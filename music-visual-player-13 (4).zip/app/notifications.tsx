import React, { useEffect, useState } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity, FlatList, Switch, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import BottomNav from './components/BottomNav';
import { useAuth } from './context/AuthContext';
import NotificationService, { 
  initializeNotifications, 
  requestPermissions, 
  areNotificationsEnabled,
  addNotificationListener,
  PushNotification 
} from './services/NotificationService';

export default function NotificationsScreen() {
  const router = useRouter();
  const { notifications, markNotificationRead, markAllNotificationsRead, getUnreadCount, addNotification } = useAuth();
  const unreadCount = getUnreadCount();
  const [pushEnabled, setPushEnabled] = useState(false);
  const [filter, setFilter] = useState<'all' | 'unread' | 'votes' | 'system'>('all');

  // Initialize push notifications
  useEffect(() => {
    const init = async () => {
      const enabled = await initializeNotifications();
      setPushEnabled(enabled);
    };
    init();

    // Listen for incoming push notifications
    const unsubscribe = addNotificationListener((notification: PushNotification) => {
      addNotification({
        type: notification.type as any,
        title: notification.title,
        message: notification.body,
        data: notification.data,
      });
    });

    return () => unsubscribe();
  }, []);

  const handleTogglePush = async () => {
    if (!pushEnabled) {
      const granted = await requestPermissions();
      if (granted) {
        setPushEnabled(true);
        Alert.alert('Notifications Enabled', 'You will now receive push notifications for votes, messages, and more!');
      } else {
        Alert.alert('Permission Denied', 'Please enable notifications in your device settings.');
      }
    } else {
      setPushEnabled(false);
      Alert.alert('Notifications Disabled', 'You will no longer receive push notifications.');
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'vote':
      case 'vote_received':
        return { name: 'heart', color: COLORS.error };
      case 'elimination':
        return { name: 'trending-down', color: COLORS.error };
      case 'advance':
        return { name: 'trending-up', color: COLORS.success };
      case 'winner':
        return { name: 'trophy', color: COLORS.gold };
      case 'message':
        return { name: 'chatbubble', color: COLORS.primary };
      case 'like':
        return { name: 'thumbs-up', color: COLORS.success };
      case 'purchase':
        return { name: 'cart', color: COLORS.gold };
      case 'payout':
        return { name: 'cash', color: COLORS.success };
      default:
        return { name: 'notifications', color: COLORS.primary };
    }
  };

  const formatTime = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !n.read;
    if (filter === 'votes') return n.type === 'vote' || n.type === 'vote_received';
    if (filter === 'system') return n.type === 'system';
    return true;
  });

  const filters = [
    { id: 'all', label: 'All', icon: 'list' },
    { id: 'unread', label: 'Unread', icon: 'mail-unread' },
    { id: 'votes', label: 'Votes', icon: 'heart' },
    { id: 'system', label: 'System', icon: 'settings' },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>Notifications</Text>
        {unreadCount > 0 && (
          <TouchableOpacity onPress={markAllNotificationsRead}>
            <Text style={styles.markAllRead}>Mark all read</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Push Notification Toggle */}
      <View style={styles.pushToggle}>
        <View style={styles.pushInfo}>
          <Ionicons name="notifications" size={24} color={COLORS.primary} />
          <View style={styles.pushText}>
            <Text style={styles.pushTitle}>Push Notifications</Text>
            <Text style={styles.pushDesc}>Get notified about votes, messages & more</Text>
          </View>
        </View>
        <Switch
          value={pushEnabled}
          onValueChange={handleTogglePush}
          trackColor={{ false: COLORS.backgroundLight, true: COLORS.primary }}
          thumbColor={COLORS.textPrimary}
        />
      </View>

      {/* Filter Tabs */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false} 
        style={styles.filterContainer}
        contentContainerStyle={styles.filterContent}
      >
        {filters.map(f => (
          <TouchableOpacity
            key={f.id}
            style={[styles.filterBtn, filter === f.id && styles.filterBtnActive]}
            onPress={() => setFilter(f.id as any)}
          >
            <Ionicons 
              name={f.icon as any} 
              size={16} 
              color={filter === f.id ? COLORS.textPrimary : COLORS.textMuted} 
            />
            <Text style={[styles.filterText, filter === f.id && styles.filterTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {unreadCount > 0 && filter === 'all' && (
        <View style={styles.unreadBanner}>
          <Ionicons name="notifications" size={20} color={COLORS.primary} />
          <Text style={styles.unreadText}>{unreadCount} unread notification{unreadCount > 1 ? 's' : ''}</Text>
        </View>
      )}

      <FlatList
        data={filteredNotifications}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => {
          const icon = getNotificationIcon(item.type);
          return (
            <TouchableOpacity 
              style={[styles.notifItem, !item.read && styles.notifUnread]}
              onPress={() => {
                markNotificationRead(item.id);
                // Navigate based on notification type
                if (item.type === 'vote' || item.type === 'vote_received') {
                  router.push('/contests');
                } else if (item.type === 'message') {
                  router.push('/messages');
                } else if (item.type === 'purchase' || item.type === 'payout') {
                  router.push('/wallet');
                }
              }}
            >
              <View style={[styles.notifIcon, { backgroundColor: `${icon.color}20` }]}>
                <Ionicons name={icon.name as any} size={24} color={icon.color} />
              </View>
              <View style={styles.notifContent}>
                <View style={styles.notifHeader}>
                  <Text style={styles.notifTitle}>{item.title}</Text>
                  <Text style={styles.notifTime}>{formatTime(item.timestamp)}</Text>
                </View>
                <Text style={styles.notifMessage}>{item.message}</Text>
                <View style={styles.notifMeta}>
                  <View style={styles.typeBadge}>
                    <Text style={styles.typeBadgeText}>{item.type.replace('_', ' ')}</Text>
                  </View>
                </View>
              </View>
              {!item.read && <View style={styles.unreadDot} />}
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="notifications-off-outline" size={64} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Notifications</Text>
            <Text style={styles.emptyText}>
              {filter === 'unread' ? 'All caught up!' : 'Nothing to show here'}
            </Text>
          </View>
        }
      />

      {/* Notification Types Info */}
      <View style={styles.infoSection}>
        <Text style={styles.infoTitle}>You'll be notified when:</Text>
        <View style={styles.infoList}>
          <View style={styles.infoItem}>
            <Ionicons name="heart" size={16} color={COLORS.error} />
            <Text style={styles.infoText}>Someone votes for you in contests</Text>
          </View>
          <View style={styles.infoItem}>
            <Ionicons name="trending-up" size={16} color={COLORS.success} />
            <Text style={styles.infoText}>You advance or get eliminated</Text>
          </View>
          <View style={styles.infoItem}>
            <Ionicons name="chatbubble" size={16} color={COLORS.primary} />
            <Text style={styles.infoText}>You receive new messages</Text>
          </View>
          <View style={styles.infoItem}>
            <Ionicons name="cart" size={16} color={COLORS.gold} />
            <Text style={styles.infoText}>Your content gets likes or purchases</Text>
          </View>
        </View>
      </View>

      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontSize: 24, fontWeight: '700', color: COLORS.textPrimary },
  markAllRead: { color: COLORS.primary, fontWeight: '600' },
  pushToggle: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    backgroundColor: COLORS.backgroundCard, 
    marginHorizontal: 20, 
    padding: 16, 
    borderRadius: 12, 
    marginBottom: 16 
  },
  pushInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  pushText: { flex: 1 },
  pushTitle: { color: COLORS.textPrimary, fontWeight: '600' },
  pushDesc: { color: COLORS.textMuted, fontSize: 12 },
  filterContainer: { maxHeight: 50, marginBottom: 12 },
  filterContent: { paddingHorizontal: 20, gap: 8 },
  filterBtn: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 6, 
    paddingHorizontal: 16, 
    paddingVertical: 8, 
    backgroundColor: COLORS.backgroundCard, 
    borderRadius: 20 
  },
  filterBtnActive: { backgroundColor: COLORS.primary },
  filterText: { color: COLORS.textMuted, fontWeight: '600', fontSize: 13 },
  filterTextActive: { color: COLORS.textPrimary },
  unreadBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, padding: 12, borderRadius: 12, marginBottom: 16 },
  unreadText: { color: COLORS.textPrimary, fontWeight: '600' },
  listContent: { paddingHorizontal: 20, paddingBottom: 200 },
  notifItem: { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 8 },
  notifUnread: { backgroundColor: 'rgba(139,92,246,0.1)', borderWidth: 1, borderColor: COLORS.primary },
  notifIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  notifContent: { flex: 1, marginLeft: 12 },
  notifHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  notifTitle: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 15, flex: 1 },
  notifMessage: { color: COLORS.textMuted, fontSize: 13, marginTop: 4, lineHeight: 20 },
  notifTime: { color: COLORS.textMuted, fontSize: 11 },
  notifMeta: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  typeBadge: { backgroundColor: COLORS.backgroundLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  typeBadgeText: { color: COLORS.textMuted, fontSize: 10, textTransform: 'uppercase' },
  unreadDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.primary },
  emptyState: { alignItems: 'center', paddingTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary, marginTop: 16 },
  emptyText: { color: COLORS.textMuted, marginTop: 8 },
  infoSection: { 
    backgroundColor: COLORS.backgroundCard, 
    marginHorizontal: 20, 
    padding: 16, 
    borderRadius: 12,
    marginBottom: 100,
  },
  infoTitle: { color: COLORS.textPrimary, fontWeight: '600', marginBottom: 12 },
  infoList: { gap: 8 },
  infoItem: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { color: COLORS.textMuted, fontSize: 13 },
});
