import React, { useEffect, useState, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { COLORS } from '../constants/colors';

interface WaveformVisualizerProps {
  isRecording: boolean;
  waveformData?: number[];
  barCount?: number;
  barWidth?: number;
  barSpacing?: number;
  minHeight?: number;
  maxHeight?: number;
  color?: string;
  activeColor?: string;
}

export default function WaveformVisualizer({
  isRecording,
  waveformData = [],
  barCount = 40,
  barWidth = 4,
  barSpacing = 2,
  minHeight = 4,
  maxHeight = 80,
  color = COLORS.primary,
  activeColor = COLORS.error,
}: WaveformVisualizerProps) {
  const [bars, setBars] = useState<number[]>(Array(barCount).fill(minHeight));
  const animatedValues = useRef<Animated.Value[]>(
    Array(barCount).fill(null).map(() => new Animated.Value(minHeight))
  ).current;

  useEffect(() => {
    if (isRecording && waveformData.length > 0) {
      // Use actual waveform data
      const step = Math.floor(waveformData.length / barCount);
      const newBars = Array(barCount).fill(0).map((_, i) => {
        const dataIndex = Math.min(i * step, waveformData.length - 1);
        const value = waveformData[dataIndex] || 0;
        return minHeight + value * (maxHeight - minHeight);
      });
      
      // Animate to new values
      newBars.forEach((height, i) => {
        Animated.spring(animatedValues[i], {
          toValue: height,
          friction: 8,
          tension: 100,
          useNativeDriver: false,
        }).start();
      });
      
      setBars(newBars);
    } else if (isRecording) {
      // Generate random waveform when no data
      const interval = setInterval(() => {
        const newBars = Array(barCount).fill(0).map(() => 
          minHeight + Math.random() * (maxHeight - minHeight) * 0.8
        );
        
        newBars.forEach((height, i) => {
          Animated.spring(animatedValues[i], {
            toValue: height,
            friction: 8,
            tension: 100,
            useNativeDriver: false,
          }).start();
        });
        
        setBars(newBars);
      }, 100);

      return () => clearInterval(interval);
    } else {
      // Reset to minimum height when not recording
      animatedValues.forEach(value => {
        Animated.timing(value, {
          toValue: minHeight,
          duration: 300,
          useNativeDriver: false,
        }).start();
      });
      setBars(Array(barCount).fill(minHeight));
    }
  }, [isRecording, waveformData, barCount, minHeight, maxHeight]);

  return (
    <View style={styles.container}>
      <View style={[styles.waveformContainer, { gap: barSpacing }]}>
        {animatedValues.map((animatedValue, index) => (
          <Animated.View
            key={index}
            style={[
              styles.bar,
              {
                width: barWidth,
                height: animatedValue,
                backgroundColor: isRecording ? activeColor : color,
                borderRadius: barWidth / 2,
              },
            ]}
          />
        ))}
      </View>
      
      {/* Center line */}
      <View style={styles.centerLine} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  waveformContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
  },
  bar: {
    backgroundColor: COLORS.primary,
  },
  centerLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: COLORS.backgroundLight,
    opacity: 0.3,
  },
});
