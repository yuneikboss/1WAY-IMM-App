import React from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { COLORS } from '../../constants/colors';

interface DataPoint {
  label: string;
  value: number;
}

interface LineChartProps {
  data: DataPoint[];
  title?: string;
  color?: string;
  height?: number;
  showLabels?: boolean;
  showValues?: boolean;
  suffix?: string;
  formatValue?: (value: number) => string;
}

export default function LineChart({
  data,
  title,
  color = COLORS.primary,
  height = 200,
  showLabels = true,
  showValues = true,
  suffix = '',
  formatValue,
}: LineChartProps) {
  if (!data || data.length === 0) {
    return (
      <View style={[styles.container, { height }]}>
        <Text style={styles.noData}>No data available</Text>
      </View>
    );
  }

  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue || 1;
  const chartHeight = height - 60;
  const chartWidth = Dimensions.get('window').width - 80;
  const pointSpacing = chartWidth / (data.length - 1 || 1);

  const getY = (value: number) => {
    return chartHeight - ((value - minValue) / range) * chartHeight;
  };

  const formatDisplayValue = (value: number) => {
    if (formatValue) return formatValue(value);
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M${suffix}`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K${suffix}`;
    return `${value}${suffix}`;
  };

  return (
    <View style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View style={[styles.chartContainer, { height }]}>
        {/* Y-axis labels */}
        <View style={styles.yAxis}>
          <Text style={styles.axisLabel}>{formatDisplayValue(maxValue)}</Text>
          <Text style={styles.axisLabel}>{formatDisplayValue((maxValue + minValue) / 2)}</Text>
          <Text style={styles.axisLabel}>{formatDisplayValue(minValue)}</Text>
        </View>

        {/* Chart area */}
        <View style={styles.chartArea}>
          {/* Grid lines */}
          <View style={[styles.gridLine, { top: 0 }]} />
          <View style={[styles.gridLine, { top: chartHeight / 2 }]} />
          <View style={[styles.gridLine, { top: chartHeight }]} />

          {/* Line and points */}
          <View style={styles.lineContainer}>
            {data.map((point, index) => {
              const x = index * pointSpacing;
              const y = getY(point.value);
              const nextPoint = data[index + 1];
              
              return (
                <React.Fragment key={index}>
                  {/* Line segment */}
                  {nextPoint && (
                    <View
                      style={[
                        styles.lineSegment,
                        {
                          left: x,
                          top: y,
                          width: Math.sqrt(
                            Math.pow(pointSpacing, 2) +
                            Math.pow(getY(nextPoint.value) - y, 2)
                          ),
                          transform: [
                            {
                              rotate: `${Math.atan2(
                                getY(nextPoint.value) - y,
                                pointSpacing
                              )}rad`,
                            },
                          ],
                          backgroundColor: color,
                        },
                      ]}
                    />
                  )}
                  
                  {/* Data point */}
                  <View
                    style={[
                      styles.dataPoint,
                      {
                        left: x - 6,
                        top: y - 6,
                        backgroundColor: color,
                      },
                    ]}
                  />
                  
                  {/* Value tooltip */}
                  {showValues && (
                    <View style={[styles.valueTooltip, { left: x - 20, top: y - 28 }]}>
                      <Text style={styles.valueText}>{formatDisplayValue(point.value)}</Text>
                    </View>
                  )}
                </React.Fragment>
              );
            })}
          </View>

          {/* X-axis labels */}
          {showLabels && (
            <View style={styles.xAxis}>
              {data.map((point, index) => (
                <Text
                  key={index}
                  style={[
                    styles.xLabel,
                    { left: index * pointSpacing - 20, width: 40 },
                  ]}
                  numberOfLines={1}
                >
                  {point.label}
                </Text>
              ))}
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  noData: {
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: 40,
  },
  chartContainer: {
    flexDirection: 'row',
    paddingRight: 16,
  },
  yAxis: {
    width: 50,
    justifyContent: 'space-between',
    paddingBottom: 30,
  },
  axisLabel: {
    fontSize: 10,
    color: COLORS.textMuted,
    textAlign: 'right',
    paddingRight: 8,
  },
  chartArea: {
    flex: 1,
    position: 'relative',
  },
  gridLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: COLORS.backgroundCard,
  },
  lineContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 30,
  },
  lineSegment: {
    position: 'absolute',
    height: 2,
    transformOrigin: 'left center',
  },
  dataPoint: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: COLORS.background,
  },
  valueTooltip: {
    position: 'absolute',
    width: 40,
    alignItems: 'center',
  },
  valueText: {
    fontSize: 9,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  xAxis: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 30,
  },
  xLabel: {
    position: 'absolute',
    fontSize: 10,
    color: COLORS.textMuted,
    textAlign: 'center',
    top: 8,
  },
});
