import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../../constants/colors';

interface DataPoint {
  label: string;
  value: number;
  color?: string;
}

interface BarChartProps {
  data: DataPoint[];
  title?: string;
  color?: string;
  height?: number;
  horizontal?: boolean;
  showValues?: boolean;
  suffix?: string;
  formatValue?: (value: number) => string;
}

export default function BarChart({
  data,
  title,
  color = COLORS.primary,
  height = 200,
  horizontal = false,
  showValues = true,
  suffix = '',
  formatValue,
}: BarChartProps) {
  if (!data || data.length === 0) {
    return (
      <View style={[styles.container, { height }]}>
        <Text style={styles.noData}>No data available</Text>
      </View>
    );
  }

  const maxValue = Math.max(...data.map(d => d.value));

  const formatDisplayValue = (value: number) => {
    if (formatValue) return formatValue(value);
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M${suffix}`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K${suffix}`;
    return `${value}${suffix}`;
  };

  if (horizontal) {
    return (
      <View style={styles.container}>
        {title && <Text style={styles.title}>{title}</Text>}
        <View style={styles.horizontalChart}>
          {data.map((item, index) => (
            <View key={index} style={styles.horizontalBarContainer}>
              <Text style={styles.horizontalLabel} numberOfLines={1}>
                {item.label}
              </Text>
              <View style={styles.horizontalBarWrapper}>
                <View
                  style={[
                    styles.horizontalBar,
                    {
                      width: `${(item.value / maxValue) * 100}%`,
                      backgroundColor: item.color || color,
                    },
                  ]}
                />
                {showValues && (
                  <Text style={styles.horizontalValue}>
                    {formatDisplayValue(item.value)}
                  </Text>
                )}
              </View>
            </View>
          ))}
        </View>
      </View>
    );
  }

  const barWidth = Math.min(40, (100 / data.length) - 2);

  return (
    <View style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View style={[styles.verticalChart, { height }]}>
        <View style={styles.barsContainer}>
          {data.map((item, index) => {
            const barHeight = (item.value / maxValue) * (height - 40);
            return (
              <View key={index} style={styles.barColumn}>
                {showValues && (
                  <Text style={styles.barValue}>
                    {formatDisplayValue(item.value)}
                  </Text>
                )}
                <View
                  style={[
                    styles.bar,
                    {
                      height: barHeight,
                      width: `${barWidth}%`,
                      backgroundColor: item.color || color,
                    },
                  ]}
                />
                <Text style={styles.barLabel} numberOfLines={1}>
                  {item.label}
                </Text>
              </View>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  noData: {
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: 40,
  },
  verticalChart: {
    justifyContent: 'flex-end',
  },
  barsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    flex: 1,
    paddingBottom: 24,
  },
  barColumn: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    borderRadius: 4,
    minHeight: 4,
  },
  barValue: {
    fontSize: 10,
    color: COLORS.textSecondary,
    fontWeight: '600',
    marginBottom: 4,
  },
  barLabel: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 8,
    textAlign: 'center',
    maxWidth: 50,
  },
  horizontalChart: {
    gap: 12,
  },
  horizontalBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  horizontalLabel: {
    width: 80,
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'right',
  },
  horizontalBarWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  horizontalBar: {
    height: 24,
    borderRadius: 4,
    minWidth: 4,
  },
  horizontalValue: {
    fontSize: 12,
    color: COLORS.textPrimary,
    fontWeight: '600',
  },
});
