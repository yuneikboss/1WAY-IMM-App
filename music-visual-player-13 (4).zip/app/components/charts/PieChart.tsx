import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../../constants/colors';

interface DataPoint {
  label: string;
  value: number;
  color: string;
}

interface PieChartProps {
  data: DataPoint[];
  title?: string;
  size?: number;
  donut?: boolean;
  showLegend?: boolean;
  showPercentages?: boolean;
  centerLabel?: string;
  centerValue?: string;
}

export default function PieChart({
  data,
  title,
  size = 160,
  donut = true,
  showLegend = true,
  showPercentages = true,
  centerLabel,
  centerValue,
}: PieChartProps) {
  if (!data || data.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.noData}>No data available</Text>
      </View>
    );
  }

  const total = data.reduce((sum, item) => sum + item.value, 0);
  const radius = size / 2;
  const innerRadius = donut ? radius * 0.6 : 0;

  // Calculate segments
  let currentAngle = -90; // Start from top
  const segments = data.map((item) => {
    const percentage = (item.value / total) * 100;
    const angle = (percentage / 100) * 360;
    const segment = {
      ...item,
      percentage,
      startAngle: currentAngle,
      endAngle: currentAngle + angle,
    };
    currentAngle += angle;
    return segment;
  });

  // Create SVG-like segments using View transforms
  const renderSegments = () => {
    return segments.map((segment, index) => {
      const midAngle = (segment.startAngle + segment.endAngle) / 2;
      const angleRad = (midAngle * Math.PI) / 180;
      const segmentSize = segment.percentage / 100;
      
      // For small segments, use a simpler representation
      if (segmentSize < 0.03) return null;

      return (
        <View
          key={index}
          style={[
            styles.segment,
            {
              width: size,
              height: size,
              borderRadius: radius,
              backgroundColor: segment.color,
              position: 'absolute',
              opacity: 0.9,
              transform: [
                { rotate: `${segment.startAngle + 90}deg` },
              ],
              // Use clip to show only the segment portion
            },
          ]}
        />
      );
    });
  };

  // Simplified pie chart using conic gradient simulation with multiple layers
  const renderPieSlices = () => {
    let accumulatedPercentage = 0;
    
    return segments.map((segment, index) => {
      const rotation = accumulatedPercentage * 3.6 - 90;
      const sliceAngle = segment.percentage * 3.6;
      accumulatedPercentage += segment.percentage;

      // Create two half-circles for each segment
      if (sliceAngle <= 180) {
        return (
          <View
            key={index}
            style={[
              styles.pieSlice,
              {
                width: size,
                height: size,
                borderRadius: radius,
                transform: [{ rotate: `${rotation}deg` }],
              },
            ]}
          >
            <View
              style={[
                styles.halfCircle,
                {
                  width: size / 2,
                  height: size,
                  borderTopLeftRadius: radius,
                  borderBottomLeftRadius: radius,
                  backgroundColor: segment.color,
                  transform: [
                    { translateX: size / 4 },
                    { rotate: `${sliceAngle}deg` },
                    { translateX: -size / 4 },
                  ],
                },
              ]}
            />
          </View>
        );
      } else {
        // For segments > 180 degrees, we need two halves
        return (
          <View
            key={index}
            style={[
              styles.pieSlice,
              {
                width: size,
                height: size,
                borderRadius: radius,
                transform: [{ rotate: `${rotation}deg` }],
              },
            ]}
          >
            <View
              style={[
                styles.halfCircle,
                {
                  width: size / 2,
                  height: size,
                  borderTopLeftRadius: radius,
                  borderBottomLeftRadius: radius,
                  backgroundColor: segment.color,
                  transform: [
                    { translateX: size / 4 },
                    { rotate: '180deg' },
                    { translateX: -size / 4 },
                  ],
                },
              ]}
            />
            <View
              style={[
                styles.halfCircle,
                {
                  position: 'absolute',
                  width: size / 2,
                  height: size,
                  borderTopRightRadius: radius,
                  borderBottomRightRadius: radius,
                  backgroundColor: segment.color,
                  right: 0,
                  transform: [
                    { translateX: -size / 4 },
                    { rotate: `${sliceAngle - 180}deg` },
                    { translateX: size / 4 },
                  ],
                },
              ]}
            />
          </View>
        );
      }
    });
  };

  return (
    <View style={styles.container}>
      {title && <Text style={styles.title}>{title}</Text>}
      <View style={styles.chartRow}>
        <View style={[styles.pieContainer, { width: size, height: size }]}>
          {/* Background circle */}
          <View
            style={[
              styles.backgroundCircle,
              { width: size, height: size, borderRadius: radius },
            ]}
          />
          
          {/* Colored segments - simplified approach */}
          {segments.map((segment, index) => {
            const startPercent = segments
              .slice(0, index)
              .reduce((sum, s) => sum + s.percentage, 0);
            
            return (
              <View
                key={index}
                style={[
                  styles.segmentArc,
                  {
                    width: size,
                    height: size,
                    borderRadius: radius,
                    borderWidth: donut ? radius * 0.4 : radius,
                    borderColor: 'transparent',
                    borderTopColor: segment.color,
                    borderRightColor: segment.percentage > 25 ? segment.color : 'transparent',
                    borderBottomColor: segment.percentage > 50 ? segment.color : 'transparent',
                    borderLeftColor: segment.percentage > 75 ? segment.color : 'transparent',
                    transform: [{ rotate: `${startPercent * 3.6 - 45}deg` }],
                  },
                ]}
              />
            );
          })}

          {/* Donut hole */}
          {donut && (
            <View
              style={[
                styles.donutHole,
                {
                  width: innerRadius * 2,
                  height: innerRadius * 2,
                  borderRadius: innerRadius,
                },
              ]}
            >
              {centerLabel && (
                <Text style={styles.centerLabel}>{centerLabel}</Text>
              )}
              {centerValue && (
                <Text style={styles.centerValue}>{centerValue}</Text>
              )}
            </View>
          )}
        </View>

        {/* Legend */}
        {showLegend && (
          <View style={styles.legend}>
            {segments.map((segment, index) => (
              <View key={index} style={styles.legendItem}>
                <View
                  style={[styles.legendDot, { backgroundColor: segment.color }]}
                />
                <View style={styles.legendTextContainer}>
                  <Text style={styles.legendLabel} numberOfLines={1}>
                    {segment.label}
                  </Text>
                  {showPercentages && (
                    <Text style={styles.legendPercentage}>
                      {segment.percentage.toFixed(1)}%
                    </Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  noData: {
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: 40,
  },
  chartRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  pieContainer: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundCircle: {
    position: 'absolute',
    backgroundColor: COLORS.backgroundCard,
  },
  segmentArc: {
    position: 'absolute',
  },
  pieSlice: {
    position: 'absolute',
    overflow: 'hidden',
  },
  halfCircle: {
    position: 'absolute',
  },
  segment: {
    overflow: 'hidden',
  },
  donutHole: {
    position: 'absolute',
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  centerLabel: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  centerValue: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  legend: {
    flex: 1,
    gap: 8,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  legendDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  legendTextContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  legendLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    flex: 1,
  },
  legendPercentage: {
    fontSize: 12,
    color: COLORS.textPrimary,
    fontWeight: '600',
  },
});
