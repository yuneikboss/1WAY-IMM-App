import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/colors';
import { LinearGradient } from 'expo-linear-gradient';

export type CardTemplate = 'milestone' | 'contest_win' | 'earnings' | 'followers' | 'streak';

interface ShareableCardProps {
  template: CardTemplate;
  title: string;
  value: string;
  subtitle?: string;
  artistName: string;
  artistImage?: string;
  date?: string;
  onShare?: () => void;
  onCustomize?: () => void;
}

const TEMPLATE_CONFIGS: Record<CardTemplate, {
  gradient: string[];
  icon: string;
  iconColor: string;
  pattern: 'circles' | 'lines' | 'dots' | 'waves' | 'stars';
}> = {
  milestone: {
    gradient: [COLORS.primary, '#8B5CF6'],
    icon: 'play-circle',
    iconColor: '#fff',
    pattern: 'circles',
  },
  contest_win: {
    gradient: ['#F59E0B', '#EF4444'],
    icon: 'trophy',
    iconColor: '#fff',
    pattern: 'stars',
  },
  earnings: {
    gradient: ['#10B981', '#059669'],
    icon: 'cash',
    iconColor: '#fff',
    pattern: 'lines',
  },
  followers: {
    gradient: ['#EC4899', '#8B5CF6'],
    icon: 'people',
    iconColor: '#fff',
    pattern: 'dots',
  },
  streak: {
    gradient: ['#F97316', '#EAB308'],
    icon: 'flame',
    iconColor: '#fff',
    pattern: 'waves',
  },
};

export default function ShareableCard({
  template,
  title,
  value,
  subtitle,
  artistName,
  artistImage,
  date,
  onShare,
  onCustomize,
}: ShareableCardProps) {
  const config = TEMPLATE_CONFIGS[template];

  const renderPattern = () => {
    switch (config.pattern) {
      case 'circles':
        return (
          <>
            <View style={[styles.patternCircle, styles.circle1]} />
            <View style={[styles.patternCircle, styles.circle2]} />
            <View style={[styles.patternCircle, styles.circle3]} />
          </>
        );
      case 'stars':
        return (
          <>
            <Ionicons name="star" size={40} color="rgba(255,255,255,0.1)" style={styles.star1} />
            <Ionicons name="star" size={60} color="rgba(255,255,255,0.1)" style={styles.star2} />
            <Ionicons name="star" size={30} color="rgba(255,255,255,0.1)" style={styles.star3} />
          </>
        );
      case 'dots':
        return (
          <View style={styles.dotsContainer}>
            {Array(20).fill(0).map((_, i) => (
              <View key={i} style={[styles.dot, { opacity: Math.random() * 0.3 + 0.1 }]} />
            ))}
          </View>
        );
      case 'lines':
        return (
          <>
            <View style={[styles.line, styles.line1]} />
            <View style={[styles.line, styles.line2]} />
            <View style={[styles.line, styles.line3]} />
          </>
        );
      case 'waves':
        return (
          <View style={styles.wavesContainer}>
            <View style={[styles.wave, styles.wave1]} />
            <View style={[styles.wave, styles.wave2]} />
          </View>
        );
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={config.gradient as any}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        {renderPattern()}
        
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <Text style={styles.logoText}>1WAY</Text>
          </View>
          {date && <Text style={styles.date}>{date}</Text>}
        </View>

        {/* Main Content */}
        <View style={styles.content}>
          <View style={styles.iconContainer}>
            <Ionicons name={config.icon as any} size={48} color={config.iconColor} />
          </View>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.value}>{value}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>

        {/* Artist Info */}
        <View style={styles.artistContainer}>
          {artistImage ? (
            <Image source={{ uri: artistImage }} style={styles.artistImage} />
          ) : (
            <View style={styles.artistImagePlaceholder}>
              <Ionicons name="person" size={20} color="#fff" />
            </View>
          )}
          <Text style={styles.artistName}>{artistName}</Text>
          <Ionicons name="checkmark-circle" size={16} color="#fff" />
        </View>

        {/* Watermark */}
        <View style={styles.watermark}>
          <Text style={styles.watermarkText}>1way.music</Text>
        </View>
      </LinearGradient>

      {/* Action Buttons */}
      <View style={styles.actions}>
        {onCustomize && (
          <TouchableOpacity style={styles.customizeBtn} onPress={onCustomize}>
            <Ionicons name="color-palette-outline" size={20} color={COLORS.textPrimary} />
            <Text style={styles.customizeBtnText}>Customize</Text>
          </TouchableOpacity>
        )}
        {onShare && (
          <TouchableOpacity style={styles.shareBtn} onPress={onShare}>
            <Ionicons name="share-social" size={20} color="#fff" />
            <Text style={styles.shareBtnText}>Share</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  card: {
    borderRadius: 20,
    padding: 24,
    minHeight: 320,
    overflow: 'hidden',
    position: 'relative',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  logoContainer: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  logoText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
  date: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
  },
  content: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 2,
    marginBottom: 8,
  },
  value: {
    color: '#fff',
    fontSize: 48,
    fontWeight: '800',
    marginBottom: 8,
  },
  subtitle: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    textAlign: 'center',
  },
  artistContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 24,
  },
  artistImage: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  artistImagePlaceholder: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  artistName: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  watermark: {
    position: 'absolute',
    bottom: 12,
    right: 16,
  },
  watermarkText: {
    color: 'rgba(255,255,255,0.4)',
    fontSize: 10,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  customizeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: COLORS.backgroundCard,
    paddingVertical: 14,
    borderRadius: 12,
  },
  customizeBtnText: {
    color: COLORS.textPrimary,
    fontSize: 14,
    fontWeight: '600',
  },
  shareBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: 12,
  },
  shareBtnText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  // Pattern styles
  patternCircle: {
    position: 'absolute',
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  circle1: {
    width: 200,
    height: 200,
    top: -50,
    right: -50,
  },
  circle2: {
    width: 150,
    height: 150,
    bottom: -30,
    left: -30,
  },
  circle3: {
    width: 80,
    height: 80,
    top: 100,
    left: 50,
  },
  star1: {
    position: 'absolute',
    top: 20,
    right: 40,
  },
  star2: {
    position: 'absolute',
    bottom: 40,
    left: 20,
  },
  star3: {
    position: 'absolute',
    top: 80,
    left: 100,
  },
  dotsContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    padding: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#fff',
    margin: 10,
  },
  line: {
    position: 'absolute',
    height: 2,
    backgroundColor: 'rgba(255,255,255,0.1)',
    transform: [{ rotate: '-30deg' }],
  },
  line1: {
    width: 300,
    top: 50,
    left: -50,
  },
  line2: {
    width: 250,
    top: 150,
    left: -30,
  },
  line3: {
    width: 200,
    bottom: 80,
    right: -50,
  },
  wavesContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  wave: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 50,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderTopLeftRadius: 100,
    borderTopRightRadius: 100,
  },
  wave1: {
    bottom: 0,
  },
  wave2: {
    bottom: 30,
    opacity: 0.5,
  },
});
