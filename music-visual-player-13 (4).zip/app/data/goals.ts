import { COLORS } from '../constants/colors';

export type GoalType = 'plays' | 'followers' | 'earnings' | 'contest_rank' | 'votes';
export type GoalStatus = 'active' | 'completed' | 'failed' | 'paused';

export interface Goal {
  id: string;
  type: GoalType;
  title: string;
  description: string;
  targetValue: number;
  currentValue: number;
  startDate: number;
  endDate: number;
  status: GoalStatus;
  milestones: GoalMilestone[];
  createdAt: number;
}

export interface GoalMilestone {
  id: string;
  percentage: number;
  reached: boolean;
  reachedAt?: number;
  notified: boolean;
}

export interface AISuggestion {
  id: string;
  goalId: string;
  title: string;
  description: string;
  actionType: 'content' | 'engagement' | 'promotion' | 'timing' | 'collaboration';
  priority: 'high' | 'medium' | 'low';
  estimatedImpact: string;
  actionUrl?: string;
}

export interface GoalTemplate {
  type: GoalType;
  title: string;
  description: string;
  suggestedTargets: number[];
  icon: string;
  color: string;
}

export const GOAL_TEMPLATES: GoalTemplate[] = [
  {
    type: 'plays',
    title: 'Total Plays',
    description: 'Increase your total play count',
    suggestedTargets: [10000, 50000, 100000, 500000, 1000000],
    icon: 'play-circle',
    color: COLORS.primary,
  },
  {
    type: 'followers',
    title: 'Followers',
    description: 'Grow your fan base',
    suggestedTargets: [1000, 5000, 10000, 50000, 100000],
    icon: 'people',
    color: COLORS.secondary,
  },
  {
    type: 'earnings',
    title: 'Earnings',
    description: 'Increase your revenue',
    suggestedTargets: [100, 500, 1000, 5000, 10000],
    icon: 'cash',
    color: COLORS.success,
  },
  {
    type: 'contest_rank',
    title: 'Contest Ranking',
    description: 'Achieve a top ranking in contests',
    suggestedTargets: [10, 5, 3, 2, 1],
    icon: 'trophy',
    color: COLORS.gold,
  },
  {
    type: 'votes',
    title: 'Total Votes',
    description: 'Get more votes on your content',
    suggestedTargets: [500, 1000, 5000, 10000, 50000],
    icon: 'heart',
    color: COLORS.accent,
  },
];

// Generate AI suggestions based on goal progress
export const generateAISuggestions = (goal: Goal, analyticsData: any): AISuggestion[] => {
  const suggestions: AISuggestion[] = [];
  const progress = (goal.currentValue / goal.targetValue) * 100;
  const daysRemaining = Math.ceil((goal.endDate - Date.now()) / (1000 * 60 * 60 * 24));
  const dailyNeeded = (goal.targetValue - goal.currentValue) / Math.max(daysRemaining, 1);

  // Content suggestions
  if (goal.type === 'plays' || goal.type === 'votes') {
    suggestions.push({
      id: `sug_${Date.now()}_1`,
      goalId: goal.id,
      title: 'Post at Peak Times',
      description: `Your audience is most active between 6-9 PM. Schedule your next release during this window for maximum engagement.`,
      actionType: 'timing',
      priority: 'high',
      estimatedImpact: '+15-25% more plays',
    });

    if (progress < 50) {
      suggestions.push({
        id: `sug_${Date.now()}_2`,
        goalId: goal.id,
        title: 'Collaborate with Artists',
        description: 'Collaborations can expose your music to new audiences. Consider reaching out to artists in similar genres.',
        actionType: 'collaboration',
        priority: 'high',
        estimatedImpact: '+30-50% audience reach',
        actionUrl: '/collaborations',
      });
    }
  }

  // Follower growth suggestions
  if (goal.type === 'followers') {
    suggestions.push({
      id: `sug_${Date.now()}_3`,
      goalId: goal.id,
      title: 'Engage with Comments',
      description: 'Responding to fan comments increases loyalty and encourages more followers. Aim to reply to at least 10 comments daily.',
      actionType: 'engagement',
      priority: 'medium',
      estimatedImpact: '+10-15% follower retention',
    });

    suggestions.push({
      id: `sug_${Date.now()}_4`,
      goalId: goal.id,
      title: 'Share Behind-the-Scenes',
      description: 'Fans love exclusive content. Share your creative process, studio sessions, or daily life to build deeper connections.',
      actionType: 'content',
      priority: 'medium',
      estimatedImpact: '+20% engagement rate',
    });
  }

  // Earnings suggestions
  if (goal.type === 'earnings') {
    suggestions.push({
      id: `sug_${Date.now()}_5`,
      goalId: goal.id,
      title: 'Sell Beat Packs',
      description: 'Bundle your beats into packs at a discounted rate. This increases average order value and attracts producers.',
      actionType: 'promotion',
      priority: 'high',
      estimatedImpact: '+40% revenue per customer',
      actionUrl: '/sell',
    });

    suggestions.push({
      id: `sug_${Date.now()}_6`,
      goalId: goal.id,
      title: 'Enter Paid Contests',
      description: 'Contests with prize pools can significantly boost earnings. You have a strong track record in competitions!',
      actionType: 'promotion',
      priority: 'medium',
      estimatedImpact: 'Up to $500+ per win',
      actionUrl: '/contests',
    });
  }

  // Contest ranking suggestions
  if (goal.type === 'contest_rank') {
    suggestions.push({
      id: `sug_${Date.now()}_7`,
      goalId: goal.id,
      title: 'Promote Your Entry',
      description: 'Share your contest entry on social media. Entries with external promotion get 3x more votes on average.',
      actionType: 'promotion',
      priority: 'high',
      estimatedImpact: '+200% vote potential',
    });

    suggestions.push({
      id: `sug_${Date.now()}_8`,
      goalId: goal.id,
      title: 'Optimize Entry Timing',
      description: 'Submit entries early in the contest period. Early entries get 40% more visibility than late submissions.',
      actionType: 'timing',
      priority: 'medium',
      estimatedImpact: '+40% visibility',
    });
  }

  // General suggestions based on progress
  if (progress < 25 && daysRemaining < 14) {
    suggestions.push({
      id: `sug_${Date.now()}_9`,
      goalId: goal.id,
      title: 'Boost Your Content',
      description: `You need ${Math.ceil(dailyNeeded)} ${goal.type} per day to reach your goal. Consider promoting your top-performing content.`,
      actionType: 'promotion',
      priority: 'high',
      estimatedImpact: 'Accelerate goal progress',
    });
  }

  return suggestions.slice(0, 4); // Return top 4 suggestions
};

// Sample goals for demo
export const getSampleGoals = (): Goal[] => {
  const now = Date.now();
  const oneMonth = 30 * 24 * 60 * 60 * 1000;

  return [
    {
      id: 'goal_1',
      type: 'plays',
      title: 'Reach 1.5M Plays',
      description: 'Grow total plays to 1.5 million',
      targetValue: 1500000,
      currentValue: 1247893,
      startDate: now - oneMonth,
      endDate: now + oneMonth,
      status: 'active',
      milestones: [
        { id: 'm1', percentage: 25, reached: true, reachedAt: now - 20 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm2', percentage: 50, reached: true, reachedAt: now - 10 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm3', percentage: 75, reached: true, reachedAt: now - 3 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm4', percentage: 100, reached: false, notified: false },
      ],
      createdAt: now - oneMonth,
    },
    {
      id: 'goal_2',
      type: 'followers',
      title: 'Get 25K Followers',
      description: 'Build fan base to 25,000 followers',
      targetValue: 25000,
      currentValue: 24891,
      startDate: now - 2 * oneMonth,
      endDate: now + 7 * 24 * 60 * 60 * 1000,
      status: 'active',
      milestones: [
        { id: 'm1', percentage: 25, reached: true, reachedAt: now - 45 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm2', percentage: 50, reached: true, reachedAt: now - 30 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm3', percentage: 75, reached: true, reachedAt: now - 15 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm4', percentage: 100, reached: false, notified: false },
      ],
      createdAt: now - 2 * oneMonth,
    },
    {
      id: 'goal_3',
      type: 'earnings',
      title: 'Earn $5,000',
      description: 'Reach $5,000 in total earnings',
      targetValue: 5000,
      currentValue: 4582.50,
      startDate: now - 3 * oneMonth,
      endDate: now + 2 * oneMonth,
      status: 'active',
      milestones: [
        { id: 'm1', percentage: 25, reached: true, reachedAt: now - 60 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm2', percentage: 50, reached: true, reachedAt: now - 40 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm3', percentage: 75, reached: true, reachedAt: now - 20 * 24 * 60 * 60 * 1000, notified: true },
        { id: 'm4', percentage: 100, reached: false, notified: false },
      ],
      createdAt: now - 3 * oneMonth,
    },
    {
      id: 'goal_4',
      type: 'contest_rank',
      title: 'Win a Contest',
      description: 'Achieve #1 ranking in a contest',
      targetValue: 1,
      currentValue: 3,
      startDate: now - oneMonth,
      endDate: now + oneMonth,
      status: 'active',
      milestones: [
        { id: 'm1', percentage: 25, reached: true, notified: true },
        { id: 'm2', percentage: 50, reached: true, notified: true },
        { id: 'm3', percentage: 75, reached: false, notified: false },
        { id: 'm4', percentage: 100, reached: false, notified: false },
      ],
      createdAt: now - oneMonth,
    },
  ];
};

export const formatGoalValue = (type: GoalType, value: number): string => {
  switch (type) {
    case 'earnings':
      return `$${value.toLocaleString()}`;
    case 'contest_rank':
      return `#${value}`;
    default:
      if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
      if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
      return value.toLocaleString();
  }
};

export const getGoalProgress = (goal: Goal): number => {
  if (goal.type === 'contest_rank') {
    // For contest rank, lower is better (1 is the goal)
    const maxRank = 10; // Assume starting from rank 10
    const progress = ((maxRank - goal.currentValue) / (maxRank - goal.targetValue)) * 100;
    return Math.min(Math.max(progress, 0), 100);
  }
  return Math.min((goal.currentValue / goal.targetValue) * 100, 100);
};

export const getGoalColor = (type: GoalType): string => {
  const template = GOAL_TEMPLATES.find(t => t.type === type);
  return template?.color || COLORS.primary;
};
