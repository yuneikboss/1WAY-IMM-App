import { COLORS } from '../constants/colors';

// Generate mock data for the past 30 days
const generateDailyData = (baseValue: number, variance: number, days: number = 30) => {
  const data = [];
  const now = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    const value = Math.floor(baseValue + (Math.random() - 0.5) * variance * 2);
    data.push({
      label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      value: Math.max(0, value),
      date: date.toISOString(),
    });
  }
  
  return data;
};

// Generate weekly data
const generateWeeklyData = (baseValue: number, variance: number, weeks: number = 12) => {
  const data = [];
  const now = new Date();
  
  for (let i = weeks - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i * 7);
    const value = Math.floor(baseValue + (Math.random() - 0.5) * variance * 2);
    data.push({
      label: `Week ${weeks - i}`,
      value: Math.max(0, value),
      date: date.toISOString(),
    });
  }
  
  return data;
};

// Generate monthly data
const generateMonthlyData = (baseValue: number, variance: number, months: number = 6) => {
  const data = [];
  const now = new Date();
  
  for (let i = months - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setMonth(date.getMonth() - i);
    const value = Math.floor(baseValue + (Math.random() - 0.5) * variance * 2);
    data.push({
      label: date.toLocaleDateString('en-US', { month: 'short' }),
      value: Math.max(0, value),
      date: date.toISOString(),
    });
  }
  
  return data;
};

export interface AnalyticsData {
  overview: {
    totalPlays: number;
    totalVotes: number;
    totalEarnings: number;
    totalFollowers: number;
    playsChange: number;
    votesChange: number;
    earningsChange: number;
    followersChange: number;
  };
  playsOverTime: { label: string; value: number; date?: string }[];
  votesOverTime: { label: string; value: number; date?: string }[];
  earningsOverTime: { label: string; value: number; date?: string }[];
  earningsBreakdown: { label: string; value: number; color: string }[];
  fanDemographics: {
    age: { label: string; value: number; color: string }[];
    gender: { label: string; value: number; color: string }[];
    location: { label: string; value: number; color: string }[];
  };
  peakListeningTimes: { label: string; value: number }[];
  contestHistory: {
    contestId: string;
    contestName: string;
    date: string;
    rank: number;
    totalParticipants: number;
    votes: number;
    status: 'winner' | 'finalist' | 'eliminated' | 'active';
  }[];
  topTracks: {
    id: string;
    title: string;
    plays: number;
    votes: number;
    earnings: number;
  }[];
  recentActivity: {
    type: 'play' | 'vote' | 'purchase' | 'follow' | 'like';
    description: string;
    timestamp: number;
    value?: number;
  }[];
}

export const getAnalyticsData = (): AnalyticsData => {
  return {
    overview: {
      totalPlays: 1247893,
      totalVotes: 8742,
      totalEarnings: 4582.50,
      totalFollowers: 24891,
      playsChange: 12.5,
      votesChange: 8.3,
      earningsChange: 15.2,
      followersChange: 5.7,
    },
    playsOverTime: generateMonthlyData(200000, 50000, 6),
    votesOverTime: generateWeeklyData(700, 200, 8),
    earningsOverTime: generateMonthlyData(750, 200, 6),
    earningsBreakdown: [
      { label: 'Music Sales', value: 2150.00, color: COLORS.primary },
      { label: 'Beat Sales', value: 1280.00, color: COLORS.secondary },
      { label: 'Contest Prizes', value: 850.00, color: COLORS.gold },
      { label: 'Tips', value: 302.50, color: COLORS.success },
    ],
    fanDemographics: {
      age: [
        { label: '13-17', value: 8, color: '#f472b6' },
        { label: '18-24', value: 35, color: COLORS.primary },
        { label: '25-34', value: 32, color: COLORS.secondary },
        { label: '35-44', value: 15, color: COLORS.accent },
        { label: '45+', value: 10, color: COLORS.gold },
      ],
      gender: [
        { label: 'Male', value: 58, color: COLORS.primary },
        { label: 'Female', value: 38, color: COLORS.accent },
        { label: 'Other', value: 4, color: COLORS.secondary },
      ],
      location: [
        { label: 'United States', value: 45, color: COLORS.primary },
        { label: 'United Kingdom', value: 12, color: COLORS.secondary },
        { label: 'Canada', value: 10, color: COLORS.accent },
        { label: 'Germany', value: 8, color: COLORS.gold },
        { label: 'Australia', value: 7, color: COLORS.success },
        { label: 'Other', value: 18, color: COLORS.textMuted },
      ],
    },
    peakListeningTimes: [
      { label: '12am', value: 120 },
      { label: '3am', value: 45 },
      { label: '6am', value: 89 },
      { label: '9am', value: 234 },
      { label: '12pm', value: 456 },
      { label: '3pm', value: 678 },
      { label: '6pm', value: 890 },
      { label: '9pm', value: 1200 },
    ],
    contestHistory: [
      {
        contestId: '1',
        contestName: 'Hip-Hop Showdown 2024',
        date: '2024-12-01',
        rank: 3,
        totalParticipants: 128,
        votes: 1250,
        status: 'finalist',
      },
      {
        contestId: '2',
        contestName: 'R&B Rising Stars',
        date: '2024-11-15',
        rank: 1,
        totalParticipants: 64,
        votes: 2100,
        status: 'winner',
      },
      {
        contestId: '3',
        contestName: 'Beat Battle Championship',
        date: '2024-11-01',
        rank: 8,
        totalParticipants: 256,
        votes: 890,
        status: 'eliminated',
      },
      {
        contestId: '4',
        contestName: 'Freestyle Friday Finals',
        date: '2024-10-20',
        rank: 2,
        totalParticipants: 32,
        votes: 1580,
        status: 'finalist',
      },
      {
        contestId: '5',
        contestName: 'Summer Vibes Contest',
        date: '2024-09-15',
        rank: 1,
        totalParticipants: 96,
        votes: 1890,
        status: 'winner',
      },
    ],
    topTracks: [
      { id: '1', title: 'Midnight Dreams', plays: 458920, votes: 2340, earnings: 1250.00 },
      { id: '2', title: 'City Lights', plays: 324560, votes: 1890, earnings: 890.00 },
      { id: '3', title: 'Summer Nights', plays: 245780, votes: 1560, earnings: 720.00 },
      { id: '4', title: 'Lost in Time', plays: 189340, votes: 1120, earnings: 580.00 },
      { id: '5', title: 'Rise Up', plays: 156780, votes: 980, earnings: 450.00 },
    ],
    recentActivity: [
      { type: 'play', description: 'Midnight Dreams played 50 times', timestamp: Date.now() - 3600000, value: 50 },
      { type: 'vote', description: 'Received 12 votes in Hip-Hop Showdown', timestamp: Date.now() - 7200000, value: 12 },
      { type: 'purchase', description: 'City Lights purchased', timestamp: Date.now() - 14400000, value: 2.99 },
      { type: 'follow', description: 'Gained 25 new followers', timestamp: Date.now() - 28800000, value: 25 },
      { type: 'like', description: 'Summer Nights received 100 likes', timestamp: Date.now() - 43200000, value: 100 },
      { type: 'purchase', description: 'Beat pack sold', timestamp: Date.now() - 86400000, value: 49.99 },
      { type: 'vote', description: 'Received 8 votes in R&B Rising Stars', timestamp: Date.now() - 172800000, value: 8 },
    ],
  };
};

export const exportAnalyticsReport = (data: AnalyticsData, format: 'csv' | 'json'): string => {
  if (format === 'json') {
    return JSON.stringify(data, null, 2);
  }

  // CSV format
  let csv = 'Analytics Report\n\n';
  
  // Overview
  csv += 'OVERVIEW\n';
  csv += 'Metric,Value,Change\n';
  csv += `Total Plays,${data.overview.totalPlays},${data.overview.playsChange}%\n`;
  csv += `Total Votes,${data.overview.totalVotes},${data.overview.votesChange}%\n`;
  csv += `Total Earnings,$${data.overview.totalEarnings.toFixed(2)},${data.overview.earningsChange}%\n`;
  csv += `Total Followers,${data.overview.totalFollowers},${data.overview.followersChange}%\n\n`;
  
  // Earnings Breakdown
  csv += 'EARNINGS BREAKDOWN\n';
  csv += 'Source,Amount\n';
  data.earningsBreakdown.forEach(item => {
    csv += `${item.label},$${item.value.toFixed(2)}\n`;
  });
  csv += '\n';
  
  // Top Tracks
  csv += 'TOP TRACKS\n';
  csv += 'Title,Plays,Votes,Earnings\n';
  data.topTracks.forEach(track => {
    csv += `${track.title},${track.plays},${track.votes},$${track.earnings.toFixed(2)}\n`;
  });
  csv += '\n';
  
  // Contest History
  csv += 'CONTEST HISTORY\n';
  csv += 'Contest,Date,Rank,Participants,Votes,Status\n';
  data.contestHistory.forEach(contest => {
    csv += `${contest.contestName},${contest.date},${contest.rank},${contest.totalParticipants},${contest.votes},${contest.status}\n`;
  });
  
  return csv;
};
