import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity, Alert, Modal, TextInput, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import WalletCard from './components/WalletCard';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import { useApp } from './context/AppContext';
import { useAuth } from './context/AuthContext';
import PaymentService, { calculateFeePreview } from './services/PaymentService';
import { NotificationHelpers } from './services/NotificationService';

const PAYMENT_TYPES = [
  { id: 'card', name: 'Debit/Credit Card', icon: 'card', color: COLORS.primary, fee: '2.9% + $0.30' },
  { id: 'paypal', name: 'PayPal', icon: 'logo-paypal', color: '#0070BA', fee: '2.9% + $0.30' },
  { id: 'cashapp', name: 'Cash App', icon: 'cash', color: '#00D632', fee: '2.9% + $0.30' },
  { id: 'chime', name: 'Chime', icon: 'wallet', color: '#00D64F', fee: '2.9% + $0.30' },
  { id: 'applepay', name: 'Apple Pay', icon: 'logo-apple', color: COLORS.textPrimary, fee: '2.9% + $0.30' },
  { id: 'bank', name: 'Bank Account (ACH)', icon: 'business', color: COLORS.secondary, fee: '0.8%' },
];

const ADD_AMOUNTS = [10, 25, 50, 100, 250, 500];
const PAYOUT_AMOUNTS = [25, 50, 100, 250, 500, 1000];

type AccountType = 'personal' | 'business';

export default function WalletScreen() {
  const router = useRouter();
  const { wallet, transactions, updateWallet, addTransaction } = useApp();
  const { profile, paymentMethods, addPaymentMethod, removePaymentMethod, setDefaultPaymentMethod, receipts, addReceipt, addNotification } = useAuth();
  
  const [activeAccount, setActiveAccount] = useState<AccountType>('personal');
  const [showAccountInfo, setShowAccountInfo] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showAddFunds, setShowAddFunds] = useState(false);
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [showPayout, setShowPayout] = useState(false);
  const [showReceipts, setShowReceipts] = useState(false);
  const [showOpenAccount, setShowOpenAccount] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState(50);
  const [customAmount, setCustomAmount] = useState('');
  const [selectedPaymentType, setSelectedPaymentType] = useState<string | null>(null);
  const [selectedPayoutMethod, setSelectedPayoutMethod] = useState<string | null>(null);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [selectedPayoutPreset, setSelectedPayoutPreset] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [feePreview, setFeePreview] = useState({ fee: 0, net: 0 });
  
  // Account balances
  const [personalBalance, setPersonalBalance] = useState(wallet.balance * 0.6);
  const [businessBalance, setBusinessBalance] = useState(wallet.balance * 0.4);
  const [hasBusinessAccount, setHasBusinessAccount] = useState(false);
  
  // Card details
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCVV, setCardCVV] = useState('');
  const [cardName, setCardName] = useState('');
  
  // Bank details
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');

  const quickActions = [
    { icon: 'send', label: 'Send', color: COLORS.primary, route: '/p2p' },
    { icon: 'download', label: 'Request', color: COLORS.success, route: '/p2p' },
    { icon: 'gift', label: 'Sponsor', color: COLORS.gold, route: '/sponsor' },
    { icon: 'storefront', label: 'Store', color: COLORS.secondary, route: '/store' },
  ];

  const services = [
    { icon: 'mic', label: 'Book Demo', price: 100, route: '/demo' },
    { icon: 'videocam', label: 'Live Tour', price: 100, route: '/livetour', premium: true },
    { icon: 'musical-notes', label: 'Music Booth', price: 0, route: '/booth' },
    { icon: 'cart', label: 'Sell Music', price: 0, route: '/sell', premium: true },
  ];

  // Update fee preview when amount changes
  useEffect(() => {
    const amount = customAmount ? parseFloat(customAmount) : selectedAmount;
    if (!isNaN(amount) && amount > 0) {
      const defaultMethod = paymentMethods.find(m => m.isDefault);
      const preview = calculateFeePreview(amount, defaultMethod?.type || 'card', 'add_funds');
      setFeePreview(preview);
    }
  }, [customAmount, selectedAmount, paymentMethods]);

  const formatCardNumber = (text: string) => {
    const cleaned = text.replace(/\D/g, '');
    const formatted = cleaned.replace(/(\d{4})/g, '$1 ').trim();
    return formatted.substring(0, 19);
  };

  const formatExpiry = (text: string) => {
    const cleaned = text.replace(/\D/g, '');
    if (cleaned.length >= 2) {
      return cleaned.substring(0, 2) + '/' + cleaned.substring(2, 4);
    }
    return cleaned;
  };

  const getCurrentBalance = () => {
    return activeAccount === 'personal' ? personalBalance : businessBalance;
  };

  const calculateBusinessFee = (amount: number) => {
    // Business account: 20¢ per $1 = 20% fee
    return amount * 0.20;
  };

  const handleAddFundsConfirm = async () => {
    const amount = customAmount ? parseFloat(customAmount) : selectedAmount;
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount');
      return;
    }
    
    const defaultMethod = paymentMethods.find(m => m.isDefault);
    if (!defaultMethod) {
      Alert.alert('No Payment Method', 'Please add a payment method first');
      return;
    }

    setIsProcessing(true);

    try {
      // Create checkout session via Stripe
      const session = await PaymentService.createCheckoutSession(
        amount,
        profile?.id || '',
        profile?.email || '',
        defaultMethod.type
      );

      if (!session) {
        throw new Error('Failed to create checkout session');
      }

      // Confirm payment
      const result = await PaymentService.confirmPayment(
        session.paymentIntent.id,
        defaultMethod.id,
        amount,
        { paymentMethod: defaultMethod.type, userId: profile?.id || '', accountType: activeAccount }
      );

      if (result.success && result.receipt) {
        // Add to appropriate account
        if (activeAccount === 'personal') {
          setPersonalBalance(prev => prev + session.net);
        } else {
          setBusinessBalance(prev => prev + session.net);
        }
        
        updateWallet(session.net);
        addTransaction({ 
          type: 'receive', 
          amount: session.net, 
          fee: session.fee, 
          description: `Added funds to ${activeAccount} account via ${defaultMethod.name}` 
        });
        addReceipt(result.receipt);
        
        addNotification({
          type: 'system',
          title: 'Funds Added!',
          message: `$${session.net.toFixed(2)} has been added to your ${activeAccount} account.`,
        });

        setShowAddFunds(false);
        setCustomAmount('');
        Alert.alert('Success!', `$${session.net.toFixed(2)} has been added to your ${activeAccount} account\n\nFee: $${session.fee.toFixed(2)}`);
      } else {
        throw new Error(result.error || 'Payment failed');
      }
    } catch (error: any) {
      Alert.alert('Payment Failed', error.message || 'Please try again');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddPaymentMethod = () => {
    if (!selectedPaymentType) {
      Alert.alert('Select Type', 'Please select a payment method type');
      return;
    }

    const type = PAYMENT_TYPES.find(t => t.id === selectedPaymentType);
    
    if (selectedPaymentType === 'card') {
      if (cardNumber.replace(/\s/g, '').length < 16) {
        Alert.alert('Invalid Card', 'Please enter a valid 16-digit card number');
        return;
      }
      if (!cardExpiry || cardExpiry.length < 5) {
        Alert.alert('Invalid Expiry', 'Please enter a valid expiry date (MM/YY)');
        return;
      }
      if (!cardCVV || cardCVV.length < 3) {
        Alert.alert('Invalid CVV', 'Please enter a valid CVV');
        return;
      }
      if (!cardName.trim()) {
        Alert.alert('Invalid Name', 'Please enter the cardholder name');
        return;
      }
    }

    if (selectedPaymentType === 'bank') {
      if (!routingNumber || routingNumber.length < 9) {
        Alert.alert('Invalid Routing', 'Please enter a valid 9-digit routing number');
        return;
      }
      if (!accountNumber || accountNumber.length < 8) {
        Alert.alert('Invalid Account', 'Please enter a valid account number');
        return;
      }
      if (!accountName.trim()) {
        Alert.alert('Invalid Name', 'Please enter the account holder name');
        return;
      }
    }

    addPaymentMethod({
      type: selectedPaymentType as any,
      name: selectedPaymentType === 'card' ? `${type?.name} ****${cardNumber.slice(-4)}` : 
            selectedPaymentType === 'bank' ? `Bank ****${accountNumber.slice(-4)}` : type?.name || 'Payment Method',
      last4: selectedPaymentType === 'card' ? cardNumber.replace(/\s/g, '').slice(-4) : 
             selectedPaymentType === 'bank' ? accountNumber.slice(-4) : undefined,
      isDefault: paymentMethods.length === 0,
    });

    // Reset form
    setShowAddPayment(false);
    setSelectedPaymentType(null);
    setCardNumber('');
    setCardExpiry('');
    setCardCVV('');
    setCardName('');
    setRoutingNumber('');
    setAccountNumber('');
    setAccountName('');
    Alert.alert('Success', 'Payment method added successfully!');
  };

  const handlePayout = async () => {
    const amount = payoutAmount ? parseFloat(payoutAmount) : selectedPayoutPreset || 0;
    const currentBalance = getCurrentBalance();
    
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount');
      return;
    }
    if (amount > currentBalance) {
      Alert.alert('Insufficient Funds', `You cannot withdraw more than your ${activeAccount} balance`);
      return;
    }
    if (amount < 10) {
      Alert.alert('Minimum Payout', 'Minimum payout amount is $10');
      return;
    }

    const payoutMethod = selectedPayoutMethod 
      ? paymentMethods.find(m => m.id === selectedPayoutMethod)
      : paymentMethods.find(m => m.isDefault);
      
    if (!payoutMethod) {
      Alert.alert('No Payment Method', 'Please add a debit card or bank account for payouts');
      return;
    }

    const isInstant = payoutMethod.type === 'card';
    let fee = 0;
    let net = amount;

    // Business account: 20¢ per $1 fee on sales/payouts
    if (activeAccount === 'business') {
      fee = calculateBusinessFee(amount);
      net = amount - fee;
    } else if (isInstant) {
      // Personal account: 1% instant payout fee only
      fee = amount * 0.01;
      net = amount - fee;
    }
    
    Alert.alert(
      'Confirm Payout',
      `Account: ${activeAccount.charAt(0).toUpperCase() + activeAccount.slice(1)}\nAmount: $${amount.toFixed(2)}\n${activeAccount === 'business' ? 'Platform Fee (20¢/$1)' : isInstant ? 'Instant Fee (1%)' : 'Fee'}: $${fee.toFixed(2)}\nYou'll receive: $${net.toFixed(2)}\n\nPayout to: ${payoutMethod.name}\nEstimated arrival: ${isInstant ? '30 minutes' : '1-2 business days'}`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Confirm', 
          onPress: async () => {
            setIsProcessing(true);
            try {
              const result = await PaymentService.requestPayout(
                amount,
                payoutMethod.last4 || payoutMethod.id,
                isInstant ? 'instant' : 'bank',
                profile?.id || ''
              );

              if (result.success && result.payout) {
                // Deduct from appropriate account
                if (activeAccount === 'personal') {
                  setPersonalBalance(prev => prev - amount);
                } else {
                  setBusinessBalance(prev => prev - amount);
                }
                
                updateWallet(-amount);
                addTransaction({ 
                  type: 'send', 
                  amount, 
                  fee, 
                  description: `Payout from ${activeAccount} account to ${payoutMethod.name}` 
                });
                
                if (result.receipt) {
                  addReceipt(result.receipt);
                }

                await NotificationHelpers.payoutComplete(net, payoutMethod.name);
                
                addNotification({
                  type: 'system',
                  title: 'Payout Initiated!',
                  message: `$${net.toFixed(2)} will be sent to your ${payoutMethod.name}. ${result.payout.estimatedArrival}`,
                });

                setShowPayout(false);
                setPayoutAmount('');
                setSelectedPayoutPreset(null);
                Alert.alert(
                  'Payout Initiated!', 
                  `$${net.toFixed(2)} will be sent to your ${payoutMethod.name}.\n\nEstimated arrival: ${result.payout.estimatedArrival}`
                );
              } else {
                throw new Error(result.error || 'Payout failed');
              }
            } catch (error: any) {
              Alert.alert('Payout Failed', error.message || 'Please try again');
            } finally {
              setIsProcessing(false);
            }
          }
        }
      ]
    );
  };

  const handleOpenBusinessAccount = () => {
    Alert.alert(
      'Open Business Account',
      'Business Account Features:\n\n• Sell music, beats, and features\n• Accept payments from fans\n• Platform fee: 20¢ per $1 earned\n• No monthly fee\n\nPersonal Account Features:\n• Send & receive from friends\n• Sponsor other artists\n• Monthly fee: $1/month\n• No transaction fees\n\nWould you like to open a Business Account?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Open Business Account', 
          onPress: () => {
            setHasBusinessAccount(true);
            setShowOpenAccount(false);
            addNotification({
              type: 'system',
              title: 'Business Account Opened!',
              message: 'You can now sell music, beats, and features. Platform fee: 20¢ per $1 earned.',
            });
            Alert.alert('Success!', 'Your Business Account is now active. Start selling your music!');
          }
        }
      ]
    );
  };

  const isPremium = profile?.isPremium;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Wallet</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={() => setShowReceipts(true)}>
            <Ionicons name="receipt" size={24} color={COLORS.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setShowAddFunds(true)}>
            <Ionicons name="add-circle" size={28} color={COLORS.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Account Type Selector */}
        <View style={styles.accountSelector}>
          <TouchableOpacity 
            style={[styles.accountTab, activeAccount === 'personal' && styles.accountTabActive]}
            onPress={() => setActiveAccount('personal')}
          >
            <Ionicons name="person" size={18} color={activeAccount === 'personal' ? COLORS.textPrimary : COLORS.textMuted} />
            <Text style={[styles.accountTabText, activeAccount === 'personal' && styles.accountTabTextActive]}>Personal</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.accountTab, activeAccount === 'business' && styles.accountTabActive, !hasBusinessAccount && styles.accountTabDisabled]}
            onPress={() => {
              if (hasBusinessAccount) {
                setActiveAccount('business');
              } else {
                setShowOpenAccount(true);
              }
            }}
          >
            <Ionicons name="briefcase" size={18} color={activeAccount === 'business' ? COLORS.textPrimary : COLORS.textMuted} />
            <Text style={[styles.accountTabText, activeAccount === 'business' && styles.accountTabTextActive]}>
              {hasBusinessAccount ? 'Business' : 'Open Business'}
            </Text>
            {!hasBusinessAccount && <Ionicons name="add-circle" size={16} color={COLORS.primary} />}
          </TouchableOpacity>
        </View>

        {/* Account Info Banner */}
        <TouchableOpacity style={styles.accountInfoBanner} onPress={() => setShowAccountInfo(true)}>
          <Ionicons name="information-circle" size={20} color={activeAccount === 'personal' ? COLORS.primary : COLORS.gold} />
          <Text style={styles.accountInfoText}>
            {activeAccount === 'personal' 
              ? 'Personal: $1/month • No transaction fees' 
              : 'Business: 20¢ per $1 earned • No monthly fee'}
          </Text>
          <Ionicons name="chevron-forward" size={16} color={COLORS.textMuted} />
        </TouchableOpacity>

        {/* Balance Card */}
        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>{activeAccount === 'personal' ? 'Personal' : 'Business'} Balance</Text>
          <Text style={styles.balanceAmount}>${getCurrentBalance().toFixed(2)}</Text>
          <View style={styles.balanceDetails}>
            <View style={styles.balanceDetail}>
              <Text style={styles.detailLabel}>Available</Text>
              <Text style={styles.detailValue}>${getCurrentBalance().toFixed(2)}</Text>
            </View>
            <View style={styles.balanceDetail}>
              <Text style={styles.detailLabel}>Pending</Text>
              <Text style={styles.detailValue}>$0.00</Text>
            </View>
          </View>
        </View>

        {wallet.frozen && (
          <View style={styles.frozenBanner}>
            <Ionicons name="warning" size={20} color={COLORS.error} />
            <Text style={styles.frozenText}>Account frozen - Pay ${wallet.credits} to unfreeze</Text>
          </View>
        )}

        {isPremium && (
          <View style={styles.infiniteCard}>
            <Ionicons name="infinite" size={24} color={COLORS.gold} />
            <View style={styles.infiniteContent}>
              <Text style={styles.infiniteTitle}>1Way Infinite Money Account</Text>
              <Text style={styles.infiniteDesc}>Unlimited earnings potential unlocked</Text>
            </View>
          </View>
        )}

        <View style={styles.balanceActions}>
          <TouchableOpacity style={styles.balanceAction} onPress={() => setShowAddFunds(true)}>
            <Ionicons name="add" size={20} color={COLORS.success} />
            <Text style={styles.balanceActionText}>Add Funds</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.balanceAction, styles.payoutAction]} onPress={() => setShowPayout(true)}>
            <Ionicons name="arrow-up" size={20} color={COLORS.textPrimary} />
            <Text style={styles.balanceActionText}>Cash Out</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>Payment Methods</Text>
        <Text style={styles.sectionSubtitle}>Add cards and bank accounts to receive payouts</Text>
        
        {paymentMethods.length === 0 ? (
          <TouchableOpacity style={styles.addPaymentCard} onPress={() => setShowAddPayment(true)}>
            <Ionicons name="add-circle" size={32} color={COLORS.primary} />
            <Text style={styles.addPaymentText}>Add Debit Card or Bank Account</Text>
            <Text style={styles.addPaymentSubtext}>Required to cash out your earnings</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.paymentMethodsList}>
            {paymentMethods.map(method => (
              <TouchableOpacity 
                key={method.id} 
                style={[styles.paymentMethod, method.isDefault && styles.paymentMethodDefault]}
                onPress={() => setDefaultPaymentMethod(method.id)}
                onLongPress={() => {
                  Alert.alert('Remove Payment Method', `Remove ${method.name}?`, [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Remove', style: 'destructive', onPress: () => removePaymentMethod(method.id) }
                  ]);
                }}
              >
                <Ionicons name={PAYMENT_TYPES.find(t => t.id === method.type)?.icon as any || 'card'} size={24} color={PAYMENT_TYPES.find(t => t.id === method.type)?.color || COLORS.primary} />
                <View style={styles.paymentMethodInfo}>
                  <Text style={styles.paymentMethodName}>{method.name}</Text>
                  {method.last4 && <Text style={styles.paymentMethodLast4}>****{method.last4}</Text>}
                </View>
                {method.isDefault && (
                  <View style={styles.defaultBadge}>
                    <Text style={styles.defaultBadgeText}>DEFAULT</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.addMorePayment} onPress={() => setShowAddPayment(true)}>
              <Ionicons name="add" size={20} color={COLORS.primary} />
              <Text style={styles.addMoreText}>Add Another</Text>
            </TouchableOpacity>
          </View>
        )}

        {activeAccount === 'personal' && (
          <>
            <Text style={styles.sectionTitle}>Quick Actions (Free)</Text>
            <View style={styles.quickActions}>
              {quickActions.map(action => (
                <TouchableOpacity key={action.label} style={styles.quickAction} onPress={() => router.push(action.route as any)}>
                  <View style={[styles.quickIcon, { backgroundColor: action.color }]}>
                    <Ionicons name={action.icon as any} size={24} color={COLORS.textPrimary} />
                  </View>
                  <Text style={styles.quickLabel}>{action.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        )}

        {activeAccount === 'business' && hasBusinessAccount && (
          <>
            <Text style={styles.sectionTitle}>Sell Your Content</Text>
            <View style={styles.sellOptions}>
              <TouchableOpacity style={styles.sellOption} onPress={() => router.push('/sell')}>
                <Ionicons name="musical-notes" size={24} color={COLORS.primary} />
                <Text style={styles.sellOptionText}>Sell Music</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sellOption} onPress={() => router.push('/beats')}>
                <Ionicons name="disc" size={24} color={COLORS.secondary} />
                <Text style={styles.sellOptionText}>Sell Beats</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sellOption} onPress={() => router.push('/collaborations')}>
                <Ionicons name="people" size={24} color={COLORS.gold} />
                <Text style={styles.sellOptionText}>Features</Text>
              </TouchableOpacity>
            </View>
          </>
        )}

        <Text style={styles.sectionTitle}>Services</Text>
        {services.map(service => (
          <TouchableOpacity 
            key={service.label} 
            style={[styles.serviceItem, service.premium && !isPremium && styles.serviceDisabled]} 
            onPress={() => {
              if (service.premium && !isPremium) {
                Alert.alert('Premium Required', 'Upgrade to Premium to access this feature', [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Upgrade', onPress: () => router.push('/premium') }
                ]);
              } else {
                router.push(service.route as any);
              }
            }}
          >
            <View style={styles.serviceIcon}>
              <Ionicons name={service.icon as any} size={24} color={service.premium && !isPremium ? COLORS.textMuted : COLORS.primary} />
            </View>
            <View style={styles.serviceInfo}>
              <Text style={[styles.serviceName, service.premium && !isPremium && styles.serviceNameDisabled]}>{service.label}</Text>
              <Text style={styles.servicePrice}>{service.price > 0 ? `$${service.price}` : 'Free'}</Text>
            </View>
            {service.premium && !isPremium && (
              <View style={styles.premiumTag}>
                <Text style={styles.premiumTagText}>PREMIUM</Text>
              </View>
            )}
            <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
          </TouchableOpacity>
        ))}

        <TouchableOpacity style={styles.historyToggle} onPress={() => setShowHistory(!showHistory)}>
          <Text style={styles.historyTitle}>Transaction History</Text>
          <Ionicons name={showHistory ? 'chevron-up' : 'chevron-down'} size={20} color={COLORS.textMuted} />
        </TouchableOpacity>

        {showHistory && (
          <View style={styles.historyList}>
            {transactions.length === 0 ? (
              <Text style={styles.noHistory}>No transactions yet</Text>
            ) : (
              transactions.slice(-10).reverse().map(tx => (
                <View key={tx.id} style={styles.txItem}>
                  <Ionicons name={tx.type === 'receive' || tx.type === 'sale' ? 'arrow-down' : 'arrow-up'} size={20} color={tx.type === 'receive' || tx.type === 'sale' ? COLORS.success : COLORS.error} />
                  <View style={styles.txInfo}>
                    <Text style={styles.txDesc}>{tx.description}</Text>
                    <Text style={styles.txDate}>{new Date(tx.timestamp).toLocaleDateString()}</Text>
                  </View>
                  <Text style={[styles.txAmount, { color: tx.type === 'receive' || tx.type === 'sale' ? COLORS.success : COLORS.error }]}>
                    {tx.type === 'receive' || tx.type === 'sale' ? '+' : '-'}${tx.amount.toFixed(2)}
                  </Text>
                </View>
              ))
            )}
          </View>
        )}

        <View style={styles.feeNote}>
          <Ionicons name="information-circle" size={16} color={COLORS.textMuted} />
          <Text style={styles.feeText}>
            {activeAccount === 'personal' 
              ? 'Personal Account: $1/month subscription. No fees on transfers between users.'
              : 'Business Account: 20¢ fee per $1 on all sales (music, beats, features). 1% fee on instant payouts.'}
          </Text>
        </View>
      </ScrollView>

      {/* Add Funds Modal */}
      <Modal visible={showAddFunds} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Funds to {activeAccount === 'personal' ? 'Personal' : 'Business'}</Text>
              <TouchableOpacity onPress={() => setShowAddFunds(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.amountGrid}>
              {ADD_AMOUNTS.map(amount => (
                <TouchableOpacity 
                  key={amount} 
                  style={[styles.amountBtn, selectedAmount === amount && !customAmount && styles.amountBtnActive]}
                  onPress={() => { setSelectedAmount(amount); setCustomAmount(''); }}
                >
                  <Text style={[styles.amountText, selectedAmount === amount && !customAmount && styles.amountTextActive]}>${amount}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.customAmountContainer}>
              <Text style={styles.customLabel}>Or enter custom amount:</Text>
              <TextInput
                style={styles.customInput}
                value={customAmount}
                onChangeText={setCustomAmount}
                placeholder="$0.00"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="decimal-pad"
              />
            </View>

            {paymentMethods.length > 0 && (
              <View style={styles.checkoutSummary}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Subtotal</Text>
                  <Text style={styles.summaryValue}>${(customAmount ? parseFloat(customAmount) : selectedAmount).toFixed(2)}</Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Processing Fee</Text>
                  <Text style={styles.summaryValue}>-${feePreview.fee.toFixed(2)}</Text>
                </View>
                <View style={[styles.summaryRow, styles.summaryTotal]}>
                  <Text style={styles.summaryLabelBold}>You'll Receive</Text>
                  <Text style={styles.summaryValueBold}>${feePreview.net.toFixed(2)}</Text>
                </View>
                <View style={styles.paymentMethodRow}>
                  <Ionicons name="card" size={16} color={COLORS.primary} />
                  <Text style={styles.paymentMethodText}>{paymentMethods.find(m => m.isDefault)?.name || 'Default Card'}</Text>
                </View>
              </View>
            )}

            <TouchableOpacity 
              style={[styles.confirmBtn, isProcessing && styles.confirmBtnDisabled]} 
              onPress={handleAddFundsConfirm}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <ActivityIndicator color={COLORS.textPrimary} />
              ) : (
                <>
                  <Ionicons name="lock-closed" size={18} color={COLORS.textPrimary} />
                  <Text style={styles.confirmBtnText}>Pay ${customAmount || selectedAmount}</Text>
                </>
              )}
            </TouchableOpacity>

            <View style={styles.secureNote}>
              <Ionicons name="shield-checkmark" size={14} color={COLORS.success} />
              <Text style={styles.secureText}>Secured by Stripe</Text>
            </View>
          </View>
        </View>
      </Modal>

      {/* Add Payment Method Modal */}
      <Modal visible={showAddPayment} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '90%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Payment Method</Text>
              <TouchableOpacity onPress={() => setShowAddPayment(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.paymentTypesList}>
              <Text style={styles.paymentSectionLabel}>Select Type</Text>
              {PAYMENT_TYPES.map(type => (
                <TouchableOpacity 
                  key={type.id}
                  style={[styles.paymentTypeItem, selectedPaymentType === type.id && styles.paymentTypeActive]}
                  onPress={() => setSelectedPaymentType(type.id)}
                >
                  <Ionicons name={type.icon as any} size={24} color={type.color} />
                  <View style={styles.paymentTypeInfo}>
                    <Text style={styles.paymentTypeName}>{type.name}</Text>
                    <Text style={styles.paymentTypeFee}>Fee: {type.fee}</Text>
                  </View>
                  {selectedPaymentType === type.id && (
                    <Ionicons name="checkmark-circle" size={24} color={COLORS.success} />
                  )}
                </TouchableOpacity>
              ))}

              {selectedPaymentType === 'card' && (
                <View style={styles.cardForm}>
                  <Text style={styles.formSectionLabel}>Card Details</Text>
                  <TextInput
                    style={styles.cardInput}
                    value={cardNumber}
                    onChangeText={(text) => setCardNumber(formatCardNumber(text))}
                    placeholder="Card Number"
                    placeholderTextColor={COLORS.textMuted}
                    keyboardType="number-pad"
                    maxLength={19}
                  />
                  <View style={styles.cardRow}>
                    <TextInput
                      style={[styles.cardInput, { flex: 1 }]}
                      value={cardExpiry}
                      onChangeText={(text) => setCardExpiry(formatExpiry(text))}
                      placeholder="MM/YY"
                      placeholderTextColor={COLORS.textMuted}
                      keyboardType="number-pad"
                      maxLength={5}
                    />
                    <TextInput
                      style={[styles.cardInput, { flex: 1 }]}
                      value={cardCVV}
                      onChangeText={setCardCVV}
                      placeholder="CVV"
                      placeholderTextColor={COLORS.textMuted}
                      keyboardType="number-pad"
                      maxLength={4}
                      secureTextEntry
                    />
                  </View>
                  <TextInput
                    style={styles.cardInput}
                    value={cardName}
                    onChangeText={setCardName}
                    placeholder="Cardholder Name"
                    placeholderTextColor={COLORS.textMuted}
                    autoCapitalize="words"
                  />
                </View>
              )}

              {selectedPaymentType === 'bank' && (
                <View style={styles.cardForm}>
                  <Text style={styles.formSectionLabel}>Bank Account Details</Text>
                  <TextInput
                    style={styles.cardInput}
                    value={routingNumber}
                    onChangeText={setRoutingNumber}
                    placeholder="Routing Number (9 digits)"
                    placeholderTextColor={COLORS.textMuted}
                    keyboardType="number-pad"
                    maxLength={9}
                  />
                  <TextInput
                    style={styles.cardInput}
                    value={accountNumber}
                    onChangeText={setAccountNumber}
                    placeholder="Account Number"
                    placeholderTextColor={COLORS.textMuted}
                    keyboardType="number-pad"
                  />
                  <TextInput
                    style={styles.cardInput}
                    value={accountName}
                    onChangeText={setAccountName}
                    placeholder="Account Holder Name"
                    placeholderTextColor={COLORS.textMuted}
                    autoCapitalize="words"
                  />
                </View>
              )}
            </ScrollView>

            <TouchableOpacity style={styles.confirmBtn} onPress={handleAddPaymentMethod}>
              <Text style={styles.confirmBtnText}>Add Payment Method</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Cash Out / Payout Modal */}
      <Modal visible={showPayout} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Cash Out from {activeAccount === 'personal' ? 'Personal' : 'Business'}</Text>
              <TouchableOpacity onPress={() => setShowPayout(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <View style={styles.payoutBalance}>
              <Text style={styles.payoutLabel}>Available Balance</Text>
              <Text style={styles.payoutValue}>${getCurrentBalance().toFixed(2)}</Text>
            </View>

            {activeAccount === 'business' && (
              <View style={styles.businessFeeNote}>
                <Ionicons name="information-circle" size={16} color={COLORS.gold} />
                <Text style={styles.businessFeeText}>Business payouts: 20¢ per $1 platform fee applies</Text>
              </View>
            )}

            <Text style={styles.payoutSectionLabel}>Select Amount</Text>
            <View style={styles.amountGrid}>
              {PAYOUT_AMOUNTS.filter(a => a <= getCurrentBalance()).map(amount => (
                <TouchableOpacity 
                  key={amount} 
                  style={[styles.amountBtn, selectedPayoutPreset === amount && !payoutAmount && styles.amountBtnActive]}
                  onPress={() => { setSelectedPayoutPreset(amount); setPayoutAmount(''); }}
                >
                  <Text style={[styles.amountText, selectedPayoutPreset === amount && !payoutAmount && styles.amountTextActive]}>${amount}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.customLabel}>Or enter custom amount:</Text>
            <TextInput
              style={styles.payoutInput}
              value={payoutAmount}
              onChangeText={(text) => { setPayoutAmount(text); setSelectedPayoutPreset(null); }}
              placeholder="Enter amount"
              placeholderTextColor={COLORS.textMuted}
              keyboardType="decimal-pad"
            />

            {paymentMethods.length > 0 && (
              <>
                <Text style={styles.payoutSectionLabel}>Cash Out To</Text>
                {paymentMethods.map(method => {
                  const isInstant = method.type === 'card';
                  return (
                    <TouchableOpacity 
                      key={method.id}
                      style={[
                        styles.payoutMethodItem, 
                        (selectedPayoutMethod === method.id || (!selectedPayoutMethod && method.isDefault)) && styles.payoutMethodActive
                      ]}
                      onPress={() => setSelectedPayoutMethod(method.id)}
                    >
                      <Ionicons name={PAYMENT_TYPES.find(t => t.id === method.type)?.icon as any || 'card'} size={20} color={COLORS.primary} />
                      <View style={styles.payoutMethodInfo}>
                        <Text style={styles.payoutMethodName}>{method.name}</Text>
                        <Text style={styles.payoutMethodSpeed}>
                          {isInstant ? 'Instant (+1% fee)' : 'Free (1-2 days)'}
                        </Text>
                      </View>
                      {(selectedPayoutMethod === method.id || (!selectedPayoutMethod && method.isDefault)) && (
                        <Ionicons name="checkmark-circle" size={20} color={COLORS.success} />
                      )}
                    </TouchableOpacity>
                  );
                })}
              </>
            )}

            <TouchableOpacity 
              style={[styles.confirmBtn, isProcessing && styles.confirmBtnDisabled]} 
              onPress={handlePayout}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <ActivityIndicator color={COLORS.textPrimary} />
              ) : (
                <>
                  <Ionicons name="arrow-up" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.confirmBtnText}>Cash Out</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Account Info Modal */}
      <Modal visible={showAccountInfo} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Account Types</Text>
              <TouchableOpacity onPress={() => setShowAccountInfo(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <View style={styles.accountTypeCard}>
              <View style={styles.accountTypeHeader}>
                <Ionicons name="person" size={24} color={COLORS.primary} />
                <Text style={styles.accountTypeName}>Personal Account</Text>
              </View>
              <View style={styles.accountTypeFeatures}>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Send money to friends & family</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Receive money from others</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Sponsor other artists</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>No transaction fees</Text>
                </View>
              </View>
              <View style={styles.accountTypePricing}>
                <Text style={styles.pricingLabel}>Monthly Fee:</Text>
                <Text style={styles.pricingValue}>$1/month</Text>
              </View>
            </View>

            <View style={[styles.accountTypeCard, styles.businessCard]}>
              <View style={styles.accountTypeHeader}>
                <Ionicons name="briefcase" size={24} color={COLORS.gold} />
                <Text style={styles.accountTypeName}>Business Account</Text>
              </View>
              <View style={styles.accountTypeFeatures}>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Sell music, songs & albums</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Sell beats & instrumentals</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Offer features & collaborations</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="checkmark-circle" size={16} color={COLORS.success} />
                  <Text style={styles.featureText}>Accept payments from fans</Text>
                </View>
              </View>
              <View style={styles.accountTypePricing}>
                <Text style={styles.pricingLabel}>Platform Fee:</Text>
                <Text style={styles.pricingValue}>20¢ per $1 earned</Text>
              </View>
              <Text style={styles.noMonthlyFee}>No monthly fee!</Text>
            </View>

            <TouchableOpacity style={styles.confirmBtn} onPress={() => setShowAccountInfo(false)}>
              <Text style={styles.confirmBtnText}>Got It</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Open Business Account Modal */}
      <Modal visible={showOpenAccount} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Open Business Account</Text>
              <TouchableOpacity onPress={() => setShowOpenAccount(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <View style={styles.openAccountContent}>
              <Ionicons name="briefcase" size={64} color={COLORS.gold} />
              <Text style={styles.openAccountTitle}>Start Selling Your Music</Text>
              <Text style={styles.openAccountDesc}>
                Open a Business Account to sell your music, beats, and offer features to other artists.
              </Text>

              <View style={styles.openAccountFeatures}>
                <View style={styles.featureRow}>
                  <Ionicons name="musical-notes" size={20} color={COLORS.primary} />
                  <Text style={styles.featureText}>Sell music & albums</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="disc" size={20} color={COLORS.secondary} />
                  <Text style={styles.featureText}>Sell beats & instrumentals</Text>
                </View>
                <View style={styles.featureRow}>
                  <Ionicons name="people" size={20} color={COLORS.gold} />
                  <Text style={styles.featureText}>Offer paid features</Text>
                </View>
              </View>

              <View style={styles.feeExplanation}>
                <Text style={styles.feeTitle}>Platform Fee Structure</Text>
                <Text style={styles.feeDesc}>20¢ per $1 earned (20%)</Text>
                <Text style={styles.feeExample}>Example: You sell a beat for $100, you receive $80</Text>
              </View>
            </View>

            <TouchableOpacity style={styles.confirmBtn} onPress={handleOpenBusinessAccount}>
              <Ionicons name="briefcase" size={20} color={COLORS.textPrimary} />
              <Text style={styles.confirmBtnText}>Open Business Account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Receipts Modal */}
      <Modal visible={showReceipts} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '80%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Receipts</Text>
              <TouchableOpacity onPress={() => setShowReceipts(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.receiptsList}>
              {receipts.length === 0 ? (
                <Text style={styles.noReceipts}>No receipts yet</Text>
              ) : (
                receipts.slice().reverse().map(receipt => (
                  <View key={receipt.id} style={styles.receiptItem}>
                    <View style={styles.receiptHeader}>
                      <Text style={styles.receiptType}>{receipt.type.toUpperCase()}</Text>
                      <Text style={[styles.receiptStatus, receipt.status === 'completed' ? styles.statusCompleted : styles.statusPending]}>
                        {receipt.status}
                      </Text>
                    </View>
                    <Text style={styles.receiptDesc}>{receipt.description}</Text>
                    <View style={styles.receiptFooter}>
                      <Text style={styles.receiptDate}>{new Date(receipt.timestamp).toLocaleString()}</Text>
                      <Text style={styles.receiptAmount}>${receipt.amount.toFixed(2)}</Text>
                    </View>
                    {receipt.fee > 0 && (
                      <Text style={styles.receiptFee}>Fee: ${receipt.fee.toFixed(2)}</Text>
                    )}
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  headerActions: { flexDirection: 'row', gap: 16 },
  title: { fontSize: 32, fontWeight: '800', color: COLORS.textPrimary },
  content: { padding: 20, paddingBottom: 180 },
  // Account Selector
  accountSelector: { flexDirection: 'row', backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 4, marginBottom: 12 },
  accountTab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, borderRadius: 10 },
  accountTabActive: { backgroundColor: COLORS.primary },
  accountTabDisabled: { opacity: 0.8 },
  accountTabText: { color: COLORS.textMuted, fontWeight: '600' },
  accountTabTextActive: { color: COLORS.textPrimary },
  accountInfoBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginBottom: 16 },
  accountInfoText: { flex: 1, color: COLORS.textSecondary, fontSize: 13 },
  // Balance Card
  balanceCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 20, marginBottom: 16, borderWidth: 1, borderColor: COLORS.primary },
  balanceLabel: { color: COLORS.textMuted, fontSize: 14 },
  balanceAmount: { color: COLORS.textPrimary, fontSize: 40, fontWeight: '800', marginVertical: 8 },
  balanceDetails: { flexDirection: 'row', gap: 24, marginTop: 8 },
  balanceDetail: {},
  detailLabel: { color: COLORS.textMuted, fontSize: 12 },
  detailValue: { color: COLORS.textPrimary, fontWeight: '600' },
  frozenBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(239,68,68,0.2)', padding: 12, borderRadius: 12, marginBottom: 16 },
  frozenText: { color: COLORS.error, flex: 1 },
  infiniteCard: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(234,179,8,0.1)', padding: 16, borderRadius: 12, marginBottom: 16, borderWidth: 1, borderColor: COLORS.gold },
  infiniteContent: { flex: 1 },
  infiniteTitle: { color: COLORS.gold, fontWeight: '700', fontSize: 16 },
  infiniteDesc: { color: COLORS.textMuted, fontSize: 13 },
  balanceActions: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  balanceAction: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, paddingVertical: 14, borderRadius: 12 },
  payoutAction: { backgroundColor: COLORS.primary },
  balanceActionText: { color: COLORS.textPrimary, fontWeight: '600' },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textPrimary, marginTop: 8, marginBottom: 4 },
  sectionSubtitle: { color: COLORS.textMuted, fontSize: 13, marginBottom: 12 },
  // Sell Options
  sellOptions: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  sellOption: { flex: 1, backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, alignItems: 'center', gap: 8 },
  sellOptionText: { color: COLORS.textPrimary, fontWeight: '600', fontSize: 12 },
  addPaymentCard: { backgroundColor: COLORS.backgroundCard, padding: 24, borderRadius: 12, alignItems: 'center', borderWidth: 2, borderStyle: 'dashed', borderColor: COLORS.primary },
  addPaymentText: { color: COLORS.primary, fontWeight: '600', marginTop: 8 },
  addPaymentSubtext: { color: COLORS.textMuted, fontSize: 12, marginTop: 4 },
  paymentMethodsList: { gap: 8 },
  paymentMethod: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 8 },
  paymentMethodDefault: { borderWidth: 1, borderColor: COLORS.primary },
  paymentMethodInfo: { flex: 1, marginLeft: 12 },
  paymentMethodName: { color: COLORS.textPrimary, fontWeight: '600' },
  paymentMethodLast4: { color: COLORS.textMuted, fontSize: 13 },
  defaultBadge: { backgroundColor: COLORS.primary, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  defaultBadgeText: { color: COLORS.textPrimary, fontSize: 10, fontWeight: '700' },
  addMorePayment: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12 },
  addMoreText: { color: COLORS.primary, fontWeight: '600' },
  quickActions: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  quickAction: { alignItems: 'center' },
  quickIcon: { width: 56, height: 56, borderRadius: 28, justifyContent: 'center', alignItems: 'center' },
  quickLabel: { color: COLORS.textSecondary, fontSize: 12, marginTop: 8 },
  serviceItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 8 },
  serviceDisabled: { opacity: 0.6 },
  serviceIcon: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.backgroundLight, justifyContent: 'center', alignItems: 'center' },
  serviceInfo: { flex: 1, marginLeft: 12 },
  serviceName: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '600' },
  serviceNameDisabled: { color: COLORS.textMuted },
  servicePrice: { color: COLORS.success, fontSize: 14 },
  premiumTag: { backgroundColor: COLORS.gold, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8, marginRight: 8 },
  premiumTagText: { color: COLORS.background, fontSize: 10, fontWeight: '700' },
  historyToggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 16, paddingVertical: 12 },
  historyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textPrimary },
  historyList: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 12 },
  noHistory: { color: COLORS.textMuted, textAlign: 'center', paddingVertical: 20 },
  txItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  txInfo: { flex: 1, marginLeft: 12 },
  txDesc: { color: COLORS.textPrimary, fontSize: 14 },
  txDate: { color: COLORS.textMuted, fontSize: 12 },
  txAmount: { fontSize: 16, fontWeight: '700' },
  feeNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginTop: 24, padding: 12, backgroundColor: COLORS.backgroundCard, borderRadius: 12 },
  feeText: { color: COLORS.textMuted, fontSize: 12, flex: 1 },
  businessFeeNote: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(234,179,8,0.1)', padding: 12, borderRadius: 8, marginBottom: 16 },
  businessFeeText: { color: COLORS.gold, fontSize: 13, flex: 1 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  amountGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  amountBtn: { width: '30%', backgroundColor: COLORS.backgroundCard, paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  amountBtnActive: { backgroundColor: COLORS.primary },
  amountText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  amountTextActive: { color: COLORS.textPrimary },
  customAmountContainer: { marginTop: 20 },
  customLabel: { color: COLORS.textMuted, marginBottom: 8 },
  customInput: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, color: COLORS.textPrimary, fontSize: 18 },
  checkoutSummary: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, marginTop: 20 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryTotal: { borderTopWidth: 1, borderTopColor: COLORS.backgroundLight, paddingTop: 12, marginTop: 8 },
  summaryLabel: { color: COLORS.textMuted },
  summaryValue: { color: COLORS.textPrimary },
  summaryLabelBold: { color: COLORS.textPrimary, fontWeight: '700' },
  summaryValueBold: { color: COLORS.success, fontWeight: '700', fontSize: 18 },
  paymentMethodRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  paymentMethodText: { color: COLORS.textSecondary },
  confirmBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, marginTop: 20, marginBottom: 10 },
  confirmBtnDisabled: { opacity: 0.7 },
  confirmBtnText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  secureNote: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginBottom: 10 },
  secureText: { color: COLORS.textMuted, fontSize: 12 },
  paymentTypesList: { maxHeight: 400 },
  paymentSectionLabel: { color: COLORS.textMuted, fontSize: 14, marginBottom: 12 },
  paymentTypeItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 8 },
  paymentTypeActive: { borderWidth: 1, borderColor: COLORS.primary },
  paymentTypeInfo: { flex: 1, marginLeft: 12 },
  paymentTypeName: { color: COLORS.textPrimary, fontSize: 16 },
  paymentTypeFee: { color: COLORS.textMuted, fontSize: 12 },
  cardForm: { marginTop: 16 },
  formSectionLabel: { color: COLORS.textSecondary, fontSize: 14, fontWeight: '600', marginBottom: 12 },
  cardInput: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, color: COLORS.textPrimary, fontSize: 16, marginBottom: 12 },
  cardRow: { flexDirection: 'row', gap: 12 },
  payoutBalance: { alignItems: 'center', marginBottom: 16 },
  payoutLabel: { color: COLORS.textMuted },
  payoutValue: { color: COLORS.textPrimary, fontSize: 32, fontWeight: '800' },
  payoutSectionLabel: { color: COLORS.textMuted, fontSize: 14, marginTop: 16, marginBottom: 8 },
  payoutInput: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, color: COLORS.textPrimary, fontSize: 24, textAlign: 'center' },
  payoutMethodItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginBottom: 8 },
  payoutMethodActive: { borderWidth: 1, borderColor: COLORS.primary },
  payoutMethodInfo: { flex: 1, marginLeft: 12 },
  payoutMethodName: { color: COLORS.textPrimary },
  payoutMethodSpeed: { color: COLORS.textMuted, fontSize: 12 },
  // Account Type Cards
  accountTypeCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 20, marginBottom: 16 },
  businessCard: { borderWidth: 1, borderColor: COLORS.gold },
  accountTypeHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  accountTypeName: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  accountTypeFeatures: { gap: 8, marginBottom: 16 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  featureText: { color: COLORS.textSecondary, fontSize: 14 },
  accountTypePricing: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 16, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  pricingLabel: { color: COLORS.textMuted },
  pricingValue: { color: COLORS.textPrimary, fontWeight: '700' },
  noMonthlyFee: { color: COLORS.success, fontSize: 12, marginTop: 8, textAlign: 'center' },
  // Open Account
  openAccountContent: { alignItems: 'center', paddingVertical: 20 },
  openAccountTitle: { color: COLORS.textPrimary, fontSize: 22, fontWeight: '700', marginTop: 16 },
  openAccountDesc: { color: COLORS.textMuted, textAlign: 'center', marginTop: 8, paddingHorizontal: 20 },
  openAccountFeatures: { width: '100%', gap: 12, marginTop: 24 },
  feeExplanation: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginTop: 24, width: '100%' },
  feeTitle: { color: COLORS.textPrimary, fontWeight: '700', marginBottom: 8 },
  feeDesc: { color: COLORS.gold, fontSize: 18, fontWeight: '700' },
  feeExample: { color: COLORS.textMuted, fontSize: 13, marginTop: 8 },
  receiptsList: { maxHeight: 400 },
  noReceipts: { color: COLORS.textMuted, textAlign: 'center', paddingVertical: 40 },
  receiptItem: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 12 },
  receiptHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  receiptType: { color: COLORS.primary, fontWeight: '700', fontSize: 12 },
  receiptStatus: { fontSize: 12, fontWeight: '600' },
  statusCompleted: { color: COLORS.success },
  statusPending: { color: COLORS.gold },
  receiptDesc: { color: COLORS.textPrimary, marginTop: 8 },
  receiptFooter: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
  receiptDate: { color: COLORS.textMuted, fontSize: 12 },
  receiptAmount: { color: COLORS.textPrimary, fontWeight: '700' },
  receiptFee: { color: COLORS.textMuted, fontSize: 12, marginTop: 4 },
});
