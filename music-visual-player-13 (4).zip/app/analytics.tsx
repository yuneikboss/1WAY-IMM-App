import React, { useState, useEffect } from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Alert,
  Share,
  ActivityIndicator,
  RefreshControl,
  Modal,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import LineChart from './components/charts/LineChart';
import BarChart from './components/charts/BarChart';
import PieChart from './components/charts/PieChart';
import ShareableCard, { CardTemplate } from './components/ShareableCard';
import { getAnalyticsData, exportAnalyticsReport, AnalyticsData } from './data/analytics';
import { 
  Goal, 
  GoalType, 
  GOAL_TEMPLATES, 
  getSampleGoals, 
  generateAISuggestions, 
  formatGoalValue, 
  getGoalProgress,
  getGoalColor,
  AISuggestion 
} from './data/goals';
import socialSharingService from './services/SocialSharingService';
import { useAuth } from './context/AuthContext';

type TimeRange = '7d' | '30d' | '90d' | '1y' | 'all';
type TabType = 'overview' | 'earnings' | 'audience' | 'contests' | 'goals';

export default function AnalyticsScreen() {
  const router = useRouter();
  const { profile, addNotification } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [aiSuggestions, setAiSuggestions] = useState<AISuggestion[]>([]);
  const [showNewGoalModal, setShowNewGoalModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedShareType, setSelectedShareType] = useState<CardTemplate>('milestone');
  const [newGoal, setNewGoal] = useState<{
    type: GoalType;
    targetValue: string;
    days: string;
  }>({ type: 'plays', targetValue: '', days: '30' });

  useEffect(() => {
    loadData();
  }, [timeRange]);

  useEffect(() => {
    if (goals.length > 0 && data) {
      const suggestions = goals.flatMap(goal => generateAISuggestions(goal, data));
      setAiSuggestions(suggestions.slice(0, 6));
    }
  }, [goals, data]);

  const loadData = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    setData(getAnalyticsData());
    setGoals(getSampleGoals());
    setLoading(false);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleExport = async (format: 'csv' | 'json') => {
    if (!data) return;
    
    try {
      const reportContent = exportAnalyticsReport(data, format);
      await Share.share({
        message: reportContent,
        title: `Analytics Report.${format}`,
      });
    } catch (error) {
      Alert.alert('Export Failed', 'Unable to export the report. Please try again.');
    }
  };

  const showExportOptions = () => {
    Alert.alert(
      'Export Report',
      'Choose export format',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'CSV', onPress: () => handleExport('csv') },
        { text: 'JSON', onPress: () => handleExport('json') },
      ]
    );
  };

  const handleCreateGoal = () => {
    const template = GOAL_TEMPLATES.find(t => t.type === newGoal.type);
    if (!template || !newGoal.targetValue) return;

    const targetValue = parseFloat(newGoal.targetValue);
    const days = parseInt(newGoal.days) || 30;
    
    const goal: Goal = {
      id: `goal_${Date.now()}`,
      type: newGoal.type,
      title: `${template.title} Goal`,
      description: `Reach ${formatGoalValue(newGoal.type, targetValue)}`,
      targetValue,
      currentValue: newGoal.type === 'plays' ? (data?.overview.totalPlays || 0) :
                    newGoal.type === 'followers' ? (data?.overview.totalFollowers || 0) :
                    newGoal.type === 'earnings' ? (data?.overview.totalEarnings || 0) :
                    newGoal.type === 'votes' ? (data?.overview.totalVotes || 0) : 10,
      startDate: Date.now(),
      endDate: Date.now() + days * 24 * 60 * 60 * 1000,
      status: 'active',
      milestones: [
        { id: 'm1', percentage: 25, reached: false, notified: false },
        { id: 'm2', percentage: 50, reached: false, notified: false },
        { id: 'm3', percentage: 75, reached: false, notified: false },
        { id: 'm4', percentage: 100, reached: false, notified: false },
      ],
      createdAt: Date.now(),
    };

    setGoals([...goals, goal]);
    setShowNewGoalModal(false);
    setNewGoal({ type: 'plays', targetValue: '', days: '30' });

    addNotification({
      type: 'system',
      title: 'Goal Created',
      message: `Your new goal "${goal.title}" has been set!`,
    });
  };

  const handleShareAchievement = async () => {
    if (!data || !profile) return;

    const shareContent = socialSharingService.generateAchievementCard(
      selectedShareType === 'milestone' ? 'milestone_plays' :
      selectedShareType === 'contest_win' ? 'contest_win' :
      selectedShareType === 'earnings' ? 'earnings' : 'followers',
      selectedShareType === 'milestone' ? data.overview.totalPlays :
      selectedShareType === 'earnings' ? data.overview.totalEarnings :
      data.overview.totalFollowers,
      profile.displayName || 'Artist'
    );

    const result = await socialSharingService.shareNative(shareContent);
    if (result.success) {
      setShowShareModal(false);
      Alert.alert('Shared!', `Your achievement was shared to ${result.platform || 'social media'}`);
    }
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatCurrency = (num: number): string => {
    return `$${num.toFixed(2)}`;
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'winner': return COLORS.gold;
      case 'finalist': return COLORS.success;
      case 'eliminated': return COLORS.error;
      case 'active': return COLORS.primary;
      default: return COLORS.textMuted;
    }
  };

  const getActivityIcon = (type: string): string => {
    switch (type) {
      case 'play': return 'play-circle';
      case 'vote': return 'heart';
      case 'purchase': return 'cart';
      case 'follow': return 'person-add';
      case 'like': return 'thumbs-up';
      default: return 'ellipse';
    }
  };

  const renderGoalsTab = () => {
    if (!data) return null;

    return (
      <>
        {/* Create Goal Button */}
        <TouchableOpacity 
          style={styles.createGoalBtn}
          onPress={() => setShowNewGoalModal(true)}
        >
          <Ionicons name="add-circle" size={24} color={COLORS.primary} />
          <Text style={styles.createGoalText}>Create New Goal</Text>
        </TouchableOpacity>

        {/* Active Goals */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Active Goals</Text>
          {goals.filter(g => g.status === 'active').map(goal => {
            const progress = getGoalProgress(goal);
            const color = getGoalColor(goal.type);
            const daysLeft = Math.ceil((goal.endDate - Date.now()) / (1000 * 60 * 60 * 24));
            
            return (
              <View key={goal.id} style={styles.goalItem}>
                <View style={styles.goalHeader}>
                  <View style={[styles.goalIcon, { backgroundColor: color + '20' }]}>
                    <Ionicons 
                      name={GOAL_TEMPLATES.find(t => t.type === goal.type)?.icon as any || 'flag'} 
                      size={20} 
                      color={color} 
                    />
                  </View>
                  <View style={styles.goalInfo}>
                    <Text style={styles.goalTitle}>{goal.title}</Text>
                    <Text style={styles.goalSubtitle}>
                      {formatGoalValue(goal.type, goal.currentValue)} / {formatGoalValue(goal.type, goal.targetValue)}
                    </Text>
                  </View>
                  <View style={styles.goalDays}>
                    <Text style={styles.goalDaysValue}>{daysLeft}</Text>
                    <Text style={styles.goalDaysLabel}>days left</Text>
                  </View>
                </View>
                <View style={styles.progressContainer}>
                  <View style={styles.progressBar}>
                    <View 
                      style={[
                        styles.progressFill, 
                        { width: `${progress}%`, backgroundColor: color }
                      ]} 
                    />
                  </View>
                  <Text style={[styles.progressText, { color }]}>{progress.toFixed(0)}%</Text>
                </View>
                {/* Milestones */}
                <View style={styles.milestones}>
                  {goal.milestones.map(milestone => (
                    <View 
                      key={milestone.id} 
                      style={[
                        styles.milestone,
                        milestone.reached && styles.milestoneReached
                      ]}
                    >
                      <Ionicons 
                        name={milestone.reached ? 'checkmark-circle' : 'ellipse-outline'} 
                        size={16} 
                        color={milestone.reached ? COLORS.success : COLORS.textMuted} 
                      />
                      <Text style={[
                        styles.milestoneText,
                        milestone.reached && styles.milestoneTextReached
                      ]}>
                        {milestone.percentage}%
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
            );
          })}
        </View>

        {/* AI Suggestions */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>AI Suggestions</Text>
            <View style={styles.aiBadge}>
              <Ionicons name="sparkles" size={14} color={COLORS.gold} />
              <Text style={styles.aiBadgeText}>AI</Text>
            </View>
          </View>
          {aiSuggestions.map(suggestion => (
            <TouchableOpacity 
              key={suggestion.id} 
              style={styles.suggestionItem}
              onPress={() => suggestion.actionUrl && router.push(suggestion.actionUrl as any)}
            >
              <View style={[
                styles.suggestionPriority,
                { backgroundColor: 
                  suggestion.priority === 'high' ? COLORS.error + '20' :
                  suggestion.priority === 'medium' ? COLORS.gold + '20' : COLORS.success + '20'
                }
              ]}>
                <Ionicons 
                  name={
                    suggestion.actionType === 'content' ? 'musical-notes' :
                    suggestion.actionType === 'engagement' ? 'chatbubbles' :
                    suggestion.actionType === 'promotion' ? 'megaphone' :
                    suggestion.actionType === 'timing' ? 'time' : 'people'
                  } 
                  size={18} 
                  color={
                    suggestion.priority === 'high' ? COLORS.error :
                    suggestion.priority === 'medium' ? COLORS.gold : COLORS.success
                  } 
                />
              </View>
              <View style={styles.suggestionContent}>
                <Text style={styles.suggestionTitle}>{suggestion.title}</Text>
                <Text style={styles.suggestionDesc} numberOfLines={2}>
                  {suggestion.description}
                </Text>
                <View style={styles.suggestionImpact}>
                  <Ionicons name="trending-up" size={12} color={COLORS.success} />
                  <Text style={styles.suggestionImpactText}>{suggestion.estimatedImpact}</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Share Achievements */}
        <TouchableOpacity 
          style={styles.shareAchievementsBtn}
          onPress={() => setShowShareModal(true)}
        >
          <Ionicons name="share-social" size={24} color="#fff" />
          <Text style={styles.shareAchievementsBtnText}>Share Your Achievements</Text>
        </TouchableOpacity>
      </>
    );
  };

  const renderOverviewTab = () => {
    if (!data) return null;

    return (
      <>
        {/* Stats Cards */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <Ionicons name="play-circle" size={24} color={COLORS.primary} />
              <View style={[styles.changeBadge, data.overview.playsChange >= 0 ? styles.positiveChange : styles.negativeChange]}>
                <Ionicons name={data.overview.playsChange >= 0 ? 'trending-up' : 'trending-down'} size={12} color={data.overview.playsChange >= 0 ? COLORS.success : COLORS.error} />
                <Text style={[styles.changeText, data.overview.playsChange >= 0 ? styles.positiveText : styles.negativeText]}>
                  {Math.abs(data.overview.playsChange)}%
                </Text>
              </View>
            </View>
            <Text style={styles.statValue}>{formatNumber(data.overview.totalPlays)}</Text>
            <Text style={styles.statLabel}>Total Plays</Text>
          </View>

          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <Ionicons name="heart" size={24} color={COLORS.accent} />
              <View style={[styles.changeBadge, data.overview.votesChange >= 0 ? styles.positiveChange : styles.negativeChange]}>
                <Ionicons name={data.overview.votesChange >= 0 ? 'trending-up' : 'trending-down'} size={12} color={data.overview.votesChange >= 0 ? COLORS.success : COLORS.error} />
                <Text style={[styles.changeText, data.overview.votesChange >= 0 ? styles.positiveText : styles.negativeText]}>
                  {Math.abs(data.overview.votesChange)}%
                </Text>
              </View>
            </View>
            <Text style={styles.statValue}>{formatNumber(data.overview.totalVotes)}</Text>
            <Text style={styles.statLabel}>Total Votes</Text>
          </View>

          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <Ionicons name="cash" size={24} color={COLORS.success} />
              <View style={[styles.changeBadge, data.overview.earningsChange >= 0 ? styles.positiveChange : styles.negativeChange]}>
                <Ionicons name={data.overview.earningsChange >= 0 ? 'trending-up' : 'trending-down'} size={12} color={data.overview.earningsChange >= 0 ? COLORS.success : COLORS.error} />
                <Text style={[styles.changeText, data.overview.earningsChange >= 0 ? styles.positiveText : styles.negativeText]}>
                  {Math.abs(data.overview.earningsChange)}%
                </Text>
              </View>
            </View>
            <Text style={styles.statValue}>{formatCurrency(data.overview.totalEarnings)}</Text>
            <Text style={styles.statLabel}>Total Earnings</Text>
          </View>

          <View style={styles.statCard}>
            <View style={styles.statHeader}>
              <Ionicons name="people" size={24} color={COLORS.secondary} />
              <View style={[styles.changeBadge, data.overview.followersChange >= 0 ? styles.positiveChange : styles.negativeChange]}>
                <Ionicons name={data.overview.followersChange >= 0 ? 'trending-up' : 'trending-down'} size={12} color={data.overview.followersChange >= 0 ? COLORS.success : COLORS.error} />
                <Text style={[styles.changeText, data.overview.followersChange >= 0 ? styles.positiveText : styles.negativeText]}>
                  {Math.abs(data.overview.followersChange)}%
                </Text>
              </View>
            </View>
            <Text style={styles.statValue}>{formatNumber(data.overview.totalFollowers)}</Text>
            <Text style={styles.statLabel}>Followers</Text>
          </View>
        </View>

        {/* Plays Over Time Chart */}
        <View style={styles.chartCard}>
          <LineChart
            data={data.playsOverTime}
            title="Plays Over Time"
            color={COLORS.primary}
            height={220}
            showValues={false}
          />
        </View>

        {/* Votes Over Time Chart */}
        <View style={styles.chartCard}>
          <LineChart
            data={data.votesOverTime}
            title="Votes Received"
            color={COLORS.accent}
            height={220}
            showValues={false}
          />
        </View>

        {/* Top Tracks */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Top Performing Tracks</Text>
          {data.topTracks.map((track, index) => (
            <View key={track.id} style={styles.trackItem}>
              <View style={styles.trackRank}>
                <Text style={styles.rankText}>{index + 1}</Text>
              </View>
              <View style={styles.trackInfo}>
                <Text style={styles.trackTitle}>{track.title}</Text>
                <View style={styles.trackStats}>
                  <View style={styles.trackStat}>
                    <Ionicons name="play" size={12} color={COLORS.textMuted} />
                    <Text style={styles.trackStatText}>{formatNumber(track.plays)}</Text>
                  </View>
                  <View style={styles.trackStat}>
                    <Ionicons name="heart" size={12} color={COLORS.textMuted} />
                    <Text style={styles.trackStatText}>{formatNumber(track.votes)}</Text>
                  </View>
                  <View style={styles.trackStat}>
                    <Ionicons name="cash" size={12} color={COLORS.textMuted} />
                    <Text style={styles.trackStatText}>{formatCurrency(track.earnings)}</Text>
                  </View>
                </View>
              </View>
            </View>
          ))}
        </View>

        {/* Recent Activity */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          {data.recentActivity.slice(0, 5).map((activity, index) => (
            <View key={index} style={styles.activityItem}>
              <View style={[styles.activityIcon, { backgroundColor: COLORS.backgroundLight }]}>
                <Ionicons name={getActivityIcon(activity.type) as any} size={16} color={COLORS.primary} />
              </View>
              <View style={styles.activityInfo}>
                <Text style={styles.activityText}>{activity.description}</Text>
                <Text style={styles.activityTime}>
                  {new Date(activity.timestamp).toLocaleDateString()}
                </Text>
              </View>
              {activity.value && (
                <Text style={styles.activityValue}>
                  {activity.type === 'purchase' ? formatCurrency(activity.value) : `+${activity.value}`}
                </Text>
              )}
            </View>
          ))}
        </View>
      </>
    );
  };

  const renderEarningsTab = () => {
    if (!data) return null;

    return (
      <>
        <View style={styles.earningsHeader}>
          <Text style={styles.earningsLabel}>Total Earnings</Text>
          <Text style={styles.earningsValue}>{formatCurrency(data.overview.totalEarnings)}</Text>
          <View style={styles.earningsChange}>
            <Ionicons name="trending-up" size={16} color={COLORS.success} />
            <Text style={styles.earningsChangeText}>+{data.overview.earningsChange}% from last month</Text>
          </View>
        </View>

        <View style={styles.chartCard}>
          <LineChart
            data={data.earningsOverTime}
            title="Earnings Over Time"
            color={COLORS.success}
            height={220}
            suffix="$"
            showValues={false}
          />
        </View>

        <View style={styles.chartCard}>
          <PieChart
            data={data.earningsBreakdown}
            title="Earnings Breakdown"
            size={140}
            donut={true}
            centerLabel="Total"
            centerValue={formatCurrency(data.overview.totalEarnings)}
          />
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Earnings by Source</Text>
          {data.earningsBreakdown.map((item, index) => (
            <View key={index} style={styles.earningSourceItem}>
              <View style={[styles.sourceIndicator, { backgroundColor: item.color }]} />
              <Text style={styles.sourceName}>{item.label}</Text>
              <Text style={styles.sourceValue}>{formatCurrency(item.value)}</Text>
              <Text style={styles.sourcePercent}>
                {((item.value / data.overview.totalEarnings) * 100).toFixed(1)}%
              </Text>
            </View>
          ))}
        </View>
      </>
    );
  };

  const renderAudienceTab = () => {
    if (!data) return null;

    return (
      <>
        <View style={styles.audienceHeader}>
          <Ionicons name="people" size={32} color={COLORS.primary} />
          <Text style={styles.audienceValue}>{formatNumber(data.overview.totalFollowers)}</Text>
          <Text style={styles.audienceLabel}>Total Followers</Text>
        </View>

        <View style={styles.chartCard}>
          <PieChart
            data={data.fanDemographics.age}
            title="Age Distribution"
            size={140}
            donut={true}
          />
        </View>

        <View style={styles.chartCard}>
          <PieChart
            data={data.fanDemographics.gender}
            title="Gender Distribution"
            size={140}
            donut={true}
          />
        </View>

        <View style={styles.chartCard}>
          <BarChart
            data={data.fanDemographics.location}
            title="Top Locations"
            horizontal={true}
            color={COLORS.primary}
            suffix="%"
          />
        </View>

        <View style={styles.chartCard}>
          <BarChart
            data={data.peakListeningTimes}
            title="Peak Listening Times"
            height={180}
            color={COLORS.secondary}
          />
        </View>
      </>
    );
  };

  const renderContestsTab = () => {
    if (!data) return null;

    const wins = data.contestHistory.filter(c => c.status === 'winner').length;
    const finals = data.contestHistory.filter(c => c.status === 'finalist').length;

    return (
      <>
        <View style={styles.contestStatsRow}>
          <View style={styles.contestStatCard}>
            <Ionicons name="trophy" size={28} color={COLORS.gold} />
            <Text style={styles.contestStatValue}>{wins}</Text>
            <Text style={styles.contestStatLabel}>Wins</Text>
          </View>
          <View style={styles.contestStatCard}>
            <Ionicons name="medal" size={28} color={COLORS.platinum} />
            <Text style={styles.contestStatValue}>{finals}</Text>
            <Text style={styles.contestStatLabel}>Finals</Text>
          </View>
          <View style={styles.contestStatCard}>
            <Ionicons name="ribbon" size={28} color={COLORS.primary} />
            <Text style={styles.contestStatValue}>{data.contestHistory.length}</Text>
            <Text style={styles.contestStatLabel}>Total</Text>
          </View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>Contest History</Text>
          {data.contestHistory.map((contest) => (
            <View key={contest.contestId} style={styles.contestItem}>
              <View style={styles.contestRankBadge}>
                <Text style={styles.contestRankText}>#{contest.rank}</Text>
              </View>
              <View style={styles.contestInfo}>
                <Text style={styles.contestName}>{contest.contestName}</Text>
                <Text style={styles.contestDate}>{contest.date}</Text>
                <View style={styles.contestMeta}>
                  <Text style={styles.contestMetaText}>
                    {contest.votes} votes • {contest.totalParticipants} participants
                  </Text>
                </View>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: getStatusColor(contest.status) + '20' }]}>
                <Text style={[styles.statusText, { color: getStatusColor(contest.status) }]}>
                  {contest.status.charAt(0).toUpperCase() + contest.status.slice(1)}
                </Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.chartCard}>
          <LineChart
            data={data.contestHistory.slice().reverse().map(c => ({
              label: c.contestName.split(' ')[0],
              value: c.totalParticipants - c.rank + 1,
            }))}
            title="Contest Performance Trend"
            color={COLORS.gold}
            height={200}
            showValues={false}
          />
        </View>
      </>
    );
  };

  if (loading && !data) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading analytics...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.title}>Analytics</Text>
          <TouchableOpacity onPress={showExportOptions} style={styles.exportBtn}>
            <Ionicons name="download-outline" size={24} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        {/* Time Range Selector */}
        <View style={styles.timeRangeContainer}>
          {(['7d', '30d', '90d', '1y', 'all'] as TimeRange[]).map((range) => (
            <TouchableOpacity
              key={range}
              style={[styles.timeRangeBtn, timeRange === range && styles.timeRangeBtnActive]}
              onPress={() => setTimeRange(range)}
            >
              <Text style={[styles.timeRangeText, timeRange === range && styles.timeRangeTextActive]}>
                {range === 'all' ? 'All' : range.toUpperCase()}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Tab Navigation */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.tabScrollContainer}
          contentContainerStyle={styles.tabContainer}
        >
          {(['overview', 'earnings', 'audience', 'contests', 'goals'] as TabType[]).map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeTab === tab && styles.tabActive]}
              onPress={() => setActiveTab(tab)}
            >
              <Ionicons
                name={
                  tab === 'overview' ? 'stats-chart' :
                  tab === 'earnings' ? 'cash' :
                  tab === 'audience' ? 'people' :
                  tab === 'contests' ? 'trophy' : 'flag'
                }
                size={18}
                color={activeTab === tab ? COLORS.textPrimary : COLORS.textMuted}
              />
              <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Tab Content */}
        {activeTab === 'overview' && renderOverviewTab()}
        {activeTab === 'earnings' && renderEarningsTab()}
        {activeTab === 'audience' && renderAudienceTab()}
        {activeTab === 'contests' && renderContestsTab()}
        {activeTab === 'goals' && renderGoalsTab()}
      </ScrollView>

      {/* New Goal Modal */}
      <Modal visible={showNewGoalModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create New Goal</Text>
              <TouchableOpacity onPress={() => setShowNewGoalModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <Text style={styles.modalLabel}>Goal Type</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.goalTypeScroll}>
              {GOAL_TEMPLATES.map(template => (
                <TouchableOpacity
                  key={template.type}
                  style={[
                    styles.goalTypeBtn,
                    newGoal.type === template.type && { borderColor: template.color, backgroundColor: template.color + '20' }
                  ]}
                  onPress={() => setNewGoal({ ...newGoal, type: template.type })}
                >
                  <Ionicons name={template.icon as any} size={24} color={template.color} />
                  <Text style={styles.goalTypeBtnText}>{template.title}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={styles.modalLabel}>Target Value</Text>
            <TextInput
              style={styles.modalInput}
              placeholder={newGoal.type === 'earnings' ? '$5000' : '100000'}
              placeholderTextColor={COLORS.textMuted}
              keyboardType="numeric"
              value={newGoal.targetValue}
              onChangeText={(text) => setNewGoal({ ...newGoal, targetValue: text })}
            />

            <Text style={styles.modalLabel}>Time Frame (Days)</Text>
            <View style={styles.daysRow}>
              {['7', '14', '30', '60', '90'].map(days => (
                <TouchableOpacity
                  key={days}
                  style={[styles.dayBtn, newGoal.days === days && styles.dayBtnActive]}
                  onPress={() => setNewGoal({ ...newGoal, days })}
                >
                  <Text style={[styles.dayBtnText, newGoal.days === days && styles.dayBtnTextActive]}>
                    {days}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.createBtn} onPress={handleCreateGoal}>
              <Text style={styles.createBtnText}>Create Goal</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Share Achievement Modal */}
      <Modal visible={showShareModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Share Achievement</Text>
              <TouchableOpacity onPress={() => setShowShareModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <Text style={styles.modalLabel}>Select Template</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.templateScroll}>
              {(['milestone', 'contest_win', 'earnings', 'followers'] as CardTemplate[]).map(template => (
                <TouchableOpacity
                  key={template}
                  style={[
                    styles.templateBtn,
                    selectedShareType === template && styles.templateBtnActive
                  ]}
                  onPress={() => setSelectedShareType(template)}
                >
                  <Text style={styles.templateBtnText}>
                    {template.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {data && (
              <ShareableCard
                template={selectedShareType}
                title={
                  selectedShareType === 'milestone' ? 'PLAYS MILESTONE' :
                  selectedShareType === 'contest_win' ? 'CONTEST WINNER' :
                  selectedShareType === 'earnings' ? 'EARNINGS MILESTONE' : 'FOLLOWERS MILESTONE'
                }
                value={
                  selectedShareType === 'milestone' ? formatNumber(data.overview.totalPlays) :
                  selectedShareType === 'contest_win' ? '#1' :
                  selectedShareType === 'earnings' ? formatCurrency(data.overview.totalEarnings) :
                  formatNumber(data.overview.totalFollowers)
                }
                subtitle="on 1WAY Music"
                artistName={profile?.displayName || 'Artist'}
                artistImage={profile?.profileImage}
                date={new Date().toLocaleDateString()}
                onShare={handleShareAchievement}
              />
            )}
          </View>
        </View>
      </Modal>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  loadingContainer: { flex: 1, backgroundColor: COLORS.background, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: COLORS.textMuted, marginTop: 12 },
  content: { paddingBottom: 180 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  exportBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  timeRangeContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 8, marginBottom: 16 },
  timeRangeBtn: { flex: 1, paddingVertical: 8, borderRadius: 8, backgroundColor: COLORS.backgroundCard, alignItems: 'center' },
  timeRangeBtnActive: { backgroundColor: COLORS.primary },
  timeRangeText: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted },
  timeRangeTextActive: { color: COLORS.textPrimary },
  tabScrollContainer: { marginBottom: 20 },
  tabContainer: { paddingHorizontal: 20, gap: 8 },
  tab: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 10, paddingHorizontal: 16, borderRadius: 12, backgroundColor: COLORS.backgroundCard },
  tabActive: { backgroundColor: COLORS.primary },
  tabText: { fontSize: 12, fontWeight: '600', color: COLORS.textMuted },
  tabTextActive: { color: COLORS.textPrimary },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 16, gap: 12, marginBottom: 16 },
  statCard: { width: '47%', backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 16 },
  statHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  changeBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8, gap: 2 },
  positiveChange: { backgroundColor: 'rgba(16, 185, 129, 0.15)' },
  negativeChange: { backgroundColor: 'rgba(239, 68, 68, 0.15)' },
  changeText: { fontSize: 11, fontWeight: '600' },
  positiveText: { color: COLORS.success },
  negativeText: { color: COLORS.error },
  statValue: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  statLabel: { fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  chartCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 16, marginHorizontal: 20, marginBottom: 16 },
  sectionCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 16, marginHorizontal: 20, marginBottom: 16 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 16 },
  trackItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  trackRank: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  rankText: { color: COLORS.textPrimary, fontSize: 12, fontWeight: '700' },
  trackInfo: { flex: 1 },
  trackTitle: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  trackStats: { flexDirection: 'row', gap: 12, marginTop: 4 },
  trackStat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  trackStatText: { fontSize: 11, color: COLORS.textMuted },
  activityItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  activityIcon: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  activityInfo: { flex: 1 },
  activityText: { fontSize: 13, color: COLORS.textPrimary },
  activityTime: { fontSize: 11, color: COLORS.textMuted, marginTop: 2 },
  activityValue: { fontSize: 13, fontWeight: '600', color: COLORS.success },
  earningsHeader: { alignItems: 'center', backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, padding: 24, borderRadius: 16, marginBottom: 16 },
  earningsLabel: { fontSize: 14, color: COLORS.textMuted },
  earningsValue: { fontSize: 40, fontWeight: '800', color: COLORS.success, marginVertical: 8 },
  earningsChange: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  earningsChangeText: { fontSize: 13, color: COLORS.success },
  earningSourceItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  sourceIndicator: { width: 12, height: 12, borderRadius: 6, marginRight: 12 },
  sourceName: { flex: 1, fontSize: 14, color: COLORS.textPrimary },
  sourceValue: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary, marginRight: 12 },
  sourcePercent: { fontSize: 12, color: COLORS.textMuted, width: 50, textAlign: 'right' },
  audienceHeader: { alignItems: 'center', backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, padding: 24, borderRadius: 16, marginBottom: 16 },
  audienceValue: { fontSize: 36, fontWeight: '800', color: COLORS.textPrimary, marginVertical: 8 },
  audienceLabel: { fontSize: 14, color: COLORS.textMuted },
  contestStatsRow: { flexDirection: 'row', paddingHorizontal: 20, gap: 12, marginBottom: 16 },
  contestStatCard: { flex: 1, backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 16, alignItems: 'center' },
  contestStatValue: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary, marginTop: 8 },
  contestStatLabel: { fontSize: 12, color: COLORS.textMuted, marginTop: 4 },
  contestItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  contestRankBadge: { width: 36, height: 36, borderRadius: 8, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  contestRankText: { color: COLORS.textPrimary, fontSize: 12, fontWeight: '700' },
  contestInfo: { flex: 1 },
  contestName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  contestDate: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  contestMeta: { marginTop: 4 },
  contestMetaText: { fontSize: 11, color: COLORS.textSecondary },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 11, fontWeight: '600' },
  // Goals Tab Styles
  createGoalBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, padding: 16, borderRadius: 12, marginBottom: 16, borderWidth: 2, borderColor: COLORS.primary, borderStyle: 'dashed' },
  createGoalText: { fontSize: 16, fontWeight: '600', color: COLORS.primary },
  goalItem: { backgroundColor: COLORS.backgroundLight, borderRadius: 12, padding: 16, marginBottom: 12 },
  goalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  goalIcon: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  goalInfo: { flex: 1 },
  goalTitle: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  goalSubtitle: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  goalDays: { alignItems: 'center' },
  goalDaysValue: { fontSize: 18, fontWeight: '700', color: COLORS.primary },
  goalDaysLabel: { fontSize: 10, color: COLORS.textMuted },
  progressContainer: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  progressBar: { flex: 1, height: 8, backgroundColor: COLORS.backgroundCard, borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4 },
  progressText: { fontSize: 12, fontWeight: '600', width: 40, textAlign: 'right' },
  milestones: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
  milestone: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  milestoneReached: {},
  milestoneText: { fontSize: 11, color: COLORS.textMuted },
  milestoneTextReached: { color: COLORS.success },
  aiBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: COLORS.gold + '20', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  aiBadgeText: { fontSize: 11, fontWeight: '600', color: COLORS.gold },
  suggestionItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  suggestionPriority: { width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  suggestionContent: { flex: 1 },
  suggestionTitle: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  suggestionDesc: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  suggestionImpact: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  suggestionImpactText: { fontSize: 11, color: COLORS.success, fontWeight: '500' },
  shareAchievementsBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, marginHorizontal: 20, padding: 16, borderRadius: 12, marginBottom: 16 },
  shareAchievementsBtnText: { fontSize: 16, fontWeight: '600', color: '#fff' },
  // Modal Styles
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.backgroundCard, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  modalLabel: { fontSize: 14, fontWeight: '600', color: COLORS.textMuted, marginBottom: 12 },
  modalInput: { backgroundColor: COLORS.background, borderRadius: 12, padding: 16, fontSize: 16, color: COLORS.textPrimary, marginBottom: 20 },
  goalTypeScroll: { marginBottom: 20 },
  goalTypeBtn: { alignItems: 'center', padding: 16, borderRadius: 12, backgroundColor: COLORS.background, marginRight: 12, borderWidth: 2, borderColor: 'transparent', minWidth: 100 },
  goalTypeBtnText: { fontSize: 12, color: COLORS.textPrimary, marginTop: 8, fontWeight: '500' },
  daysRow: { flexDirection: 'row', gap: 8, marginBottom: 24 },
  dayBtn: { flex: 1, paddingVertical: 12, borderRadius: 8, backgroundColor: COLORS.background, alignItems: 'center' },
  dayBtnActive: { backgroundColor: COLORS.primary },
  dayBtnText: { fontSize: 14, fontWeight: '600', color: COLORS.textMuted },
  dayBtnTextActive: { color: COLORS.textPrimary },
  createBtn: { backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  createBtnText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  templateScroll: { marginBottom: 20 },
  templateBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 20, backgroundColor: COLORS.background, marginRight: 12 },
  templateBtnActive: { backgroundColor: COLORS.primary },
  templateBtnText: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
});
