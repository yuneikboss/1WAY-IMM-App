import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';

const GLOBAL_STATS = {
  totalUsers: 2847593,
  totalArtists: 458291,
  totalTracks: 1293847,
  totalStreams: 89472635,
};

const TOP_COUNTRIES = [
  { name: 'United States', users: 892453, flag: 'US', growth: '+12%' },
  { name: 'United Kingdom', users: 324891, flag: 'GB', growth: '+8%' },
  { name: 'Canada', users: 198234, flag: 'CA', growth: '+15%' },
  { name: 'Germany', users: 156782, flag: 'DE', growth: '+6%' },
  { name: 'France', users: 134567, flag: 'FR', growth: '+9%' },
  { name: 'Australia', users: 112345, flag: 'AU', growth: '+11%' },
  { name: 'Brazil', users: 98765, flag: 'BR', growth: '+22%' },
  { name: 'Japan', users: 87654, flag: 'JP', growth: '+7%' },
  { name: 'Nigeria', users: 76543, flag: 'NG', growth: '+31%' },
  { name: 'South Africa', users: 65432, flag: 'ZA', growth: '+18%' },
];

const TOP_STATES = [
  { name: 'California', users: 234567, country: 'US' },
  { name: 'Texas', users: 187654, country: 'US' },
  { name: 'New York', users: 165432, country: 'US' },
  { name: 'Florida', users: 143210, country: 'US' },
  { name: 'Georgia', users: 98765, country: 'US' },
  { name: 'Illinois', users: 87654, country: 'US' },
  { name: 'Ohio', users: 76543, country: 'US' },
  { name: 'Pennsylvania', users: 65432, country: 'US' },
];

const TOP_CITIES = [
  { name: 'Los Angeles', state: 'CA', users: 98765 },
  { name: 'New York City', state: 'NY', users: 87654 },
  { name: 'Houston', state: 'TX', users: 76543 },
  { name: 'Atlanta', state: 'GA', users: 65432 },
  { name: 'Chicago', state: 'IL', users: 54321 },
  { name: 'Miami', state: 'FL', users: 43210 },
  { name: 'Dallas', state: 'TX', users: 32109 },
  { name: 'Phoenix', state: 'AZ', users: 21098 },
];

export default function GlobalStatsScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<'countries' | 'states' | 'cities'>('countries');

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>Global Stats</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
        <View style={styles.globalOverview}>
          <View style={styles.globeIcon}>
            <Ionicons name="globe" size={48} color={COLORS.primary} />
          </View>
          <Text style={styles.overviewTitle}>1WAY Worldwide</Text>
          <Text style={styles.overviewDesc}>Artists connecting across the globe</Text>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Ionicons name="people" size={24} color={COLORS.primary} />
            <Text style={styles.statValue}>{formatNumber(GLOBAL_STATS.totalUsers)}</Text>
            <Text style={styles.statLabel}>Total Users</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="mic" size={24} color={COLORS.secondary} />
            <Text style={styles.statValue}>{formatNumber(GLOBAL_STATS.totalArtists)}</Text>
            <Text style={styles.statLabel}>Artists</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="musical-notes" size={24} color={COLORS.gold} />
            <Text style={styles.statValue}>{formatNumber(GLOBAL_STATS.totalTracks)}</Text>
            <Text style={styles.statLabel}>Tracks</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="play" size={24} color={COLORS.success} />
            <Text style={styles.statValue}>{formatNumber(GLOBAL_STATS.totalStreams)}</Text>
            <Text style={styles.statLabel}>Streams</Text>
          </View>
        </View>

        <View style={styles.tabs}>
          {(['countries', 'states', 'cities'] as const).map(tab => (
            <TouchableOpacity 
              key={tab} 
              style={[styles.tab, activeTab === tab && styles.tabActive]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {activeTab === 'countries' && (
          <View style={styles.listSection}>
            <Text style={styles.sectionTitle}>Top Countries</Text>
            {TOP_COUNTRIES.map((country, index) => (
              <View key={country.name} style={styles.listItem}>
                <Text style={styles.rank}>#{index + 1}</Text>
                <View style={styles.flagContainer}>
                  <Ionicons name="flag" size={20} color={COLORS.primary} />
                </View>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{country.name}</Text>
                  <Text style={styles.itemUsers}>{formatNumber(country.users)} users</Text>
                </View>
                <View style={styles.growthBadge}>
                  <Ionicons name="trending-up" size={14} color={COLORS.success} />
                  <Text style={styles.growthText}>{country.growth}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'states' && (
          <View style={styles.listSection}>
            <Text style={styles.sectionTitle}>Top States (US)</Text>
            {TOP_STATES.map((state, index) => (
              <View key={state.name} style={styles.listItem}>
                <Text style={styles.rank}>#{index + 1}</Text>
                <View style={styles.flagContainer}>
                  <Ionicons name="location" size={20} color={COLORS.secondary} />
                </View>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{state.name}</Text>
                  <Text style={styles.itemUsers}>{formatNumber(state.users)} users</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'cities' && (
          <View style={styles.listSection}>
            <Text style={styles.sectionTitle}>Top Cities</Text>
            {TOP_CITIES.map((city, index) => (
              <View key={city.name} style={styles.listItem}>
                <Text style={styles.rank}>#{index + 1}</Text>
                <View style={styles.flagContainer}>
                  <Ionicons name="business" size={20} color={COLORS.gold} />
                </View>
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{city.name}</Text>
                  <Text style={styles.itemUsers}>{city.state} • {formatNumber(city.users)} users</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        <View style={styles.liveIndicator}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>Live data • Updated every hour</Text>
        </View>
      </ScrollView>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    paddingTop: 60, 
    paddingHorizontal: 20, 
    paddingBottom: 16 
  },
  title: { fontSize: 24, fontWeight: '700', color: COLORS.textPrimary },
  content: { flex: 1 },
  contentContainer: { padding: 20, paddingBottom: 180 },
  globalOverview: { alignItems: 'center', marginBottom: 24 },
  globeIcon: { 
    width: 96, 
    height: 96, 
    borderRadius: 48, 
    backgroundColor: COLORS.backgroundCard, 
    justifyContent: 'center', 
    alignItems: 'center',
    marginBottom: 16,
  },
  overviewTitle: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  overviewDesc: { color: COLORS.textMuted, marginTop: 4 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  statCard: { 
    width: '48%', 
    backgroundColor: COLORS.backgroundCard, 
    padding: 16, 
    borderRadius: 16, 
    alignItems: 'center' 
  },
  statValue: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary, marginTop: 8 },
  statLabel: { color: COLORS.textMuted, fontSize: 12, marginTop: 4 },
  tabs: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  tab: { 
    flex: 1, 
    paddingVertical: 12, 
    borderRadius: 12, 
    backgroundColor: COLORS.backgroundCard, 
    alignItems: 'center' 
  },
  tabActive: { backgroundColor: COLORS.primary },
  tabText: { color: COLORS.textMuted, fontWeight: '600' },
  tabTextActive: { color: COLORS.textPrimary },
  listSection: {},
  sectionTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 16 },
  listItem: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: COLORS.backgroundCard, 
    padding: 16, 
    borderRadius: 12, 
    marginBottom: 8 
  },
  rank: { 
    width: 32, 
    color: COLORS.textMuted, 
    fontWeight: '700', 
    fontSize: 14 
  },
  flagContainer: { 
    width: 40, 
    height: 40, 
    borderRadius: 20, 
    backgroundColor: COLORS.backgroundLight, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  itemInfo: { flex: 1, marginLeft: 12 },
  itemName: { color: COLORS.textPrimary, fontWeight: '600', fontSize: 16 },
  itemUsers: { color: COLORS.textMuted, fontSize: 13 },
  growthBadge: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 4, 
    backgroundColor: 'rgba(34,197,94,0.15)', 
    paddingHorizontal: 8, 
    paddingVertical: 4, 
    borderRadius: 8 
  },
  growthText: { color: COLORS.success, fontSize: 12, fontWeight: '600' },
  liveIndicator: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    gap: 8, 
    marginTop: 24 
  },
  liveDot: { 
    width: 8, 
    height: 8, 
    borderRadius: 4, 
    backgroundColor: COLORS.success 
  },
  liveText: { color: COLORS.textMuted, fontSize: 12 },
});
