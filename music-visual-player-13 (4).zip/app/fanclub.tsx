import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity, Image, Modal, TextInput, Alert, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import { IMAGES } from './constants/images';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import { useAuth } from './context/AuthContext';
import { ARTISTS } from './data/artists';

interface MembershipTier {
  id: string;
  name: string;
  price: number;
  color: string;
  icon: string;
  perks: string[];
  memberCount: number;
}

interface FanClubPost {
  id: string;
  type: 'text' | 'image' | 'video' | 'music' | 'poll';
  content: string;
  media?: string;
  tier: string;
  likes: number;
  comments: number;
  timestamp: number;
}

interface FanClubMember {
  id: string;
  name: string;
  image: string;
  tier: string;
  joinedAt: number;
}

const MEMBERSHIP_TIERS: MembershipTier[] = [
  {
    id: 'bronze',
    name: 'Bronze Fan',
    price: 4.99,
    color: '#CD7F32',
    icon: 'star',
    perks: ['Exclusive posts', 'Fan badge', 'Community access'],
    memberCount: 1250,
  },
  {
    id: 'silver',
    name: 'Silver Supporter',
    price: 9.99,
    color: '#C0C0C0',
    icon: 'star-half',
    perks: ['All Bronze perks', 'Early music access', 'Behind-the-scenes', 'Monthly Q&A'],
    memberCount: 580,
  },
  {
    id: 'gold',
    name: 'Gold VIP',
    price: 19.99,
    color: COLORS.gold,
    icon: 'star',
    perks: ['All Silver perks', 'Direct messaging', 'Exclusive merch discounts', 'Name in credits'],
    memberCount: 245,
  },
  {
    id: 'platinum',
    name: 'Platinum Elite',
    price: 49.99,
    color: '#E5E4E2',
    icon: 'diamond',
    perks: ['All Gold perks', 'Virtual meet & greets', 'Unreleased tracks', 'Personal shoutouts', 'Priority support'],
    memberCount: 82,
  },
];

const SAMPLE_POSTS: FanClubPost[] = [
  { id: '1', type: 'text', content: 'Working on something special for you all! New album dropping next month. Stay tuned!', tier: 'bronze', likes: 342, comments: 89, timestamp: Date.now() - 3600000 },
  { id: '2', type: 'image', content: 'Studio session vibes', media: IMAGES.booth, tier: 'silver', likes: 567, comments: 124, timestamp: Date.now() - 7200000 },
  { id: '3', type: 'music', content: 'Exclusive preview of my new track "Midnight Dreams" - Gold members only!', tier: 'gold', likes: 189, comments: 45, timestamp: Date.now() - 14400000 },
  { id: '4', type: 'video', content: 'Virtual meet & greet recording from last week. Thank you Platinum members!', media: IMAGES.heroBanners[1], tier: 'platinum', likes: 78, comments: 23, timestamp: Date.now() - 28800000 },
];

const SAMPLE_MEMBERS: FanClubMember[] = ARTISTS.slice(0, 8).map((artist, i) => ({
  id: artist.id,
  name: artist.name,
  image: artist.image,
  tier: ['bronze', 'silver', 'gold', 'platinum'][i % 4],
  joinedAt: Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000,
}));

export default function FanClubScreen() {
  const router = useRouter();
  const { profile, addNotification } = useAuth();
  const [activeTab, setActiveTab] = useState<'feed' | 'tiers' | 'members' | 'analytics'>('feed');
  const [showCreateTier, setShowCreateTier] = useState(false);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showSubscribe, setShowSubscribe] = useState(false);
  const [selectedTier, setSelectedTier] = useState<MembershipTier | null>(null);
  const [newTierName, setNewTierName] = useState('');
  const [newTierPrice, setNewTierPrice] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostTier, setNewPostTier] = useState('bronze');
  const [userTiers, setUserTiers] = useState<MembershipTier[]>(MEMBERSHIP_TIERS);
  const [posts, setPosts] = useState<FanClubPost[]>(SAMPLE_POSTS);
  const [subscribedTier, setSubscribedTier] = useState<string | null>(null);

  const isPremium = profile?.isPremium;
  const isArtist = profile?.isArtist;

  const getTierColor = (tierId: string) => {
    const tier = userTiers.find(t => t.id === tierId);
    return tier?.color || COLORS.textMuted;
  };

  const handleSubscribe = (tier: MembershipTier) => {
    setSelectedTier(tier);
    setShowSubscribe(true);
  };

  const confirmSubscription = () => {
    if (!selectedTier) return;
    
    setSubscribedTier(selectedTier.id);
    setShowSubscribe(false);
    
    addNotification({
      type: 'purchase',
      title: 'Subscription Active!',
      message: `You're now a ${selectedTier.name}! Enjoy your exclusive perks.`,
    });
    
    Alert.alert('Welcome!', `You're now a ${selectedTier.name}! Enjoy your exclusive content and perks.`);
  };

  const handleCreatePost = () => {
    if (!newPostContent.trim()) {
      Alert.alert('Error', 'Please enter some content for your post');
      return;
    }

    const newPost: FanClubPost = {
      id: Date.now().toString(),
      type: 'text',
      content: newPostContent,
      tier: newPostTier,
      likes: 0,
      comments: 0,
      timestamp: Date.now(),
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
    setShowCreatePost(false);
    
    Alert.alert('Posted!', 'Your exclusive content has been shared with your fans.');
  };

  const formatTimeAgo = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const hours = Math.floor(diff / 3600000);
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const canViewPost = (postTier: string) => {
    if (!subscribedTier) return postTier === 'bronze';
    const tierOrder = ['bronze', 'silver', 'gold', 'platinum'];
    return tierOrder.indexOf(postTier) <= tierOrder.indexOf(subscribedTier);
  };

  const renderFeed = () => (
    <View style={styles.feedContainer}>
      {isArtist && (
        <TouchableOpacity style={styles.createPostBtn} onPress={() => setShowCreatePost(true)}>
          <Ionicons name="add-circle" size={24} color={COLORS.primary} />
          <Text style={styles.createPostText}>Create Exclusive Post</Text>
        </TouchableOpacity>
      )}

      {posts.map(post => (
        <View key={post.id} style={styles.postCard}>
          <View style={styles.postHeader}>
            <Image source={{ uri: profile?.profileImage || IMAGES.artists[0] }} style={styles.postAvatar} />
            <View style={styles.postInfo}>
              <Text style={styles.postAuthor}>{profile?.displayName || 'Artist'}</Text>
              <View style={styles.postMeta}>
                <View style={[styles.tierBadge, { backgroundColor: getTierColor(post.tier) }]}>
                  <Text style={styles.tierBadgeText}>{post.tier.toUpperCase()}</Text>
                </View>
                <Text style={styles.postTime}>{formatTimeAgo(post.timestamp)}</Text>
              </View>
            </View>
          </View>

          {canViewPost(post.tier) ? (
            <>
              <Text style={styles.postContent}>{post.content}</Text>
              {post.media && (
                <Image source={{ uri: post.media }} style={styles.postMedia} />
              )}
              <View style={styles.postActions}>
                <TouchableOpacity style={styles.postAction}>
                  <Ionicons name="heart-outline" size={20} color={COLORS.textMuted} />
                  <Text style={styles.actionCount}>{post.likes}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.postAction}>
                  <Ionicons name="chatbubble-outline" size={20} color={COLORS.textMuted} />
                  <Text style={styles.actionCount}>{post.comments}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.postAction}>
                  <Ionicons name="share-outline" size={20} color={COLORS.textMuted} />
                </TouchableOpacity>
              </View>
            </>
          ) : (
            <View style={styles.lockedContent}>
              <Ionicons name="lock-closed" size={32} color={COLORS.textMuted} />
              <Text style={styles.lockedText}>This content is for {post.tier} members and above</Text>
              <TouchableOpacity 
                style={styles.unlockBtn}
                onPress={() => handleSubscribe(userTiers.find(t => t.id === post.tier)!)}
              >
                <Text style={styles.unlockBtnText}>Unlock Now</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      ))}
    </View>
  );

  const renderTiers = () => (
    <View style={styles.tiersContainer}>
      {isArtist && (
        <TouchableOpacity style={styles.createTierBtn} onPress={() => setShowCreateTier(true)}>
          <Ionicons name="add-circle" size={24} color={COLORS.primary} />
          <Text style={styles.createTierText}>Create New Tier</Text>
        </TouchableOpacity>
      )}

      {userTiers.map(tier => (
        <View key={tier.id} style={[styles.tierCard, { borderColor: tier.color }]}>
          <View style={styles.tierHeader}>
            <View style={[styles.tierIcon, { backgroundColor: tier.color }]}>
              <Ionicons name={tier.icon as any} size={24} color={COLORS.background} />
            </View>
            <View style={styles.tierInfo}>
              <Text style={styles.tierName}>{tier.name}</Text>
              <Text style={[styles.tierPrice, { color: tier.color }]}>${tier.price}/month</Text>
            </View>
            <View style={styles.memberCount}>
              <Text style={styles.memberCountNum}>{tier.memberCount}</Text>
              <Text style={styles.memberCountLabel}>members</Text>
            </View>
          </View>

          <View style={styles.perksList}>
            {tier.perks.map((perk, index) => (
              <View key={index} style={styles.perkItem}>
                <Ionicons name="checkmark-circle" size={16} color={tier.color} />
                <Text style={styles.perkText}>{perk}</Text>
              </View>
            ))}
          </View>

          {!isArtist && (
            <TouchableOpacity 
              style={[
                styles.subscribeBtn, 
                { backgroundColor: tier.color },
                subscribedTier === tier.id && styles.subscribedBtn
              ]}
              onPress={() => handleSubscribe(tier)}
              disabled={subscribedTier === tier.id}
            >
              <Text style={styles.subscribeBtnText}>
                {subscribedTier === tier.id ? 'Subscribed' : 'Subscribe'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </View>
  );

  const renderMembers = () => (
    <View style={styles.membersContainer}>
      <View style={styles.membersHeader}>
        <Text style={styles.membersTitle}>Recent Members</Text>
        <Text style={styles.membersCount}>{SAMPLE_MEMBERS.length} total</Text>
      </View>

      {SAMPLE_MEMBERS.map(member => (
        <TouchableOpacity key={member.id} style={styles.memberCard}>
          <Image source={{ uri: member.image }} style={styles.memberAvatar} />
          <View style={styles.memberInfo}>
            <Text style={styles.memberName}>{member.name}</Text>
            <Text style={styles.memberJoined}>Joined {formatTimeAgo(member.joinedAt)}</Text>
          </View>
          <View style={[styles.memberTierBadge, { backgroundColor: getTierColor(member.tier) }]}>
            <Text style={styles.memberTierText}>{member.tier}</Text>
          </View>
        </TouchableOpacity>
      ))}
    </View>
  );

  const renderAnalytics = () => (
    <View style={styles.analyticsContainer}>
      <View style={styles.statsGrid}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>2,157</Text>
          <Text style={styles.statLabel}>Total Members</Text>
          <Text style={styles.statChange}>+12% this month</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>$8,420</Text>
          <Text style={styles.statLabel}>Monthly Revenue</Text>
          <Text style={styles.statChange}>+8% this month</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>89%</Text>
          <Text style={styles.statLabel}>Retention Rate</Text>
          <Text style={styles.statChange}>+2% this month</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>4.2</Text>
          <Text style={styles.statLabel}>Avg. Posts/Week</Text>
          <Text style={styles.statChange}>Consistent</Text>
        </View>
      </View>

      <View style={styles.tierBreakdown}>
        <Text style={styles.breakdownTitle}>Membership Breakdown</Text>
        {userTiers.map(tier => (
          <View key={tier.id} style={styles.breakdownRow}>
            <View style={[styles.breakdownDot, { backgroundColor: tier.color }]} />
            <Text style={styles.breakdownName}>{tier.name}</Text>
            <View style={styles.breakdownBar}>
              <View style={[styles.breakdownFill, { width: `${(tier.memberCount / 2157) * 100}%`, backgroundColor: tier.color }]} />
            </View>
            <Text style={styles.breakdownCount}>{tier.memberCount}</Text>
          </View>
        ))}
      </View>

      <View style={styles.engagementCard}>
        <Text style={styles.engagementTitle}>Top Performing Content</Text>
        <View style={styles.engagementItem}>
          <Ionicons name="musical-notes" size={20} color={COLORS.primary} />
          <Text style={styles.engagementText}>Exclusive track preview</Text>
          <Text style={styles.engagementStat}>567 likes</Text>
        </View>
        <View style={styles.engagementItem}>
          <Ionicons name="videocam" size={20} color={COLORS.secondary} />
          <Text style={styles.engagementText}>Behind the scenes</Text>
          <Text style={styles.engagementStat}>342 likes</Text>
        </View>
        <View style={styles.engagementItem}>
          <Ionicons name="chatbubbles" size={20} color={COLORS.gold} />
          <Text style={styles.engagementText}>Q&A Session</Text>
          <Text style={styles.engagementStat}>289 comments</Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>Fan Club</Text>
        <TouchableOpacity>
          <Ionicons name="settings-outline" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
      </View>

      <View style={styles.tabs}>
        {[
          { id: 'feed', label: 'Feed', icon: 'newspaper' },
          { id: 'tiers', label: 'Tiers', icon: 'layers' },
          { id: 'members', label: 'Members', icon: 'people' },
          ...(isArtist ? [{ id: 'analytics', label: 'Analytics', icon: 'stats-chart' }] : []),
        ].map(tab => (
          <TouchableOpacity
            key={tab.id}
            style={[styles.tab, activeTab === tab.id && styles.tabActive]}
            onPress={() => setActiveTab(tab.id as any)}
          >
            <Ionicons 
              name={tab.icon as any} 
              size={18} 
              color={activeTab === tab.id ? COLORS.textPrimary : COLORS.textMuted} 
            />
            <Text style={[styles.tabText, activeTab === tab.id && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
        {activeTab === 'feed' && renderFeed()}
        {activeTab === 'tiers' && renderTiers()}
        {activeTab === 'members' && renderMembers()}
        {activeTab === 'analytics' && renderAnalytics()}
      </ScrollView>

      {/* Create Post Modal */}
      <Modal visible={showCreatePost} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create Post</Text>
              <TouchableOpacity onPress={() => setShowCreatePost(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.postInput}
              value={newPostContent}
              onChangeText={setNewPostContent}
              placeholder="Share something exclusive with your fans..."
              placeholderTextColor={COLORS.textMuted}
              multiline
              numberOfLines={4}
            />

            <Text style={styles.tierSelectLabel}>Minimum tier to view:</Text>
            <View style={styles.tierSelect}>
              {userTiers.map(tier => (
                <TouchableOpacity
                  key={tier.id}
                  style={[
                    styles.tierOption,
                    newPostTier === tier.id && { backgroundColor: tier.color }
                  ]}
                  onPress={() => setNewPostTier(tier.id)}
                >
                  <Text style={styles.tierOptionText}>{tier.name}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.mediaOptions}>
              <TouchableOpacity style={styles.mediaOption}>
                <Ionicons name="image" size={24} color={COLORS.primary} />
                <Text style={styles.mediaOptionText}>Photo</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.mediaOption}>
                <Ionicons name="videocam" size={24} color={COLORS.secondary} />
                <Text style={styles.mediaOptionText}>Video</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.mediaOption}>
                <Ionicons name="musical-notes" size={24} color={COLORS.gold} />
                <Text style={styles.mediaOptionText}>Music</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.mediaOption}>
                <Ionicons name="stats-chart" size={24} color={COLORS.accent} />
                <Text style={styles.mediaOptionText}>Poll</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.publishBtn} onPress={handleCreatePost}>
              <Text style={styles.publishBtnText}>Publish Post</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Subscribe Modal */}
      <Modal visible={showSubscribe} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Subscribe</Text>
              <TouchableOpacity onPress={() => setShowSubscribe(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {selectedTier && (
              <>
                <View style={[styles.selectedTierCard, { borderColor: selectedTier.color }]}>
                  <View style={[styles.tierIcon, { backgroundColor: selectedTier.color }]}>
                    <Ionicons name={selectedTier.icon as any} size={32} color={COLORS.background} />
                  </View>
                  <Text style={styles.selectedTierName}>{selectedTier.name}</Text>
                  <Text style={[styles.selectedTierPrice, { color: selectedTier.color }]}>
                    ${selectedTier.price}/month
                  </Text>
                </View>

                <View style={styles.perksPreview}>
                  <Text style={styles.perksTitle}>What you'll get:</Text>
                  {selectedTier.perks.map((perk, index) => (
                    <View key={index} style={styles.perkItem}>
                      <Ionicons name="checkmark-circle" size={16} color={selectedTier.color} />
                      <Text style={styles.perkText}>{perk}</Text>
                    </View>
                  ))}
                </View>

                <TouchableOpacity 
                  style={[styles.confirmSubscribeBtn, { backgroundColor: selectedTier.color }]}
                  onPress={confirmSubscription}
                >
                  <Text style={styles.confirmSubscribeBtnText}>
                    Subscribe for ${selectedTier.price}/month
                  </Text>
                </TouchableOpacity>

                <Text style={styles.cancelNote}>Cancel anytime. No commitment.</Text>
              </>
            )}
          </View>
        </View>
      </Modal>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  tabs: { flexDirection: 'row', paddingHorizontal: 20, gap: 8 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, backgroundColor: COLORS.backgroundCard, borderRadius: 12 },
  tabActive: { backgroundColor: COLORS.primary },
  tabText: { color: COLORS.textMuted, fontWeight: '600', fontSize: 12 },
  tabTextActive: { color: COLORS.textPrimary },
  content: { flex: 1 },
  contentContainer: { padding: 20, paddingBottom: 180 },
  // Feed
  feedContainer: { gap: 16 },
  createPostBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: COLORS.primary },
  createPostText: { color: COLORS.primary, fontWeight: '600' },
  postCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 16 },
  postHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  postAvatar: { width: 44, height: 44, borderRadius: 22 },
  postInfo: { flex: 1, marginLeft: 12 },
  postAuthor: { color: COLORS.textPrimary, fontWeight: '700' },
  postMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  tierBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  tierBadgeText: { color: COLORS.background, fontSize: 10, fontWeight: '700' },
  postTime: { color: COLORS.textMuted, fontSize: 12 },
  postContent: { color: COLORS.textPrimary, fontSize: 15, lineHeight: 22, marginBottom: 12 },
  postMedia: { width: '100%', height: 200, borderRadius: 12, marginBottom: 12 },
  postActions: { flexDirection: 'row', gap: 24 },
  postAction: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionCount: { color: COLORS.textMuted, fontSize: 14 },
  lockedContent: { alignItems: 'center', paddingVertical: 32, backgroundColor: COLORS.backgroundLight, borderRadius: 12 },
  lockedText: { color: COLORS.textMuted, marginTop: 12, textAlign: 'center' },
  unlockBtn: { backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 20, marginTop: 16 },
  unlockBtnText: { color: COLORS.textPrimary, fontWeight: '600' },
  // Tiers
  tiersContainer: { gap: 16 },
  createTierBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, borderWidth: 2, borderStyle: 'dashed', borderColor: COLORS.primary },
  createTierText: { color: COLORS.primary, fontWeight: '600' },
  tierCard: { backgroundColor: COLORS.backgroundCard, borderRadius: 16, padding: 20, borderWidth: 2 },
  tierHeader: { flexDirection: 'row', alignItems: 'center' },
  tierIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  tierInfo: { flex: 1, marginLeft: 12 },
  tierName: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  tierPrice: { fontSize: 16, fontWeight: '700', marginTop: 2 },
  memberCount: { alignItems: 'center' },
  memberCountNum: { color: COLORS.textPrimary, fontSize: 20, fontWeight: '800' },
  memberCountLabel: { color: COLORS.textMuted, fontSize: 11 },
  perksList: { marginTop: 16, gap: 8 },
  perkItem: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  perkText: { color: COLORS.textSecondary, fontSize: 14 },
  subscribeBtn: { marginTop: 16, paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  subscribedBtn: { opacity: 0.7 },
  subscribeBtnText: { color: COLORS.background, fontWeight: '700', fontSize: 16 },
  // Members
  membersContainer: { gap: 12 },
  membersHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  membersTitle: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  membersCount: { color: COLORS.textMuted },
  memberCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12 },
  memberAvatar: { width: 44, height: 44, borderRadius: 22 },
  memberInfo: { flex: 1, marginLeft: 12 },
  memberName: { color: COLORS.textPrimary, fontWeight: '600' },
  memberJoined: { color: COLORS.textMuted, fontSize: 12 },
  memberTierBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  memberTierText: { color: COLORS.background, fontSize: 11, fontWeight: '700', textTransform: 'capitalize' },
  // Analytics
  analyticsContainer: { gap: 20 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  statCard: { width: '47%', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12 },
  statValue: { color: COLORS.textPrimary, fontSize: 24, fontWeight: '800' },
  statLabel: { color: COLORS.textMuted, fontSize: 13, marginTop: 4 },
  statChange: { color: COLORS.success, fontSize: 12, marginTop: 4 },
  tierBreakdown: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12 },
  breakdownTitle: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 16 },
  breakdownRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  breakdownDot: { width: 12, height: 12, borderRadius: 6 },
  breakdownName: { color: COLORS.textSecondary, fontSize: 13, marginLeft: 8, width: 100 },
  breakdownBar: { flex: 1, height: 8, backgroundColor: COLORS.backgroundLight, borderRadius: 4, marginHorizontal: 8 },
  breakdownFill: { height: '100%', borderRadius: 4 },
  breakdownCount: { color: COLORS.textMuted, fontSize: 12, width: 40, textAlign: 'right' },
  engagementCard: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12 },
  engagementTitle: { color: COLORS.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 16 },
  engagementItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  engagementText: { flex: 1, color: COLORS.textSecondary, marginLeft: 12 },
  engagementStat: { color: COLORS.textMuted, fontSize: 13 },
  // Modals
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '85%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  postInput: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, color: COLORS.textPrimary, fontSize: 16, minHeight: 120, textAlignVertical: 'top' },
  tierSelectLabel: { color: COLORS.textMuted, marginTop: 16, marginBottom: 8 },
  tierSelect: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tierOption: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: COLORS.backgroundCard },
  tierOptionText: { color: COLORS.textPrimary, fontSize: 13 },
  mediaOptions: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 20, paddingTop: 20, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  mediaOption: { alignItems: 'center', gap: 4 },
  mediaOptionText: { color: COLORS.textMuted, fontSize: 12 },
  publishBtn: { backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
  publishBtnText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  selectedTierCard: { alignItems: 'center', padding: 24, backgroundColor: COLORS.backgroundCard, borderRadius: 16, borderWidth: 2 },
  selectedTierName: { color: COLORS.textPrimary, fontSize: 22, fontWeight: '700', marginTop: 12 },
  selectedTierPrice: { fontSize: 18, fontWeight: '700', marginTop: 4 },
  perksPreview: { marginTop: 20 },
  perksTitle: { color: COLORS.textPrimary, fontWeight: '600', marginBottom: 12 },
  confirmSubscribeBtn: { paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
  confirmSubscribeBtnText: { color: COLORS.background, fontSize: 18, fontWeight: '700' },
  cancelNote: { color: COLORS.textMuted, textAlign: 'center', marginTop: 12, fontSize: 13 },
});
