import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Text, TouchableOpacity, Image, Modal, TextInput, Alert, FlatList, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import { IMAGES } from './constants/images';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import { useAuth } from './context/AuthContext';
import { useApp } from './context/AppContext';
import LicenseDeliveryService, { 
  PurchasedBeat, 
  LicenseAgreement, 
  LICENSE_TYPES 
} from './services/LicenseDeliveryService';

interface Beat {
  id: string;
  title: string;
  producer: string;
  producerImage: string;
  coverImage: string;
  bpm: number;
  key: string;
  genre: string;
  mood: string;
  duration: string;
  plays: number;
  price: {
    mp3: number;
    wav: number;
    stems: number;
    exclusive: number;
  };
  tags: string[];
  isExclusive: boolean;
}

interface CartItem {
  beat: Beat;
  license: 'mp3' | 'wav' | 'stems' | 'exclusive';
  price: number;
}

const GENRES = ['All', 'Hip Hop', 'Trap', 'R&B', 'Pop', 'Drill', 'Afrobeat', 'Lo-Fi'];
const MOODS = ['All', 'Dark', 'Energetic', 'Chill', 'Emotional', 'Aggressive', 'Uplifting'];
const BPM_RANGES = ['All', '60-90', '90-120', '120-150', '150+'];
const KEYS = ['All', 'C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

const SAMPLE_BEATS: Beat[] = [
  {
    id: '1',
    title: 'Midnight Dreams',
    producer: 'BeatMaker Pro',
    producerImage: IMAGES.artists[0],
    coverImage: IMAGES.albums[0],
    bpm: 140,
    key: 'C Minor',
    genre: 'Trap',
    mood: 'Dark',
    duration: '3:24',
    plays: 12500,
    price: { mp3: 29.99, wav: 49.99, stems: 99.99, exclusive: 499.99 },
    tags: ['dark', 'trap', 'hard'],
    isExclusive: false,
  },
  {
    id: '2',
    title: 'Summer Vibes',
    producer: 'Wave Studios',
    producerImage: IMAGES.artists[1],
    coverImage: IMAGES.albums[1],
    bpm: 95,
    key: 'G Major',
    genre: 'R&B',
    mood: 'Chill',
    duration: '4:12',
    plays: 8900,
    price: { mp3: 24.99, wav: 44.99, stems: 89.99, exclusive: 399.99 },
    tags: ['smooth', 'rnb', 'summer'],
    isExclusive: false,
  },
  {
    id: '3',
    title: 'Street Anthem',
    producer: 'DrillKing',
    producerImage: IMAGES.artists[2],
    coverImage: IMAGES.albums[2],
    bpm: 145,
    key: 'F Minor',
    genre: 'Drill',
    mood: 'Aggressive',
    duration: '2:58',
    plays: 15200,
    price: { mp3: 34.99, wav: 54.99, stems: 109.99, exclusive: 599.99 },
    tags: ['drill', 'uk', 'hard'],
    isExclusive: false,
  },
  {
    id: '4',
    title: 'Emotional Journey',
    producer: 'SoulBeats',
    producerImage: IMAGES.artists[3],
    coverImage: IMAGES.albums[3],
    bpm: 75,
    key: 'A Minor',
    genre: 'Hip Hop',
    mood: 'Emotional',
    duration: '3:45',
    plays: 6700,
    price: { mp3: 19.99, wav: 39.99, stems: 79.99, exclusive: 349.99 },
    tags: ['emotional', 'piano', 'sad'],
    isExclusive: false,
  },
  {
    id: '5',
    title: 'Club Banger',
    producer: 'PartyMaster',
    producerImage: IMAGES.artists[4],
    coverImage: IMAGES.albums[4],
    bpm: 128,
    key: 'E Minor',
    genre: 'Pop',
    mood: 'Energetic',
    duration: '3:15',
    plays: 22100,
    price: { mp3: 39.99, wav: 59.99, stems: 119.99, exclusive: 699.99 },
    tags: ['club', 'dance', 'party'],
    isExclusive: false,
  },
  {
    id: '6',
    title: 'Lagos Nights',
    producer: 'AfroWave',
    producerImage: IMAGES.artists[5],
    coverImage: IMAGES.albums[5],
    bpm: 105,
    key: 'D Major',
    genre: 'Afrobeat',
    mood: 'Uplifting',
    duration: '3:52',
    plays: 18400,
    price: { mp3: 29.99, wav: 49.99, stems: 99.99, exclusive: 449.99 },
    tags: ['afro', 'dance', 'summer'],
    isExclusive: false,
  },
  {
    id: '7',
    title: 'Study Session',
    producer: 'LoFi Dreams',
    producerImage: IMAGES.artists[6],
    coverImage: IMAGES.albums[6],
    bpm: 85,
    key: 'B Minor',
    genre: 'Lo-Fi',
    mood: 'Chill',
    duration: '4:30',
    plays: 9800,
    price: { mp3: 14.99, wav: 29.99, stems: 59.99, exclusive: 249.99 },
    tags: ['lofi', 'chill', 'study'],
    isExclusive: false,
  },
  {
    id: '8',
    title: 'Exclusive Fire',
    producer: 'Elite Beats',
    producerImage: IMAGES.artists[7],
    coverImage: IMAGES.albums[7],
    bpm: 138,
    key: 'G Minor',
    genre: 'Trap',
    mood: 'Dark',
    duration: '3:08',
    plays: 5200,
    price: { mp3: 0, wav: 0, stems: 0, exclusive: 999.99 },
    tags: ['exclusive', 'premium', 'fire'],
    isExclusive: true,
  },
];

export default function BeatsScreen() {
  const router = useRouter();
  const { profile, addNotification } = useAuth();
  const { updateWallet } = useApp();
  
  const [beats, setBeats] = useState<Beat[]>(SAMPLE_BEATS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showBeatDetail, setShowBeatDetail] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showPurchaseHistory, setShowPurchaseHistory] = useState(false);
  const [showLicenseViewer, setShowLicenseViewer] = useState(false);
  const [selectedBeat, setSelectedBeat] = useState<Beat | null>(null);
  const [selectedLicense, setSelectedLicense] = useState<'mp3' | 'wav' | 'stems' | 'exclusive'>('mp3');
  const [selectedPurchase, setSelectedPurchase] = useState<PurchasedBeat | null>(null);
  const [purchaseHistory, setPurchaseHistory] = useState<PurchasedBeat[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [playingBeat, setPlayingBeat] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Filters
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [selectedMood, setSelectedMood] = useState('All');
  const [selectedBpmRange, setSelectedBpmRange] = useState('All');
  const [selectedKey, setSelectedKey] = useState('All');
  const [sortBy, setSortBy] = useState<'popular' | 'newest' | 'price_low' | 'price_high'>('popular');

  const filteredBeats = beats.filter(beat => {
    if (searchQuery && !beat.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !beat.producer.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (selectedGenre !== 'All' && beat.genre !== selectedGenre) return false;
    if (selectedMood !== 'All' && beat.mood !== selectedMood) return false;
    if (selectedKey !== 'All' && !beat.key.includes(selectedKey)) return false;
    
    if (selectedBpmRange !== 'All') {
      const [min, max] = selectedBpmRange.includes('+') 
        ? [parseInt(selectedBpmRange), 999] 
        : selectedBpmRange.split('-').map(Number);
      if (beat.bpm < min || beat.bpm > max) return false;
    }
    
    return true;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'popular': return b.plays - a.plays;
      case 'newest': return 0;
      case 'price_low': return a.price.mp3 - b.price.mp3;
      case 'price_high': return b.price.mp3 - a.price.mp3;
      default: return 0;
    }
  });

  const addToCart = (beat: Beat, license: 'mp3' | 'wav' | 'stems' | 'exclusive') => {
    const existingItem = cart.find(item => item.beat.id === beat.id);
    if (existingItem) {
      Alert.alert('Already in Cart', 'This beat is already in your cart');
      return;
    }

    const price = beat.price[license];
    setCart([...cart, { beat, license, price }]);
    setShowBeatDetail(false);
    
    Alert.alert('Added to Cart', `${beat.title} (${license.toUpperCase()}) added to cart`);
  };

  const removeFromCart = (beatId: string) => {
    setCart(cart.filter(item => item.beat.id !== beatId));
  };

  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price, 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      Alert.alert('Cart Empty', 'Add some beats to your cart first');
      return;
    }
    setShowCart(false);
    setShowCheckout(true);
  };

  const processPayment = async () => {
    const total = getCartTotal();
    setIsProcessing(true);
    
    try {
      // Process each item in cart
      const purchases: PurchasedBeat[] = [];
      
      for (const item of cart) {
        const result = await LicenseDeliveryService.processBeatPurchase(
          item.beat.id,
          item.beat.title,
          item.beat.producer,
          item.beat.id, // producer ID
          item.beat.coverImage,
          item.license,
          item.price,
          profile?.displayName || 'Artist',
          profile?.email || 'user@example.com'
        );
        
        if (result.success && result.purchase) {
          purchases.push(result.purchase);
        }
      }
      
      // Update purchase history
      setPurchaseHistory(prev => [...prev, ...purchases]);
      
      // Add notification
      addNotification({
        type: 'purchase',
        title: 'Purchase Complete!',
        message: `You purchased ${cart.length} beat(s) for $${total.toFixed(2)}. Check your purchase history for download links.`,
      });
      
      setCart([]);
      setShowCheckout(false);
      setIsProcessing(false);
      
      Alert.alert(
        'Purchase Successful!',
        'Your beats have been purchased.\n\nLicense agreements have been generated and download links are available in your Purchase History.',
        [
          { text: 'View Purchases', onPress: () => setShowPurchaseHistory(true) },
          { text: 'OK' }
        ]
      );
    } catch (error) {
      setIsProcessing(false);
      Alert.alert('Error', 'Failed to process payment. Please try again.');
    }
  };

  const handleDownload = (purchase: PurchasedBeat) => {
    const canDownload = LicenseDeliveryService.canDownload(purchase.id);
    
    if (!canDownload.canDownload) {
      Alert.alert('Download Unavailable', canDownload.reason);
      return;
    }
    
    LicenseDeliveryService.incrementDownloadCount(purchase.id);
    
    // Update local state
    setPurchaseHistory(prev => prev.map(p => 
      p.id === purchase.id 
        ? { ...p, downloadCount: p.downloadCount + 1 }
        : p
    ));
    
    Alert.alert(
      'Download Started',
      `Downloading ${purchase.beatTitle} (${purchase.licenseName})...\n\nDownloads remaining: ${purchase.maxDownloads - purchase.downloadCount - 1}`
    );
  };

  const viewLicense = (purchase: PurchasedBeat) => {
    setSelectedPurchase(purchase);
    setShowLicenseViewer(true);
  };

  const openBeatDetail = (beat: Beat) => {
    setSelectedBeat(beat);
    setSelectedLicense(beat.isExclusive ? 'exclusive' : 'mp3');
    setShowBeatDetail(true);
  };

  const togglePlay = (beatId: string) => {
    setPlayingBeat(playingBeat === beatId ? null : beatId);
  };

  const renderBeatCard = ({ item }: { item: Beat }) => (
    <TouchableOpacity style={styles.beatCard} onPress={() => openBeatDetail(item)}>
      <View style={styles.beatImageContainer}>
        <Image source={{ uri: item.coverImage }} style={styles.beatImage} />
        <TouchableOpacity 
          style={styles.playOverlay}
          onPress={(e) => { e.stopPropagation(); togglePlay(item.id); }}
        >
          <Ionicons 
            name={playingBeat === item.id ? 'pause' : 'play'} 
            size={24} 
            color={COLORS.textPrimary} 
          />
        </TouchableOpacity>
        {item.isExclusive && (
          <View style={styles.exclusiveBadge}>
            <Text style={styles.exclusiveText}>EXCLUSIVE</Text>
          </View>
        )}
      </View>
      
      <View style={styles.beatInfo}>
        <Text style={styles.beatTitle} numberOfLines={1}>{item.title}</Text>
        <View style={styles.producerRow}>
          <Image source={{ uri: item.producerImage }} style={styles.producerThumb} />
          <Text style={styles.producerName}>{item.producer}</Text>
        </View>
        
        <View style={styles.beatMeta}>
          <View style={styles.metaItem}>
            <Ionicons name="speedometer" size={12} color={COLORS.textMuted} />
            <Text style={styles.metaText}>{item.bpm} BPM</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="musical-note" size={12} color={COLORS.textMuted} />
            <Text style={styles.metaText}>{item.key}</Text>
          </View>
        </View>
        
        <View style={styles.beatFooter}>
          <Text style={styles.beatPrice}>
            {item.isExclusive ? `$${item.price.exclusive}` : `From $${item.price.mp3}`}
          </Text>
          <View style={styles.playsCount}>
            <Ionicons name="play" size={12} color={COLORS.textMuted} />
            <Text style={styles.playsText}>{(item.plays / 1000).toFixed(1)}K</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  const renderPurchaseItem = ({ item }: { item: PurchasedBeat }) => {
    const isExpired = item.expiryDate && item.expiryDate < Date.now();
    const downloadsLeft = item.maxDownloads - item.downloadCount;
    
    return (
      <View style={[styles.purchaseItem, isExpired && styles.purchaseExpired]}>
        <Image source={{ uri: item.coverImage }} style={styles.purchaseImage} />
        <View style={styles.purchaseInfo}>
          <Text style={styles.purchaseTitle}>{item.beatTitle}</Text>
          <Text style={styles.purchaseLicense}>{item.licenseName}</Text>
          <Text style={styles.purchaseProducer}>by {item.producerName}</Text>
          <Text style={styles.purchaseDate}>
            Purchased: {new Date(item.purchaseDate).toLocaleDateString()}
          </Text>
          {item.expiryDate && (
            <Text style={[styles.purchaseExpiry, isExpired && styles.expiredText]}>
              {isExpired ? 'EXPIRED' : `Expires: ${new Date(item.expiryDate).toLocaleDateString()}`}
            </Text>
          )}
          <Text style={styles.downloadsLeft}>
            Downloads: {item.downloadCount}/{item.maxDownloads}
          </Text>
        </View>
        <View style={styles.purchaseActions}>
          <TouchableOpacity 
            style={[styles.downloadBtn, (isExpired || downloadsLeft <= 0) && styles.downloadBtnDisabled]}
            onPress={() => handleDownload(item)}
            disabled={isExpired || downloadsLeft <= 0}
          >
            <Ionicons name="download" size={18} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.licenseBtn}
            onPress={() => viewLicense(item)}
          >
            <Ionicons name="document-text" size={18} color={COLORS.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>Beat Store</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.historyBtn} onPress={() => setShowPurchaseHistory(true)}>
            <Ionicons name="receipt" size={22} color={COLORS.textPrimary} />
            {purchaseHistory.length > 0 && (
              <View style={styles.historyBadge}>
                <Text style={styles.historyBadgeText}>{purchaseHistory.length}</Text>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity style={styles.cartBtn} onPress={() => setShowCart(true)}>
            <Ionicons name="cart" size={24} color={COLORS.textPrimary} />
            {cart.length > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>{cart.length}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color={COLORS.textMuted} />
          <TextInput
            style={styles.searchInput}
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search beats, producers..."
            placeholderTextColor={COLORS.textMuted}
          />
          {searchQuery && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Ionicons name="close-circle" size={20} color={COLORS.textMuted} />
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity style={styles.filterBtn} onPress={() => setShowFilters(true)}>
          <Ionicons name="options" size={20} color={COLORS.textPrimary} />
        </TouchableOpacity>
      </View>

      {/* Genre Pills */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false} 
        contentContainerStyle={styles.genrePills}
      >
        {GENRES.map(genre => (
          <TouchableOpacity
            key={genre}
            style={[styles.genrePill, selectedGenre === genre && styles.genrePillActive]}
            onPress={() => setSelectedGenre(genre)}
          >
            <Text style={[styles.genrePillText, selectedGenre === genre && styles.genrePillTextActive]}>
              {genre}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Results Count & Sort */}
      <View style={styles.resultsBar}>
        <Text style={styles.resultsCount}>{filteredBeats.length} beats found</Text>
        <TouchableOpacity style={styles.sortBtn}>
          <Text style={styles.sortText}>Sort: {sortBy.replace('_', ' ')}</Text>
          <Ionicons name="chevron-down" size={16} color={COLORS.textMuted} />
        </TouchableOpacity>
      </View>

      {/* Beats Grid */}
      <FlatList
        data={filteredBeats}
        renderItem={renderBeatCard}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.beatsGrid}
        columnWrapperStyle={styles.beatsRow}
        showsVerticalScrollIndicator={false}
      />

      {/* Beat Detail Modal */}
      <Modal visible={showBeatDetail} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Beat Details</Text>
              <TouchableOpacity onPress={() => setShowBeatDetail(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {selectedBeat && (
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.beatDetailHeader}>
                  <Image source={{ uri: selectedBeat.coverImage }} style={styles.detailImage} />
                  <TouchableOpacity 
                    style={styles.detailPlayBtn}
                    onPress={() => togglePlay(selectedBeat.id)}
                  >
                    <Ionicons 
                      name={playingBeat === selectedBeat.id ? 'pause' : 'play'} 
                      size={32} 
                      color={COLORS.textPrimary} 
                    />
                  </TouchableOpacity>
                </View>

                <Text style={styles.detailTitle}>{selectedBeat.title}</Text>
                
                <TouchableOpacity style={styles.detailProducer}>
                  <Image source={{ uri: selectedBeat.producerImage }} style={styles.detailProducerImage} />
                  <View>
                    <Text style={styles.detailProducerName}>{selectedBeat.producer}</Text>
                    <Text style={styles.detailProducerLabel}>Producer</Text>
                  </View>
                </TouchableOpacity>

                <View style={styles.detailMeta}>
                  <View style={styles.detailMetaItem}>
                    <Text style={styles.detailMetaLabel}>BPM</Text>
                    <Text style={styles.detailMetaValue}>{selectedBeat.bpm}</Text>
                  </View>
                  <View style={styles.detailMetaItem}>
                    <Text style={styles.detailMetaLabel}>Key</Text>
                    <Text style={styles.detailMetaValue}>{selectedBeat.key}</Text>
                  </View>
                  <View style={styles.detailMetaItem}>
                    <Text style={styles.detailMetaLabel}>Genre</Text>
                    <Text style={styles.detailMetaValue}>{selectedBeat.genre}</Text>
                  </View>
                  <View style={styles.detailMetaItem}>
                    <Text style={styles.detailMetaLabel}>Duration</Text>
                    <Text style={styles.detailMetaValue}>{selectedBeat.duration}</Text>
                  </View>
                </View>

                <View style={styles.tagsContainer}>
                  {selectedBeat.tags.map(tag => (
                    <View key={tag} style={styles.tag}>
                      <Text style={styles.tagText}>#{tag}</Text>
                    </View>
                  ))}
                </View>

                <Text style={styles.licenseTitle}>Select License</Text>
                
                {!selectedBeat.isExclusive ? (
                  <View style={styles.licenseOptions}>
                    {[
                      { id: 'mp3', name: 'MP3 Lease', desc: 'MP3 file, 5000 streams, 1 year', price: selectedBeat.price.mp3 },
                      { id: 'wav', name: 'WAV Lease', desc: 'WAV file, 10000 streams, 2 years', price: selectedBeat.price.wav },
                      { id: 'stems', name: 'Trackout', desc: 'All stems, 25000 streams, 3 years', price: selectedBeat.price.stems },
                      { id: 'exclusive', name: 'Exclusive', desc: 'Full ownership, unlimited, lifetime', price: selectedBeat.price.exclusive },
                    ].map(license => (
                      <TouchableOpacity
                        key={license.id}
                        style={[
                          styles.licenseOption,
                          selectedLicense === license.id && styles.licenseOptionActive
                        ]}
                        onPress={() => setSelectedLicense(license.id as any)}
                      >
                        <View style={styles.licenseInfo}>
                          <Text style={styles.licenseName}>{license.name}</Text>
                          <Text style={styles.licenseDesc}>{license.desc}</Text>
                        </View>
                        <Text style={styles.licensePrice}>${license.price}</Text>
                        {selectedLicense === license.id && (
                          <Ionicons name="checkmark-circle" size={24} color={COLORS.success} />
                        )}
                      </TouchableOpacity>
                    ))}
                  </View>
                ) : (
                  <View style={styles.exclusiveOnly}>
                    <Ionicons name="diamond" size={32} color={COLORS.gold} />
                    <Text style={styles.exclusiveOnlyTitle}>Exclusive Rights Only</Text>
                    <Text style={styles.exclusiveOnlyDesc}>
                      This beat is only available for exclusive purchase. You will own full rights.
                    </Text>
                    <Text style={styles.exclusiveOnlyPrice}>${selectedBeat.price.exclusive}</Text>
                  </View>
                )}

                <TouchableOpacity 
                  style={styles.addToCartBtn}
                  onPress={() => addToCart(selectedBeat, selectedLicense)}
                >
                  <Ionicons name="cart" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.addToCartText}>
                    Add to Cart - ${selectedBeat.price[selectedLicense]}
                  </Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>

      {/* Cart Modal */}
      <Modal visible={showCart} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Shopping Cart ({cart.length})</Text>
              <TouchableOpacity onPress={() => setShowCart(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {cart.length === 0 ? (
              <View style={styles.emptyCart}>
                <Ionicons name="cart-outline" size={64} color={COLORS.textMuted} />
                <Text style={styles.emptyCartText}>Your cart is empty</Text>
                <Text style={styles.emptyCartSubtext}>Browse beats and add them to your cart</Text>
              </View>
            ) : (
              <>
                <ScrollView style={styles.cartList}>
                  {cart.map(item => (
                    <View key={item.beat.id} style={styles.cartItem}>
                      <Image source={{ uri: item.beat.coverImage }} style={styles.cartItemImage} />
                      <View style={styles.cartItemInfo}>
                        <Text style={styles.cartItemTitle}>{item.beat.title}</Text>
                        <Text style={styles.cartItemLicense}>{item.license.toUpperCase()} License</Text>
                        <Text style={styles.cartItemProducer}>by {item.beat.producer}</Text>
                      </View>
                      <View style={styles.cartItemRight}>
                        <Text style={styles.cartItemPrice}>${item.price}</Text>
                        <TouchableOpacity onPress={() => removeFromCart(item.beat.id)}>
                          <Ionicons name="trash-outline" size={20} color={COLORS.error} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  ))}
                </ScrollView>

                <View style={styles.cartSummary}>
                  <View style={styles.cartTotalRow}>
                    <Text style={styles.cartTotalLabel}>Subtotal</Text>
                    <Text style={styles.cartTotalValue}>${getCartTotal().toFixed(2)}</Text>
                  </View>
                  <TouchableOpacity style={styles.checkoutBtn} onPress={handleCheckout}>
                    <Ionicons name="lock-closed" size={20} color={COLORS.textPrimary} />
                    <Text style={styles.checkoutBtnText}>Checkout - ${getCartTotal().toFixed(2)}</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Checkout Modal */}
      <Modal visible={showCheckout} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Checkout</Text>
              <TouchableOpacity onPress={() => setShowCheckout(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <View style={styles.checkoutSummary}>
              <Text style={styles.checkoutTitle}>Order Summary</Text>
              {cart.map(item => (
                <View key={item.beat.id} style={styles.checkoutItem}>
                  <Text style={styles.checkoutItemName}>{item.beat.title}</Text>
                  <Text style={styles.checkoutItemLicense}>{item.license.toUpperCase()}</Text>
                  <Text style={styles.checkoutItemPrice}>${item.price}</Text>
                </View>
              ))}
              <View style={styles.checkoutTotal}>
                <Text style={styles.checkoutTotalLabel}>Total</Text>
                <Text style={styles.checkoutTotalValue}>${getCartTotal().toFixed(2)}</Text>
              </View>
            </View>

            <View style={styles.paymentInfo}>
              <Text style={styles.paymentTitle}>Payment Method</Text>
              <View style={styles.paymentMethod}>
                <Ionicons name="card" size={24} color={COLORS.primary} />
                <Text style={styles.paymentMethodText}>Credit/Debit Card</Text>
                <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
              </View>
            </View>

            <View style={styles.licenseNote}>
              <Ionicons name="document-text" size={20} color={COLORS.gold} />
              <Text style={styles.licenseNoteText}>
                License agreements will be automatically generated and sent to your email. You can re-download files from your Purchase History.
              </Text>
            </View>

            <TouchableOpacity 
              style={[styles.payBtn, isProcessing && styles.payBtnDisabled]} 
              onPress={processPayment}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <Text style={styles.payBtnText}>Processing...</Text>
              ) : (
                <>
                  <Ionicons name="lock-closed" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.payBtnText}>Pay ${getCartTotal().toFixed(2)}</Text>
                </>
              )}
            </TouchableOpacity>

            <View style={styles.secureNote}>
              <Ionicons name="shield-checkmark" size={14} color={COLORS.success} />
              <Text style={styles.secureNoteText}>Secured by Stripe</Text>
            </View>
          </View>
        </View>
      </Modal>

      {/* Purchase History Modal */}
      <Modal visible={showPurchaseHistory} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Purchase History</Text>
              <TouchableOpacity onPress={() => setShowPurchaseHistory(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {purchaseHistory.length === 0 ? (
              <View style={styles.emptyCart}>
                <Ionicons name="receipt-outline" size={64} color={COLORS.textMuted} />
                <Text style={styles.emptyCartText}>No purchases yet</Text>
                <Text style={styles.emptyCartSubtext}>Your purchased beats will appear here</Text>
              </View>
            ) : (
              <FlatList
                data={purchaseHistory}
                renderItem={renderPurchaseItem}
                keyExtractor={item => item.id}
                contentContainerStyle={styles.purchaseList}
              />
            )}
          </View>
        </View>
      </Modal>

      {/* License Viewer Modal */}
      <Modal visible={showLicenseViewer} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>License Agreement</Text>
              <TouchableOpacity onPress={() => setShowLicenseViewer(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {selectedPurchase && (
              <ScrollView style={styles.licenseViewer}>
                <View style={styles.licenseHeader}>
                  <Ionicons name="document-text" size={48} color={COLORS.primary} />
                  <Text style={styles.licenseHeaderTitle}>{selectedPurchase.licenseName}</Text>
                  <Text style={styles.licenseHeaderBeat}>"{selectedPurchase.beatTitle}"</Text>
                </View>

                <View style={styles.licenseSection}>
                  <Text style={styles.licenseSectionTitle}>License Details</Text>
                  <View style={styles.licenseRow}>
                    <Text style={styles.licenseLabel}>License Type:</Text>
                    <Text style={styles.licenseValue}>{selectedPurchase.licenseName}</Text>
                  </View>
                  <View style={styles.licenseRow}>
                    <Text style={styles.licenseLabel}>Producer:</Text>
                    <Text style={styles.licenseValue}>{selectedPurchase.producerName}</Text>
                  </View>
                  <View style={styles.licenseRow}>
                    <Text style={styles.licenseLabel}>Purchase Date:</Text>
                    <Text style={styles.licenseValue}>
                      {new Date(selectedPurchase.purchaseDate).toLocaleDateString()}
                    </Text>
                  </View>
                  <View style={styles.licenseRow}>
                    <Text style={styles.licenseLabel}>Price Paid:</Text>
                    <Text style={styles.licenseValue}>${selectedPurchase.price.toFixed(2)}</Text>
                  </View>
                  {selectedPurchase.expiryDate && (
                    <View style={styles.licenseRow}>
                      <Text style={styles.licenseLabel}>Expires:</Text>
                      <Text style={styles.licenseValue}>
                        {new Date(selectedPurchase.expiryDate).toLocaleDateString()}
                      </Text>
                    </View>
                  )}
                </View>

                <View style={styles.licenseSection}>
                  <Text style={styles.licenseSectionTitle}>Usage Rights</Text>
                  {LICENSE_TYPES[selectedPurchase.licenseType] && (
                    <>
                      <View style={styles.licenseRow}>
                        <Text style={styles.licenseLabel}>Streams:</Text>
                        <Text style={styles.licenseValue}>
                          {LICENSE_TYPES[selectedPurchase.licenseType].streams === 'unlimited' 
                            ? 'Unlimited' 
                            : LICENSE_TYPES[selectedPurchase.licenseType].streams.toLocaleString()}
                        </Text>
                      </View>
                      <View style={styles.licenseRow}>
                        <Text style={styles.licenseLabel}>Downloads/Sales:</Text>
                        <Text style={styles.licenseValue}>
                          {LICENSE_TYPES[selectedPurchase.licenseType].downloads === 'unlimited' 
                            ? 'Unlimited' 
                            : LICENSE_TYPES[selectedPurchase.licenseType].downloads.toLocaleString()}
                        </Text>
                      </View>
                      <View style={styles.licenseRow}>
                        <Text style={styles.licenseLabel}>Radio Play:</Text>
                        <Text style={[styles.licenseValue, LICENSE_TYPES[selectedPurchase.licenseType].radioPlay ? styles.allowed : styles.notAllowed]}>
                          {LICENSE_TYPES[selectedPurchase.licenseType].radioPlay ? 'Allowed' : 'Not Allowed'}
                        </Text>
                      </View>
                      <View style={styles.licenseRow}>
                        <Text style={styles.licenseLabel}>Music Video:</Text>
                        <Text style={[styles.licenseValue, LICENSE_TYPES[selectedPurchase.licenseType].musicVideo ? styles.allowed : styles.notAllowed]}>
                          {LICENSE_TYPES[selectedPurchase.licenseType].musicVideo ? 'Allowed' : 'Not Allowed'}
                        </Text>
                      </View>
                    </>
                  )}
                </View>

                <TouchableOpacity style={styles.downloadLicenseBtn}>
                  <Ionicons name="download" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.downloadLicenseBtnText}>Download PDF License</Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>

      {/* Filters Modal */}
      <Modal visible={showFilters} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Filters</Text>
              <TouchableOpacity onPress={() => setShowFilters(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.filterLabel}>Genre</Text>
              <View style={styles.filterOptions}>
                {GENRES.map(genre => (
                  <TouchableOpacity
                    key={genre}
                    style={[styles.filterOption, selectedGenre === genre && styles.filterOptionActive]}
                    onPress={() => setSelectedGenre(genre)}
                  >
                    <Text style={[styles.filterOptionText, selectedGenre === genre && styles.filterOptionTextActive]}>
                      {genre}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.filterLabel}>Mood</Text>
              <View style={styles.filterOptions}>
                {MOODS.map(mood => (
                  <TouchableOpacity
                    key={mood}
                    style={[styles.filterOption, selectedMood === mood && styles.filterOptionActive]}
                    onPress={() => setSelectedMood(mood)}
                  >
                    <Text style={[styles.filterOptionText, selectedMood === mood && styles.filterOptionTextActive]}>
                      {mood}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.filterLabel}>BPM Range</Text>
              <View style={styles.filterOptions}>
                {BPM_RANGES.map(range => (
                  <TouchableOpacity
                    key={range}
                    style={[styles.filterOption, selectedBpmRange === range && styles.filterOptionActive]}
                    onPress={() => setSelectedBpmRange(range)}
                  >
                    <Text style={[styles.filterOptionText, selectedBpmRange === range && styles.filterOptionTextActive]}>
                      {range}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.filterLabel}>Key</Text>
              <View style={styles.filterOptions}>
                {KEYS.map(key => (
                  <TouchableOpacity
                    key={key}
                    style={[styles.filterOption, selectedKey === key && styles.filterOptionActive]}
                    onPress={() => setSelectedKey(key)}
                  >
                    <Text style={[styles.filterOptionText, selectedKey === key && styles.filterOptionTextActive]}>
                      {key}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            <View style={styles.filterActions}>
              <TouchableOpacity 
                style={styles.clearFiltersBtn}
                onPress={() => {
                  setSelectedGenre('All');
                  setSelectedMood('All');
                  setSelectedBpmRange('All');
                  setSelectedKey('All');
                }}
              >
                <Text style={styles.clearFiltersBtnText}>Clear All</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.applyFiltersBtn}
                onPress={() => setShowFilters(false)}
              >
                <Text style={styles.applyFiltersBtnText}>Apply Filters</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  historyBtn: { position: 'relative' },
  historyBadge: { position: 'absolute', top: -6, right: -6, backgroundColor: COLORS.success, width: 16, height: 16, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  historyBadgeText: { color: COLORS.textPrimary, fontSize: 10, fontWeight: '700' },
  cartBtn: { position: 'relative' },
  cartBadge: { position: 'absolute', top: -8, right: -8, backgroundColor: COLORS.error, width: 18, height: 18, borderRadius: 9, justifyContent: 'center', alignItems: 'center' },
  cartBadgeText: { color: COLORS.textPrimary, fontSize: 11, fontWeight: '700' },
  searchContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 12, marginBottom: 12 },
  searchBar: { flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, borderRadius: 12, paddingHorizontal: 12, gap: 8 },
  searchInput: { flex: 1, color: COLORS.textPrimary, paddingVertical: 12 },
  filterBtn: { width: 48, height: 48, backgroundColor: COLORS.primary, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  genrePills: { paddingHorizontal: 20, gap: 8, marginBottom: 12 },
  genrePill: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: COLORS.backgroundCard, borderRadius: 20 },
  genrePillActive: { backgroundColor: COLORS.primary },
  genrePillText: { color: COLORS.textMuted, fontWeight: '600' },
  genrePillTextActive: { color: COLORS.textPrimary },
  resultsBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, marginBottom: 12 },
  resultsCount: { color: COLORS.textMuted },
  sortBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  sortText: { color: COLORS.textSecondary, fontSize: 13 },
  beatsGrid: { paddingHorizontal: 20, paddingBottom: 180 },
  beatsRow: { justifyContent: 'space-between', marginBottom: 16 },
  beatCard: { width: '48%', backgroundColor: COLORS.backgroundCard, borderRadius: 12, overflow: 'hidden' },
  beatImageContainer: { position: 'relative' },
  beatImage: { width: '100%', aspectRatio: 1 },
  playOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center' },
  exclusiveBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: COLORS.gold, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  exclusiveText: { color: COLORS.background, fontSize: 10, fontWeight: '700' },
  beatInfo: { padding: 12 },
  beatTitle: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 14 },
  producerRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
  producerThumb: { width: 20, height: 20, borderRadius: 10 },
  producerName: { color: COLORS.textMuted, fontSize: 12 },
  beatMeta: { flexDirection: 'row', gap: 12, marginTop: 8 },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { color: COLORS.textMuted, fontSize: 11 },
  beatFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  beatPrice: { color: COLORS.primary, fontWeight: '700' },
  playsCount: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  playsText: { color: COLORS.textMuted, fontSize: 11 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '90%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  beatDetailHeader: { position: 'relative', marginBottom: 16 },
  detailImage: { width: '100%', aspectRatio: 1, borderRadius: 16 },
  detailPlayBtn: { position: 'absolute', bottom: 16, right: 16, width: 56, height: 56, borderRadius: 28, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  detailTitle: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary, marginBottom: 12 },
  detailProducer: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 16 },
  detailProducerImage: { width: 44, height: 44, borderRadius: 22 },
  detailProducerName: { color: COLORS.textPrimary, fontWeight: '600' },
  detailProducerLabel: { color: COLORS.textMuted, fontSize: 12 },
  detailMeta: { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 16 },
  detailMetaItem: { alignItems: 'center' },
  detailMetaLabel: { color: COLORS.textMuted, fontSize: 12 },
  detailMetaValue: { color: COLORS.textPrimary, fontWeight: '700', marginTop: 4 },
  tagsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 20 },
  tag: { backgroundColor: COLORS.backgroundCard, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16 },
  tagText: { color: COLORS.textSecondary, fontSize: 13 },
  licenseTitle: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700', marginBottom: 12 },
  licenseOptions: { gap: 8, marginBottom: 20 },
  licenseOption: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12 },
  licenseOptionActive: { borderWidth: 2, borderColor: COLORS.primary },
  licenseInfo: { flex: 1 },
  licenseName: { color: COLORS.textPrimary, fontWeight: '600' },
  licenseDesc: { color: COLORS.textMuted, fontSize: 12, marginTop: 2 },
  licensePrice: { color: COLORS.primary, fontWeight: '700', fontSize: 18, marginRight: 12 },
  exclusiveOnly: { alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 24, borderRadius: 12, marginBottom: 20 },
  exclusiveOnlyTitle: { color: COLORS.gold, fontSize: 18, fontWeight: '700', marginTop: 12 },
  exclusiveOnlyDesc: { color: COLORS.textMuted, textAlign: 'center', marginTop: 8 },
  exclusiveOnlyPrice: { color: COLORS.textPrimary, fontSize: 32, fontWeight: '800', marginTop: 16 },
  addToCartBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, marginBottom: 20 },
  addToCartText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  emptyCart: { alignItems: 'center', paddingVertical: 60 },
  emptyCartText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '600', marginTop: 16 },
  emptyCartSubtext: { color: COLORS.textMuted, marginTop: 8 },
  cartList: { maxHeight: 300 },
  cartItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginBottom: 8 },
  cartItemImage: { width: 60, height: 60, borderRadius: 8 },
  cartItemInfo: { flex: 1, marginLeft: 12 },
  cartItemTitle: { color: COLORS.textPrimary, fontWeight: '600' },
  cartItemLicense: { color: COLORS.primary, fontSize: 12, marginTop: 2 },
  cartItemProducer: { color: COLORS.textMuted, fontSize: 12 },
  cartItemRight: { alignItems: 'flex-end', gap: 8 },
  cartItemPrice: { color: COLORS.textPrimary, fontWeight: '700' },
  cartSummary: { borderTopWidth: 1, borderTopColor: COLORS.backgroundLight, paddingTop: 16, marginTop: 16 },
  cartTotalRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  cartTotalLabel: { color: COLORS.textMuted, fontSize: 16 },
  cartTotalValue: { color: COLORS.textPrimary, fontSize: 24, fontWeight: '800' },
  checkoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12 },
  checkoutBtnText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  checkoutSummary: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginBottom: 16 },
  checkoutTitle: { color: COLORS.textPrimary, fontWeight: '700', marginBottom: 12 },
  checkoutItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  checkoutItemName: { flex: 1, color: COLORS.textPrimary },
  checkoutItemLicense: { color: COLORS.textMuted, fontSize: 12, marginRight: 12 },
  checkoutItemPrice: { color: COLORS.textPrimary, fontWeight: '600' },
  checkoutTotal: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, paddingTop: 12 },
  checkoutTotalLabel: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 18 },
  checkoutTotalValue: { color: COLORS.primary, fontWeight: '800', fontSize: 24 },
  paymentInfo: { marginBottom: 16 },
  paymentTitle: { color: COLORS.textPrimary, fontWeight: '700', marginBottom: 8 },
  paymentMethod: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, gap: 12 },
  paymentMethodText: { flex: 1, color: COLORS.textPrimary },
  licenseNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, backgroundColor: 'rgba(234,179,8,0.1)', padding: 12, borderRadius: 12, marginBottom: 16 },
  licenseNoteText: { flex: 1, color: COLORS.textMuted, fontSize: 13 },
  payBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12 },
  payBtnDisabled: { opacity: 0.6 },
  payBtnText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  secureNote: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 12 },
  secureNoteText: { color: COLORS.textMuted, fontSize: 12 },
  purchaseList: { paddingBottom: 20 },
  purchaseItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginBottom: 8 },
  purchaseExpired: { opacity: 0.6 },
  purchaseImage: { width: 60, height: 60, borderRadius: 8 },
  purchaseInfo: { flex: 1, marginLeft: 12 },
  purchaseTitle: { color: COLORS.textPrimary, fontWeight: '600' },
  purchaseLicense: { color: COLORS.primary, fontSize: 12, marginTop: 2 },
  purchaseProducer: { color: COLORS.textMuted, fontSize: 11 },
  purchaseDate: { color: COLORS.textMuted, fontSize: 10, marginTop: 4 },
  purchaseExpiry: { color: COLORS.gold, fontSize: 10 },
  expiredText: { color: COLORS.error },
  downloadsLeft: { color: COLORS.textMuted, fontSize: 10 },
  purchaseActions: { flexDirection: 'column', gap: 8 },
  downloadBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  downloadBtnDisabled: { backgroundColor: COLORS.textMuted },
  licenseBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.backgroundLight, justifyContent: 'center', alignItems: 'center' },
  licenseViewer: { maxHeight: 500 },
  licenseHeader: { alignItems: 'center', paddingVertical: 20, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundCard },
  licenseHeaderTitle: { color: COLORS.textPrimary, fontSize: 20, fontWeight: '700', marginTop: 12 },
  licenseHeaderBeat: { color: COLORS.textMuted, marginTop: 4 },
  licenseSection: { paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundCard },
  licenseSectionTitle: { color: COLORS.primary, fontWeight: '700', marginBottom: 12 },
  licenseRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  licenseLabel: { color: COLORS.textMuted },
  licenseValue: { color: COLORS.textPrimary, fontWeight: '600' },
  allowed: { color: COLORS.success },
  notAllowed: { color: COLORS.error },
  downloadLicenseBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 14, borderRadius: 12, marginTop: 20 },
  downloadLicenseBtnText: { color: COLORS.textPrimary, fontWeight: '700' },
  filterLabel: { color: COLORS.textPrimary, fontWeight: '700', marginTop: 16, marginBottom: 8 },
  filterOptions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  filterOption: { paddingHorizontal: 16, paddingVertical: 8, backgroundColor: COLORS.backgroundCard, borderRadius: 20 },
  filterOptionActive: { backgroundColor: COLORS.primary },
  filterOptionText: { color: COLORS.textMuted },
  filterOptionTextActive: { color: COLORS.textPrimary },
  filterActions: { flexDirection: 'row', gap: 12, marginTop: 24 },
  clearFiltersBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center', backgroundColor: COLORS.backgroundCard },
  clearFiltersBtnText: { color: COLORS.textPrimary, fontWeight: '600' },
  applyFiltersBtn: { flex: 1, paddingVertical: 14, borderRadius: 12, alignItems: 'center', backgroundColor: COLORS.primary },
  applyFiltersBtnText: { color: COLORS.textPrimary, fontWeight: '700' },
});
