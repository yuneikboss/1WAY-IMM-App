import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://xuntnvypdwphnnzwbypp.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM4N2NmYWE2LTBlNmQtNGU2Yi1hZjI3LTU5ZDM2ZDkwMWUyYiJ9.eyJwcm9qZWN0SWQiOiJ4dW50bnZ5cGR3cGhubnp3YnlwcCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY0OTk3MDQ2LCJleHAiOjIwODAzNTcwNDYsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.5eu3gJKjDE25EFcJPw5NAmaCCTSsNcKrURkFfMAUSHQ';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };