import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, Image, ScrollView, Alert, Modal, Animated, TextInput, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import { IMAGES } from './constants/images';
import { ARTISTS } from './data/artists';
import WaveformVisualizer from './components/WaveformVisualizer';
import { useAuth } from './context/AuthContext';
import { useApp } from './context/AppContext';
import AudioRecordingService, { 
  RecordingInfo, 
  AudioEffect,
  RecordingState 
} from './services/AudioRecordingService';

const MICROPHONES = [
  { id: 'basic', name: 'Basic', quality: 'Standard', color: COLORS.textMuted },
  { id: 'silver', name: 'Silver', quality: 'Enhanced', color: '#C0C0C0' },
  { id: 'gold', name: 'Gold', quality: 'Pro', color: COLORS.gold },
  { id: 'platinum', name: 'Platinum', quality: 'Premium', color: '#E5E4E2' },
  { id: 'diamond', name: 'Diamond', quality: 'Ultimate', color: '#B9F2FF' },
];

const TRACKS = [
  { id: '1', name: 'Vocals', color: COLORS.primary, muted: false, solo: false, volume: 80 },
  { id: '2', name: 'Beat', color: COLORS.secondary, muted: false, solo: false, volume: 70 },
  { id: '3', name: 'Bass', color: COLORS.success, muted: false, solo: false, volume: 65 },
  { id: '4', name: 'Synth', color: COLORS.gold, muted: false, solo: false, volume: 50 },
];

const TIP_AMOUNTS = [1, 5, 10, 20];

interface LiveChatMessage {
  id: string;
  user: string;
  userImage: string;
  message: string;
  timestamp: number;
  isTip?: boolean;
  tipAmount?: number;
}

interface ScheduledStream {
  id: string;
  title: string;
  description: string;
  scheduledTime: number;
  notifyCount: number;
  isNotified: boolean;
}

interface TipLeaderboardEntry {
  user: string;
  userImage: string;
  totalTips: number;
}

type StudioMode = 'record' | 'edit' | 'mix' | 'live';

export default function BoothScreen() {
  const router = useRouter();
  const { profile, addNotification, uploadMedia } = useAuth();
  const { wallet, updateWallet } = useApp();
  const [mode, setMode] = useState<StudioMode>('record');
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [featuringArtist, setFeaturingArtist] = useState<string | null>(null);
  const [viewers, setViewers] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const [showEffects, setShowEffects] = useState(false);
  const [activeEffects, setActiveEffects] = useState<AudioEffect[]>([]);
  const [tracks, setTracks] = useState(TRACKS);
  const [selectedTrack, setSelectedTrack] = useState<string | null>(null);
  const [bpm, setBpm] = useState(120);
  const [showMetronome, setShowMetronome] = useState(false);
  const [waveformData, setWaveformData] = useState<number[]>([]);
  const [currentRecording, setCurrentRecording] = useState<RecordingInfo | null>(null);
  const [savedRecordings, setSavedRecordings] = useState<RecordingInfo[]>([]);
  const [permissionGranted, setPermissionGranted] = useState(false);
  
  // Live streaming state
  const [showScheduleStream, setShowScheduleStream] = useState(false);
  const [showLiveChat, setShowLiveChat] = useState(true);
  const [showTipLeaderboard, setShowTipLeaderboard] = useState(false);
  const [liveChat, setLiveChat] = useState<LiveChatMessage[]>([]);
  const [chatMessage, setChatMessage] = useState('');
  const [totalTips, setTotalTips] = useState(0);
  const [tipLeaderboard, setTipLeaderboard] = useState<TipLeaderboardEntry[]>([]);
  const [scheduledStreams, setScheduledStreams] = useState<ScheduledStream[]>([]);
  const [streamTitle, setStreamTitle] = useState('');
  const [streamDescription, setStreamDescription] = useState('');
  const [streamDate, setStreamDate] = useState('');
  const [streamTime, setStreamTime] = useState('');
  const [showTipAnimation, setShowTipAnimation] = useState(false);
  const [lastTip, setLastTip] = useState<{ user: string; amount: number } | null>(null);
  const [liveStreamDuration, setLiveStreamDuration] = useState(0);
  
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const tipAnim = useRef(new Animated.Value(0)).current;
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const liveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const viewerInterval = useRef<NodeJS.Timeout | null>(null);
  const chatInterval = useRef<NodeJS.Timeout | null>(null);
  const chatListRef = useRef<FlatList>(null);

  const isPremium = profile?.isPremium;
  const ownedMics = profile?.ownedMics || ['basic'];
  const activeMic = profile?.activeMic || 'basic';
  const currentMic = MICROPHONES.find(m => m.id === activeMic) || MICROPHONES[0];

  // Initialize effects
  useEffect(() => {
    setActiveEffects(AudioRecordingService.getAvailableEffects());
  }, []);

  // Request microphone permission on mount
  useEffect(() => {
    const requestPermission = async () => {
      const granted = await AudioRecordingService.requestMicrophonePermission();
      setPermissionGranted(granted);
    };
    requestPermission();

    return () => {
      AudioRecordingService.cleanup();
    };
  }, []);

  // Waveform listener
  useEffect(() => {
    const unsubscribe = AudioRecordingService.addWaveformListener((data) => {
      setWaveformData(data);
    });
    return unsubscribe;
  }, []);

  // Recording timer and animation
  useEffect(() => {
    if (recordingState === 'recording') {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 500, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
        ])
      ).start();
      
      timerRef.current = setInterval(() => {
        setRecordingTime(t => t + 1);
      }, 1000);
    } else {
      pulseAnim.setValue(1);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [recordingState]);

  // Live streaming effects
  useEffect(() => {
    if (isLive) {
      // Start live stream timer
      liveTimerRef.current = setInterval(() => {
        setLiveStreamDuration(d => d + 1);
      }, 1000);

      // Simulate viewer count changes
      viewerInterval.current = setInterval(() => {
        setViewers(prev => Math.max(10, prev + Math.floor(Math.random() * 10) - 4));
      }, 5000);

      // Simulate chat messages and tips
      const sampleMessages = [
        'Fire track!',
        'Love this vibe',
        'When is the album dropping?',
        'You are so talented!',
        'This beat is crazy',
        'Keep going!',
        'Best live session ever',
        'Can you play that again?',
        'Sounds amazing!',
        'This is heat!',
      ];
      
      chatInterval.current = setInterval(() => {
        const randomArtist = ARTISTS[Math.floor(Math.random() * ARTISTS.length)];
        const randomMessage = sampleMessages[Math.floor(Math.random() * sampleMessages.length)];
        const isTip = Math.random() > 0.85;
        const tipAmount = isTip ? TIP_AMOUNTS[Math.floor(Math.random() * TIP_AMOUNTS.length)] : undefined;
        
        const newMessage: LiveChatMessage = {
          id: Date.now().toString(),
          user: randomArtist.name,
          userImage: randomArtist.image,
          message: isTip ? `Sent a $${tipAmount} tip!` : randomMessage,
          timestamp: Date.now(),
          isTip,
          tipAmount,
        };
        
        setLiveChat(prev => [...prev.slice(-100), newMessage]);
        
        if (isTip && tipAmount) {
          handleIncomingTip(randomArtist.name, randomArtist.image, tipAmount);
        }
      }, 2500);
    }

    return () => {
      if (liveTimerRef.current) clearInterval(liveTimerRef.current);
      if (viewerInterval.current) clearInterval(viewerInterval.current);
      if (chatInterval.current) clearInterval(chatInterval.current);
    };
  }, [isLive]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatListRef.current && liveChat.length > 0) {
      setTimeout(() => {
        chatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [liveChat]);

  const handleIncomingTip = (user: string, userImage: string, amount: number) => {
    setTotalTips(prev => prev + amount);
    setLastTip({ user, amount });
    setShowTipAnimation(true);
    
    // Update leaderboard
    setTipLeaderboard(prev => {
      const existing = prev.find(e => e.user === user);
      if (existing) {
        return prev.map(e => 
          e.user === user ? { ...e, totalTips: e.totalTips + amount } : e
        ).sort((a, b) => b.totalTips - a.totalTips);
      } else {
        return [...prev, { user, userImage, totalTips: amount }]
          .sort((a, b) => b.totalTips - a.totalTips)
          .slice(0, 10);
      }
    });
    
    // Animate tip
    Animated.sequence([
      Animated.timing(tipAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.delay(1500),
      Animated.timing(tipAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start(() => {
      setShowTipAnimation(false);
    });
  };

  const sendChatMessage = () => {
    if (!chatMessage.trim()) return;
    
    const newMessage: LiveChatMessage = {
      id: Date.now().toString(),
      user: profile?.displayName || 'You',
      userImage: profile?.profileImage || IMAGES.artists[0],
      message: chatMessage,
      timestamp: Date.now(),
    };
    
    setLiveChat(prev => [...prev, newMessage]);
    setChatMessage('');
  };

  const sendTip = (amount: number) => {
    if (wallet.balance < amount) {
      Alert.alert('Insufficient Balance', 'Add funds to your wallet to send tips.');
      return;
    }
    
    updateWallet(-amount);
    
    const newMessage: LiveChatMessage = {
      id: Date.now().toString(),
      user: profile?.displayName || 'You',
      userImage: profile?.profileImage || IMAGES.artists[0],
      message: `Sent a $${amount} tip!`,
      timestamp: Date.now(),
      isTip: true,
      tipAmount: amount,
    };
    
    setLiveChat(prev => [...prev, newMessage]);
    
    Alert.alert('Tip Sent!', `You sent a $${amount} tip to the streamer!`);
  };

  const scheduleStream = () => {
    if (!streamTitle.trim()) {
      Alert.alert('Error', 'Please enter a stream title');
      return;
    }
    
    const scheduledTime = Date.now() + 24 * 60 * 60 * 1000; // Default to tomorrow
    
    const newStream: ScheduledStream = {
      id: Date.now().toString(),
      title: streamTitle,
      description: streamDescription,
      scheduledTime,
      notifyCount: 0,
      isNotified: false,
    };
    
    setScheduledStreams(prev => [...prev, newStream]);
    setShowScheduleStream(false);
    setStreamTitle('');
    setStreamDescription('');
    
    addNotification({
      type: 'system',
      title: 'Stream Scheduled',
      message: `Your stream "${newStream.title}" has been scheduled. Followers will be notified.`,
    });
    
    Alert.alert('Stream Scheduled!', 'Your followers will be notified when you go live.');
  };

  const handleRecord = async () => {
    if (!permissionGranted) {
      const granted = await AudioRecordingService.requestMicrophonePermission();
      if (!granted) {
        Alert.alert('Permission Denied', 'Microphone access is required to record.');
        return;
      }
      setPermissionGranted(true);
    }

    if (recordingState === 'idle' || recordingState === 'stopped') {
      const started = await AudioRecordingService.startRecording();
      if (started) {
        setRecordingState('recording');
        setRecordingTime(0);
        setCurrentRecording(null);
        Alert.alert(
          'Recording Started', 
          `Using ${currentMic.name} Mic (${currentMic.quality} Quality)\n\nSpeak clearly into your device microphone.`
        );
      } else {
        Alert.alert('Recording Failed', 'Could not start recording. Please try again.');
      }
    } else if (recordingState === 'recording') {
      const recording = await AudioRecordingService.stopRecording();
      setRecordingState('stopped');
      
      if (recording) {
        setCurrentRecording(recording);
        Alert.alert(
          'Recording Complete!', 
          `Duration: ${formatTime(Math.floor(recording.duration / 1000))}\nQuality: ${currentMic.quality}\n\nWhat would you like to do?`,
          [
            { 
              text: 'Discard', 
              style: 'destructive',
              onPress: () => {
                AudioRecordingService.deleteRecording(recording.uri);
                setCurrentRecording(null);
              }
            },
            { text: 'Apply Effects', onPress: () => setShowEffects(true) },
            { text: 'Save', onPress: () => handleSaveRecording(recording) },
          ]
        );
      }
    } else if (recordingState === 'paused') {
      await AudioRecordingService.resumeRecording();
      setRecordingState('recording');
    }
  };

  const handlePauseRecording = async () => {
    if (recordingState === 'recording') {
      await AudioRecordingService.pauseRecording();
      setRecordingState('paused');
    }
  };

  const handleSaveRecording = async (recording: RecordingInfo) => {
    const name = `Recording_${new Date().toISOString().slice(0, 10)}_${recordingTime}s`;
    
    const enabledEffects = activeEffects.filter(e => e.enabled);
    let finalUri = recording.uri;
    
    if (enabledEffects.length > 0) {
      Alert.alert('Applying Effects', 'Processing your recording...');
      finalUri = await AudioRecordingService.applyEffectsToRecording(recording.uri);
    }

    const savedUri = await AudioRecordingService.saveRecordingLocally(
      { ...recording, uri: finalUri },
      name
    );

    uploadMedia('music', savedUri, name, recording.size);
    setSavedRecordings(prev => [...prev, { ...recording, uri: savedUri }]);

    addNotification({
      type: 'system',
      title: 'Track Saved!',
      message: `Your recording "${name}" (${formatTime(Math.floor(recording.duration / 1000))}) has been saved to your profile.`,
    });

    Alert.alert('Saved!', `Your track "${name}" has been saved to your profile.`);
    setCurrentRecording(null);
  };

  const handlePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleGoLive = () => {
    if (!isPremium) {
      Alert.alert('Premium Required', 'Live streaming is a Premium feature', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Upgrade', onPress: () => router.push('/premium') }
      ]);
      return;
    }
    
    if (isLive) {
      Alert.alert(
        'End Stream?',
        `You've been live for ${formatTime(liveStreamDuration)}.\nTotal tips: $${totalTips}`,
        [
          { text: 'Keep Streaming', style: 'cancel' },
          { 
            text: 'End Stream', 
            style: 'destructive',
            onPress: () => {
              setIsLive(false);
              setLiveStreamDuration(0);
              setLiveChat([]);
              setTotalTips(0);
              setTipLeaderboard([]);
              
              addNotification({
                type: 'system',
                title: 'Stream Ended',
                message: `Your stream lasted ${formatTime(liveStreamDuration)}. You earned $${totalTips} in tips!`,
              });
            }
          }
        ]
      );
    } else {
      setIsLive(true);
      setViewers(Math.floor(Math.random() * 100) + 10);
      Alert.alert('You are LIVE!', 'Your booth session is now streaming in crystal clear quality');
    }
  };

  const handleFaceTime = () => {
    if (featuringArtist) {
      router.push(`/videochat?artistId=${featuringArtist}`);
    } else {
      Alert.alert('Select Artist', 'Choose a featuring artist first');
    }
  };

  const handleMicChange = () => {
    router.push('/microphones');
  };

  const toggleEffect = (effectId: string) => {
    const updatedEffects = AudioRecordingService.toggleEffect(effectId);
    setActiveEffects([...updatedEffects]);
  };

  const toggleTrackMute = (trackId: string) => {
    setTracks(tracks.map(t => t.id === trackId ? { ...t, muted: !t.muted } : t));
  };

  const toggleTrackSolo = (trackId: string) => {
    setTracks(tracks.map(t => t.id === trackId ? { ...t, solo: !t.solo } : t));
  };

  const updateTrackVolume = (trackId: string, delta: number) => {
    setTracks(tracks.map(t => {
      if (t.id === trackId) {
        const newVolume = Math.max(0, Math.min(100, t.volume + delta));
        return { ...t, volume: newVolume };
      }
      return t;
    }));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const renderChatMessage = ({ item }: { item: LiveChatMessage }) => (
    <View style={[styles.chatMessage, item.isTip && styles.tipMessage]}>
      <Image source={{ uri: item.userImage }} style={styles.chatAvatar} />
      <View style={styles.chatContent}>
        <Text style={styles.chatUser}>{item.user}</Text>
        <Text style={[styles.chatText, item.isTip && styles.tipText]}>{item.message}</Text>
      </View>
      {item.isTip && (
        <View style={styles.tipBadge}>
          <Ionicons name="cash" size={14} color={COLORS.gold} />
        </View>
      )}
    </View>
  );

  const renderRecordMode = () => (
    <View style={styles.recordSection}>
      <View style={styles.waveformContainer}>
        <WaveformVisualizer 
          isRecording={recordingState === 'recording'} 
          waveformData={waveformData}
          barCount={50}
          maxHeight={100}
          color={COLORS.primary}
          activeColor={COLORS.error}
        />
      </View>

      {recordingState !== 'idle' && (
        <View style={styles.recordingStatus}>
          <Animated.View style={[
            styles.recordingDot, 
            { 
              transform: [{ scale: pulseAnim }],
              backgroundColor: recordingState === 'paused' ? COLORS.gold : COLORS.error,
            }
          ]} />
          <Text style={styles.recordingTime}>{formatTime(recordingTime)}</Text>
          <Text style={styles.recordingQuality}>
            {recordingState === 'paused' ? 'PAUSED' : `Recording in ${currentMic.quality}`}
          </Text>
        </View>
      )}

      <View style={styles.transportControls}>
        <TouchableOpacity style={styles.transportBtn} onPress={() => setRecordingTime(0)}>
          <Ionicons name="play-skip-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        
        {recordingState === 'recording' && (
          <TouchableOpacity style={styles.transportBtn} onPress={handlePauseRecording}>
            <Ionicons name="pause" size={28} color={COLORS.textPrimary} />
          </TouchableOpacity>
        )}
        
        <TouchableOpacity style={styles.transportBtn} onPress={handlePlay}>
          <Ionicons name={isPlaying ? 'pause' : 'play'} size={28} color={COLORS.textPrimary} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[
            styles.recordBtn, 
            recordingState === 'recording' && styles.recordingActive,
            recordingState === 'paused' && styles.recordingPaused,
          ]} 
          onPress={handleRecord}
        >
          <Ionicons 
            name={recordingState === 'recording' ? 'stop' : recordingState === 'paused' ? 'play' : 'mic'} 
            size={32} 
            color={COLORS.textPrimary} 
          />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.transportBtn} onPress={() => setShowMetronome(!showMetronome)}>
          <Ionicons name="metronome" size={24} color={showMetronome ? COLORS.primary : COLORS.textPrimary} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.transportBtn}>
          <Ionicons name="repeat" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
      </View>

      {showMetronome && (
        <View style={styles.metronomeBar}>
          <TouchableOpacity onPress={() => setBpm(Math.max(60, bpm - 5))}>
            <Ionicons name="remove-circle" size={24} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.bpmText}>{bpm} BPM</Text>
          <TouchableOpacity onPress={() => setBpm(Math.min(200, bpm + 5))}>
            <Ionicons name="add-circle" size={24} color={COLORS.textPrimary} />
          </TouchableOpacity>
        </View>
      )}

      {currentRecording && (
        <View style={styles.recordingPreview}>
          <Text style={styles.previewTitle}>Last Recording</Text>
          <View style={styles.previewInfo}>
            <Ionicons name="musical-note" size={20} color={COLORS.primary} />
            <Text style={styles.previewDuration}>
              {formatTime(Math.floor(currentRecording.duration / 1000))}
            </Text>
            <Text style={styles.previewSize}>
              {(currentRecording.size / 1024).toFixed(1)} KB
            </Text>
          </View>
          <View style={styles.previewActions}>
            <TouchableOpacity style={styles.previewBtn} onPress={() => setShowEffects(true)}>
              <Ionicons name="color-wand" size={16} color={COLORS.textPrimary} />
              <Text style={styles.previewBtnText}>Effects</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.previewBtn, styles.saveBtn]}
              onPress={() => handleSaveRecording(currentRecording)}
            >
              <Ionicons name="save" size={16} color={COLORS.textPrimary} />
              <Text style={styles.previewBtnText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );

  const renderEditMode = () => (
    <View style={styles.editSection}>
      <View style={styles.timelineHeader}>
        <Text style={styles.timelineTitle}>Timeline</Text>
        <View style={styles.timelineActions}>
          <TouchableOpacity style={styles.timelineBtn}>
            <Ionicons name="cut" size={20} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.timelineBtn}>
            <Ionicons name="copy" size={20} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.timelineBtn}>
            <Ionicons name="trash" size={20} color={COLORS.error} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.timeline}>
        <View style={styles.timelineContent}>
          {tracks.map(track => (
            <TouchableOpacity 
              key={track.id} 
              style={[
                styles.trackRow, 
                selectedTrack === track.id && styles.trackRowSelected,
                track.muted && styles.trackRowMuted
              ]}
              onPress={() => setSelectedTrack(track.id)}
            >
              <View style={[styles.trackLabel, { backgroundColor: track.color }]}>
                <Text style={styles.trackName}>{track.name}</Text>
              </View>
              <View style={styles.trackWaveform}>
                {[...Array(20)].map((_, i) => (
                  <View 
                    key={i} 
                    style={[
                      styles.waveformBar, 
                      { 
                        height: Math.random() * 30 + 10,
                        backgroundColor: track.muted ? COLORS.textMuted : track.color,
                      }
                    ]} 
                  />
                ))}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <View style={styles.editTools}>
        <TouchableOpacity style={styles.editTool}>
          <Ionicons name="resize" size={24} color={COLORS.textPrimary} />
          <Text style={styles.editToolText}>Trim</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.editTool}>
          <Ionicons name="swap-horizontal" size={24} color={COLORS.textPrimary} />
          <Text style={styles.editToolText}>Split</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.editTool}>
          <Ionicons name="volume-high" size={24} color={COLORS.textPrimary} />
          <Text style={styles.editToolText}>Fade</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.editTool} onPress={() => setShowEffects(true)}>
          <Ionicons name="color-wand" size={24} color={COLORS.textPrimary} />
          <Text style={styles.editToolText}>Effects</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderMixMode = () => (
    <View style={styles.mixSection}>
      <View style={styles.mixHeader}>
        <Text style={styles.mixTitle}>Mixer</Text>
        <TouchableOpacity style={styles.masterBtn}>
          <Text style={styles.masterText}>Master</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.mixerChannels}>
        {tracks.map(track => (
          <View key={track.id} style={styles.channel}>
            <Text style={styles.channelName}>{track.name}</Text>
            
            <View style={styles.faderContainer}>
              <View style={styles.faderTrack}>
                <View style={[styles.faderFill, { height: `${track.volume}%`, backgroundColor: track.color }]} />
              </View>
              <View style={styles.faderControls}>
                <TouchableOpacity onPress={() => updateTrackVolume(track.id, 5)}>
                  <Ionicons name="add" size={20} color={COLORS.textPrimary} />
                </TouchableOpacity>
                <Text style={styles.volumeText}>{track.volume}</Text>
                <TouchableOpacity onPress={() => updateTrackVolume(track.id, -5)}>
                  <Ionicons name="remove" size={20} color={COLORS.textPrimary} />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.channelButtons}>
              <TouchableOpacity 
                style={[styles.channelBtn, track.muted && styles.channelBtnActive]}
                onPress={() => toggleTrackMute(track.id)}
              >
                <Text style={styles.channelBtnText}>M</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.channelBtn, track.solo && styles.channelBtnSolo]}
                onPress={() => toggleTrackSolo(track.id)}
              >
                <Text style={styles.channelBtnText}>S</Text>
              </TouchableOpacity>
            </View>

            <View style={[styles.channelIndicator, { backgroundColor: track.color }]} />
          </View>
        ))}

        <View style={[styles.channel, styles.masterChannel]}>
          <Text style={styles.channelName}>Master</Text>
          <View style={styles.faderContainer}>
            <View style={styles.faderTrack}>
              <View style={[styles.faderFill, { height: '85%', backgroundColor: COLORS.primary }]} />
            </View>
          </View>
          <View style={styles.masterMeter}>
            <View style={[styles.meterBar, { height: '70%' }]} />
            <View style={[styles.meterBar, { height: '65%' }]} />
          </View>
        </View>
      </View>

      <TouchableOpacity style={styles.effectsBtn} onPress={() => setShowEffects(true)}>
        <Ionicons name="color-wand" size={20} color={COLORS.textPrimary} />
        <Text style={styles.effectsBtnText}>Effects ({activeEffects.filter(e => e.enabled).length})</Text>
      </TouchableOpacity>
    </View>
  );

  const renderLiveMode = () => (
    <View style={styles.liveSection}>
      {isLive ? (
        <>
          {/* Tip Animation Overlay */}
          {showTipAnimation && lastTip && (
            <Animated.View style={[styles.tipAnimationOverlay, { opacity: tipAnim }]}>
              <View style={styles.tipAnimationContent}>
                <Ionicons name="cash" size={48} color={COLORS.gold} />
                <Text style={styles.tipAnimationText}>${lastTip.amount} TIP!</Text>
                <Text style={styles.tipAnimationUser}>from {lastTip.user}</Text>
              </View>
            </Animated.View>
          )}

          <View style={styles.liveHeader}>
            <View style={styles.liveIndicator}>
              <View style={styles.liveDot} />
              <Text style={styles.liveText}>LIVE</Text>
              <Text style={styles.liveDuration}>{formatTime(liveStreamDuration)}</Text>
            </View>
            <View style={styles.liveStats}>
              <View style={styles.viewerCount}>
                <Ionicons name="eye" size={16} color={COLORS.textPrimary} />
                <Text style={styles.viewerText}>{viewers}</Text>
              </View>
              <TouchableOpacity 
                style={styles.tipsCount}
                onPress={() => setShowTipLeaderboard(true)}
              >
                <Ionicons name="cash" size={16} color={COLORS.gold} />
                <Text style={styles.tipsText}>${totalTips}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.livePreview}>
            <Image source={{ uri: IMAGES.booth }} style={styles.liveImage} />
            <View style={styles.liveOverlay}>
              <WaveformVisualizer isRecording={true} barCount={30} maxHeight={60} />
            </View>
          </View>

          {/* Live Chat */}
          {showLiveChat && (
            <View style={styles.liveChatContainer}>
              <View style={styles.chatHeader}>
                <Text style={styles.chatHeaderTitle}>Live Chat</Text>
                <TouchableOpacity onPress={() => setShowLiveChat(false)}>
                  <Ionicons name="chevron-down" size={20} color={COLORS.textMuted} />
                </TouchableOpacity>
              </View>
              
              <FlatList
                ref={chatListRef}
                data={liveChat}
                renderItem={renderChatMessage}
                keyExtractor={item => item.id}
                style={styles.chatList}
                showsVerticalScrollIndicator={false}
              />
              
              <View style={styles.chatInputContainer}>
                <TextInput
                  style={styles.chatInput}
                  value={chatMessage}
                  onChangeText={setChatMessage}
                  placeholder="Say something..."
                  placeholderTextColor={COLORS.textMuted}
                  onSubmitEditing={sendChatMessage}
                />
                <TouchableOpacity style={styles.sendBtn} onPress={sendChatMessage}>
                  <Ionicons name="send" size={20} color={COLORS.textPrimary} />
                </TouchableOpacity>
              </View>
              
              {/* Tip Buttons */}
              <View style={styles.tipButtonsContainer}>
                <Text style={styles.tipLabel}>Send Tip:</Text>
                {TIP_AMOUNTS.map(amount => (
                  <TouchableOpacity 
                    key={amount}
                    style={styles.tipButton}
                    onPress={() => sendTip(amount)}
                  >
                    <Text style={styles.tipButtonText}>${amount}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {!showLiveChat && (
            <TouchableOpacity 
              style={styles.showChatBtn}
              onPress={() => setShowLiveChat(true)}
            >
              <Ionicons name="chatbubbles" size={20} color={COLORS.textPrimary} />
              <Text style={styles.showChatBtnText}>Show Chat ({liveChat.length})</Text>
            </TouchableOpacity>
          )}

          <View style={styles.liveControls}>
            <TouchableOpacity style={styles.liveControlBtn}>
              <Ionicons name="mic" size={24} color={COLORS.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.liveControlBtn}>
              <Ionicons name="videocam" size={24} color={COLORS.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.liveControlBtn}
              onPress={() => setShowTipLeaderboard(true)}
            >
              <Ionicons name="trophy" size={24} color={COLORS.gold} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.liveControlBtn, styles.endLiveBtn]} onPress={handleGoLive}>
              <Ionicons name="close" size={24} color={COLORS.textPrimary} />
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={styles.goLiveContainer}>
          <Ionicons name="radio" size={64} color={COLORS.primary} />
          <Text style={styles.goLiveTitle}>Go Live</Text>
          <Text style={styles.goLiveDesc}>
            Stream your booth session in crystal clear HD quality to your fans
          </Text>
          
          {scheduledStreams.length > 0 && (
            <View style={styles.scheduledStreamsSection}>
              <Text style={styles.scheduledTitle}>Scheduled Streams</Text>
              {scheduledStreams.map(stream => (
                <View key={stream.id} style={styles.scheduledItem}>
                  <Ionicons name="calendar" size={20} color={COLORS.primary} />
                  <View style={styles.scheduledInfo}>
                    <Text style={styles.scheduledName}>{stream.title}</Text>
                    <Text style={styles.scheduledTime}>
                      {new Date(stream.scheduledTime).toLocaleString()}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          )}
          
          <View style={styles.goLiveActions}>
            <TouchableOpacity style={styles.goLiveBtn} onPress={handleGoLive}>
              <Ionicons name="radio" size={24} color={COLORS.textPrimary} />
              <Text style={styles.goLiveBtnText}>Start Live Session</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.scheduleBtn}
              onPress={() => setShowScheduleStream(true)}
            >
              <Ionicons name="calendar" size={20} color={COLORS.primary} />
              <Text style={styles.scheduleBtnText}>Schedule Stream</Text>
            </TouchableOpacity>
          </View>
          
          {!isPremium && (
            <View style={styles.premiumRequired}>
              <Ionicons name="diamond" size={16} color={COLORS.gold} />
              <Text style={styles.premiumRequiredText}>Premium Required</Text>
            </View>
          )}
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>1Way Music Studio</Text>
        {isLive && (
          <View style={styles.liveTag}>
            <View style={styles.liveDotSmall} />
            <Text style={styles.liveTagText}>LIVE</Text>
          </View>
        )}
      </View>

      <TouchableOpacity style={styles.micIndicator} onPress={handleMicChange}>
        <View style={[styles.micDot, { backgroundColor: currentMic.color }]} />
        <View style={styles.micInfo}>
          <Text style={styles.micName}>{currentMic.name} Mic</Text>
          <Text style={styles.micQuality}>{currentMic.quality} Quality</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
      </TouchableOpacity>

      <View style={styles.modeSelector}>
        {([
          { id: 'record', icon: 'mic', label: 'Record' },
          { id: 'edit', icon: 'create', label: 'Edit' },
          { id: 'mix', icon: 'options', label: 'Mix' },
          { id: 'live', icon: 'radio', label: 'Live' },
        ] as const).map(m => (
          <TouchableOpacity 
            key={m.id} 
            style={[styles.modeBtn, mode === m.id && styles.modeActive]} 
            onPress={() => setMode(m.id)}
          >
            <Ionicons 
              name={m.icon} 
              size={20} 
              color={mode === m.id ? COLORS.textPrimary : COLORS.textMuted} 
            />
            <Text style={[styles.modeText, mode === m.id && styles.modeTextActive]}>
              {m.label}
            </Text>
            {m.id === 'live' && !isPremium && (
              <View style={styles.premiumBadge}>
                <Ionicons name="diamond" size={10} color={COLORS.gold} />
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} contentContainerStyle={styles.contentContainer}>
        {mode === 'record' && renderRecordMode()}
        {mode === 'edit' && renderEditMode()}
        {mode === 'mix' && renderMixMode()}
        {mode === 'live' && renderLiveMode()}

        {mode !== 'live' && (
          <>
            <View style={styles.featureSection}>
              <Text style={styles.sectionTitle}>Featuring Artist</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.artistList}>
                {ARTISTS.slice(0, 6).map(artist => (
                  <TouchableOpacity 
                    key={artist.id} 
                    style={[styles.artistChip, featuringArtist === artist.id && styles.artistSelected]} 
                    onPress={() => setFeaturingArtist(artist.id)}
                  >
                    <Image source={{ uri: artist.image }} style={styles.artistThumb} />
                    <Text style={styles.artistName}>{artist.name}</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
              {featuringArtist && (
                <TouchableOpacity style={styles.faceTimeBtn} onPress={handleFaceTime}>
                  <Ionicons name="videocam" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.faceTimeText}>FaceTime with Artist (Crystal Clear HD)</Text>
                </TouchableOpacity>
              )}
            </View>

            <View style={styles.qualityNote}>
              <Ionicons name="sparkles" size={16} color={COLORS.gold} />
              <Text style={styles.qualityNoteText}>
                Crystal clear recording & mixing with state-of-the-art technology
              </Text>
            </View>
          </>
        )}
      </ScrollView>

      {/* Effects Modal */}
      <Modal visible={showEffects} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Audio Effects</Text>
              <TouchableOpacity onPress={() => setShowEffects(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.effectsGrid}>
              {activeEffects.map(effect => (
                <TouchableOpacity 
                  key={effect.id}
                  style={[styles.effectItem, effect.enabled && styles.effectItemActive]}
                  onPress={() => toggleEffect(effect.id)}
                >
                  <Ionicons 
                    name={
                      effect.id === 'reverb' ? 'water' :
                      effect.id === 'delay' ? 'timer' :
                      effect.id === 'compression' ? 'contract' :
                      effect.id === 'eq' ? 'options' :
                      effect.id === 'autotune' ? 'musical-notes' :
                      'flash'
                    } 
                    size={32} 
                    color={effect.enabled ? COLORS.textPrimary : COLORS.textMuted} 
                  />
                  <Text style={[styles.effectName, effect.enabled && styles.effectNameActive]}>
                    {effect.name}
                  </Text>
                  {effect.enabled && (
                    <View style={styles.effectValueBar}>
                      <View style={[styles.effectValueFill, { width: `${effect.value * 100}%` }]} />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity 
              style={styles.applyBtn} 
              onPress={() => {
                setShowEffects(false);
                if (currentRecording) {
                  Alert.alert('Effects Applied', 'Effects will be applied when you save the recording.');
                }
              }}
            >
              <Text style={styles.applyBtnText}>Apply Effects</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Schedule Stream Modal */}
      <Modal visible={showScheduleStream} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Schedule Stream</Text>
              <TouchableOpacity onPress={() => setShowScheduleStream(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.scheduleForm}>
              <Text style={styles.inputLabel}>Stream Title</Text>
              <TextInput
                style={styles.textInput}
                value={streamTitle}
                onChangeText={setStreamTitle}
                placeholder="e.g., Late Night Recording Session"
                placeholderTextColor={COLORS.textMuted}
              />
              
              <Text style={styles.inputLabel}>Description (Optional)</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={streamDescription}
                onChangeText={setStreamDescription}
                placeholder="What will you be working on?"
                placeholderTextColor={COLORS.textMuted}
                multiline
                numberOfLines={3}
              />
              
              <View style={styles.scheduleNote}>
                <Ionicons name="notifications" size={20} color={COLORS.primary} />
                <Text style={styles.scheduleNoteText}>
                  Your followers will be notified when you go live
                </Text>
              </View>
              
              <TouchableOpacity style={styles.scheduleConfirmBtn} onPress={scheduleStream}>
                <Ionicons name="calendar" size={20} color={COLORS.textPrimary} />
                <Text style={styles.scheduleConfirmBtnText}>Schedule Stream</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Tip Leaderboard Modal */}
      <Modal visible={showTipLeaderboard} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Top Supporters</Text>
              <TouchableOpacity onPress={() => setShowTipLeaderboard(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.totalTipsHeader}>
              <Ionicons name="cash" size={32} color={COLORS.gold} />
              <Text style={styles.totalTipsAmount}>${totalTips}</Text>
              <Text style={styles.totalTipsLabel}>Total Tips This Stream</Text>
            </View>
            
            {tipLeaderboard.length === 0 ? (
              <View style={styles.emptyLeaderboard}>
                <Ionicons name="trophy-outline" size={48} color={COLORS.textMuted} />
                <Text style={styles.emptyLeaderboardText}>No tips yet</Text>
              </View>
            ) : (
              <FlatList
                data={tipLeaderboard}
                keyExtractor={(item, index) => `${item.user}-${index}`}
                renderItem={({ item, index }) => (
                  <View style={styles.leaderboardItem}>
                    <Text style={styles.leaderboardRank}>#{index + 1}</Text>
                    <Image source={{ uri: item.userImage }} style={styles.leaderboardAvatar} />
                    <Text style={styles.leaderboardName}>{item.user}</Text>
                    <Text style={styles.leaderboardAmount}>${item.totalTips}</Text>
                    {index === 0 && <Ionicons name="trophy" size={20} color={COLORS.gold} />}
                  </View>
                )}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  title: { flex: 1, fontSize: 20, fontWeight: '700', color: COLORS.textPrimary, marginLeft: 16 },
  liveTag: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.error, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  liveDotSmall: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.textPrimary, marginRight: 6 },
  liveTagText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 11 },
  micIndicator: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: COLORS.primary },
  micDot: { width: 12, height: 12, borderRadius: 6 },
  micInfo: { flex: 1, marginLeft: 12 },
  micName: { color: COLORS.textPrimary, fontWeight: '700' },
  micQuality: { color: COLORS.textMuted, fontSize: 12 },
  modeSelector: { flexDirection: 'row', padding: 20, gap: 8 },
  modeBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, backgroundColor: COLORS.backgroundCard, borderRadius: 12, position: 'relative' },
  modeActive: { backgroundColor: COLORS.primary },
  modeText: { color: COLORS.textMuted, fontWeight: '600', fontSize: 12 },
  modeTextActive: { color: COLORS.textPrimary },
  premiumBadge: { position: 'absolute', top: -4, right: -4, backgroundColor: COLORS.backgroundLight, padding: 4, borderRadius: 8 },
  content: { flex: 1 },
  contentContainer: { paddingBottom: 40 },
  recordSection: { paddingHorizontal: 20 },
  waveformContainer: { height: 120, backgroundColor: COLORS.backgroundCard, borderRadius: 12, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  recordingStatus: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 12, paddingVertical: 16 },
  recordingDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: COLORS.error },
  recordingTime: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 24 },
  recordingQuality: { color: COLORS.textMuted, fontSize: 12 },
  transportControls: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 16, paddingVertical: 16 },
  transportBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  recordBtn: { width: 72, height: 72, borderRadius: 36, backgroundColor: COLORS.error, justifyContent: 'center', alignItems: 'center' },
  recordingActive: { backgroundColor: COLORS.primary },
  recordingPaused: { backgroundColor: COLORS.gold },
  metronomeBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 20, paddingVertical: 12, backgroundColor: COLORS.backgroundCard, borderRadius: 12 },
  bpmText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 18 },
  recordingPreview: { backgroundColor: COLORS.backgroundCard, padding: 16, borderRadius: 12, marginTop: 16 },
  previewTitle: { color: COLORS.textPrimary, fontWeight: '600', marginBottom: 8 },
  previewInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  previewDuration: { color: COLORS.textPrimary, fontWeight: '700' },
  previewSize: { color: COLORS.textMuted, fontSize: 12 },
  previewActions: { flexDirection: 'row', gap: 12, marginTop: 12 },
  previewBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundLight, paddingVertical: 10, borderRadius: 8 },
  saveBtn: { backgroundColor: COLORS.primary },
  previewBtnText: { color: COLORS.textPrimary, fontWeight: '600' },
  editSection: { paddingHorizontal: 20 },
  timelineHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  timelineTitle: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 16 },
  timelineActions: { flexDirection: 'row', gap: 8 },
  timelineBtn: { padding: 8, backgroundColor: COLORS.backgroundCard, borderRadius: 8 },
  timeline: { maxHeight: 200 },
  timelineContent: { gap: 8 },
  trackRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, borderRadius: 8, overflow: 'hidden', height: 44 },
  trackRowSelected: { borderWidth: 1, borderColor: COLORS.primary },
  trackRowMuted: { opacity: 0.5 },
  trackLabel: { width: 60, height: '100%', justifyContent: 'center', alignItems: 'center' },
  trackName: { color: COLORS.textPrimary, fontSize: 11, fontWeight: '600' },
  trackWaveform: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 2, paddingHorizontal: 8 },
  waveformBar: { width: 3, borderRadius: 1.5 },
  editTools: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 16, paddingVertical: 16, backgroundColor: COLORS.backgroundCard, borderRadius: 12 },
  editTool: { alignItems: 'center' },
  editToolText: { color: COLORS.textMuted, fontSize: 11, marginTop: 4 },
  mixSection: { paddingHorizontal: 20 },
  mixHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  mixTitle: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 16 },
  masterBtn: { backgroundColor: COLORS.primary, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8 },
  masterText: { color: COLORS.textPrimary, fontWeight: '600', fontSize: 12 },
  mixerChannels: { flexDirection: 'row', gap: 8 },
  channel: { flex: 1, backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 12, alignItems: 'center' },
  masterChannel: { backgroundColor: COLORS.backgroundLight },
  channelName: { color: COLORS.textPrimary, fontSize: 11, fontWeight: '600', marginBottom: 8 },
  faderContainer: { flex: 1, width: '100%', alignItems: 'center' },
  faderTrack: { width: 8, height: 100, backgroundColor: COLORS.backgroundLight, borderRadius: 4, justifyContent: 'flex-end' },
  faderFill: { width: '100%', borderRadius: 4 },
  faderControls: { alignItems: 'center', marginTop: 8 },
  volumeText: { color: COLORS.textMuted, fontSize: 10, marginVertical: 4 },
  channelButtons: { flexDirection: 'row', gap: 4, marginTop: 8 },
  channelBtn: { width: 24, height: 24, borderRadius: 4, backgroundColor: COLORS.backgroundLight, justifyContent: 'center', alignItems: 'center' },
  channelBtnActive: { backgroundColor: COLORS.error },
  channelBtnSolo: { backgroundColor: COLORS.gold },
  channelBtnText: { color: COLORS.textPrimary, fontSize: 10, fontWeight: '700' },
  channelIndicator: { width: '100%', height: 4, borderRadius: 2, marginTop: 8 },
  masterMeter: { flexDirection: 'row', gap: 4, marginTop: 8 },
  meterBar: { width: 8, backgroundColor: COLORS.success, borderRadius: 2 },
  effectsBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 14, borderRadius: 12, marginTop: 16 },
  effectsBtnText: { color: COLORS.textPrimary, fontWeight: '600' },
  liveSection: { paddingHorizontal: 20, flex: 1 },
  liveHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  liveIndicator: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  liveDot: { width: 12, height: 12, borderRadius: 6, backgroundColor: COLORS.error },
  liveText: { color: COLORS.error, fontWeight: '700', fontSize: 18 },
  liveDuration: { color: COLORS.textMuted, fontSize: 14 },
  liveStats: { flexDirection: 'row', gap: 12 },
  viewerCount: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: COLORS.backgroundCard, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  viewerText: { color: COLORS.textPrimary, fontWeight: '600' },
  tipsCount: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(234,179,8,0.2)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  tipsText: { color: COLORS.gold, fontWeight: '700' },
  livePreview: { height: 150, borderRadius: 12, overflow: 'hidden', position: 'relative' },
  liveImage: { width: '100%', height: '100%' },
  liveOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 60, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center' },
  liveChatContainer: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, marginTop: 12, maxHeight: 280 },
  chatHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  chatHeaderTitle: { color: COLORS.textPrimary, fontWeight: '600' },
  chatList: { maxHeight: 120, padding: 8 },
  chatMessage: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8, gap: 8 },
  tipMessage: { backgroundColor: 'rgba(234,179,8,0.1)', padding: 8, borderRadius: 8, marginHorizontal: -8 },
  chatAvatar: { width: 28, height: 28, borderRadius: 14 },
  chatContent: { flex: 1 },
  chatUser: { color: COLORS.primary, fontWeight: '600', fontSize: 12 },
  chatText: { color: COLORS.textPrimary, fontSize: 13 },
  tipText: { color: COLORS.gold, fontWeight: '600' },
  tipBadge: { padding: 4 },
  chatInputContainer: { flexDirection: 'row', padding: 8, gap: 8, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  chatInput: { flex: 1, backgroundColor: COLORS.backgroundLight, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 8, color: COLORS.textPrimary },
  sendBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  tipButtonsContainer: { flexDirection: 'row', alignItems: 'center', padding: 8, gap: 8, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  tipLabel: { color: COLORS.textMuted, fontSize: 12 },
  tipButton: { backgroundColor: COLORS.gold, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16 },
  tipButtonText: { color: COLORS.background, fontWeight: '700', fontSize: 12 },
  showChatBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginTop: 12 },
  showChatBtnText: { color: COLORS.textPrimary, fontWeight: '600' },
  liveControls: { flexDirection: 'row', justifyContent: 'center', gap: 16, marginTop: 12 },
  liveControlBtn: { width: 56, height: 56, borderRadius: 28, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  endLiveBtn: { backgroundColor: COLORS.error },
  tipAnimationOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.7)', zIndex: 100 },
  tipAnimationContent: { alignItems: 'center' },
  tipAnimationText: { color: COLORS.gold, fontSize: 36, fontWeight: '800', marginTop: 12 },
  tipAnimationUser: { color: COLORS.textPrimary, fontSize: 18, marginTop: 8 },
  goLiveContainer: { alignItems: 'center', paddingVertical: 20 },
  goLiveTitle: { color: COLORS.textPrimary, fontSize: 24, fontWeight: '700', marginTop: 16 },
  goLiveDesc: { color: COLORS.textMuted, textAlign: 'center', marginTop: 8, paddingHorizontal: 20 },
  scheduledStreamsSection: { width: '100%', marginTop: 20 },
  scheduledTitle: { color: COLORS.textPrimary, fontWeight: '600', marginBottom: 8 },
  scheduledItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, padding: 12, borderRadius: 12, marginBottom: 8, gap: 12 },
  scheduledInfo: { flex: 1 },
  scheduledName: { color: COLORS.textPrimary, fontWeight: '600' },
  scheduledTime: { color: COLORS.textMuted, fontSize: 12 },
  goLiveActions: { width: '100%', gap: 12, marginTop: 20 },
  goLiveBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.error, paddingVertical: 16, borderRadius: 30 },
  goLiveBtnText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 16 },
  scheduleBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.backgroundCard, paddingVertical: 14, borderRadius: 12 },
  scheduleBtnText: { color: COLORS.primary, fontWeight: '600' },
  premiumRequired: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  premiumRequiredText: { color: COLORS.gold, fontSize: 13 },
  featureSection: { padding: 20 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 12 },
  artistList: { gap: 12 },
  artistChip: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.backgroundCard, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, gap: 8 },
  artistSelected: { backgroundColor: COLORS.primary },
  artistThumb: { width: 32, height: 32, borderRadius: 16 },
  artistName: { color: COLORS.textPrimary, fontSize: 14 },
  faceTimeBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.success, paddingVertical: 12, borderRadius: 12, marginTop: 16 },
  faceTimeText: { color: COLORS.textPrimary, fontWeight: '600' },
  qualityNote: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: 'rgba(234,179,8,0.1)', marginHorizontal: 20, padding: 12, borderRadius: 12 },
  qualityNoteText: { flex: 1, color: COLORS.gold, fontSize: 12 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.background, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  effectsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  effectItem: { width: '30%', aspectRatio: 1, backgroundColor: COLORS.backgroundCard, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  effectItemActive: { backgroundColor: COLORS.primary },
  effectName: { color: COLORS.textMuted, fontSize: 12, marginTop: 8 },
  effectNameActive: { color: COLORS.textPrimary },
  effectValueBar: { width: '60%', height: 4, backgroundColor: COLORS.backgroundLight, borderRadius: 2, marginTop: 4 },
  effectValueFill: { height: '100%', backgroundColor: COLORS.textPrimary, borderRadius: 2 },
  applyBtn: { backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
  applyBtnText: { color: COLORS.textPrimary, fontSize: 18, fontWeight: '700' },
  scheduleForm: { gap: 16 },
  inputLabel: { color: COLORS.textSecondary, fontSize: 14 },
  textInput: { backgroundColor: COLORS.backgroundCard, borderRadius: 12, padding: 16, color: COLORS.textPrimary },
  textArea: { height: 80, textAlignVertical: 'top' },
  scheduleNote: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: 'rgba(139,92,246,0.1)', padding: 12, borderRadius: 12 },
  scheduleNoteText: { flex: 1, color: COLORS.textMuted, fontSize: 13 },
  scheduleConfirmBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12 },
  scheduleConfirmBtnText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 16 },
  totalTipsHeader: { alignItems: 'center', paddingVertical: 20, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundCard },
  totalTipsAmount: { color: COLORS.gold, fontSize: 36, fontWeight: '800', marginTop: 8 },
  totalTipsLabel: { color: COLORS.textMuted, marginTop: 4 },
  emptyLeaderboard: { alignItems: 'center', paddingVertical: 40 },
  emptyLeaderboardText: { color: COLORS.textMuted, marginTop: 12 },
  leaderboardItem: { flexDirection: 'row', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundCard, gap: 12 },
  leaderboardRank: { color: COLORS.textMuted, fontWeight: '700', width: 30 },
  leaderboardAvatar: { width: 40, height: 40, borderRadius: 20 },
  leaderboardName: { flex: 1, color: COLORS.textPrimary, fontWeight: '600' },
  leaderboardAmount: { color: COLORS.gold, fontWeight: '700', marginRight: 8 },
});
