import React, { useState, useRef, useEffect } from 'react';
import { View, ScrollView, StyleSheet, FlatList, Text, TouchableOpacity, Image, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from './constants/colors';
import { IMAGES } from './constants/images';
import GradientHeader from './components/GradientHeader';
import SectionHeader from './components/SectionHeader';
import ArtistCard from './components/ArtistCard';
import TrackCard from './components/TrackCard';
import CategoryPill from './components/CategoryPill';
import ContestCard from './components/ContestCard';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import { ARTISTS, CATEGORIES } from './data/artists';
import { TRACKS } from './data/tracks';
import { CONTESTS } from './data/contests';
import { useApp } from './context/AppContext';
import { useAuth } from './context/AuthContext';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Hero banner content with text overlays
const HERO_BANNERS = [
  {
    image: IMAGES.heroBanners[0],
    title: 'Community Guidelines',
    subtitle: 'Respect. Create. Inspire.',
    description: 'Keep our community safe. No hate speech, harassment, or explicit content. Violations result in account suspension.',
    icon: 'shield-checkmark',
    color: COLORS.primary,
  },
  {
    image: IMAGES.heroBanners[1],
    title: 'Weekly Contests',
    subtitle: 'Win $10,000 in Prizes',
    description: 'Upload your best tracks and compete against artists worldwide. Top 10 advance each round!',
    icon: 'trophy',
    color: COLORS.gold,
  },
  {
    image: IMAGES.heroBanners[2],
    title: 'Content Warning',
    subtitle: 'Original Music Only',
    description: 'All uploads must be original. Copyright violations will be removed and may result in permanent ban.',
    icon: 'warning',
    color: COLORS.error,
  },
];

export default function HomeScreen() {
  const router = useRouter();
  const { playTrack } = useApp();
  const { profile, isAuthenticated } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [currentBanner, setCurrentBanner] = useState(0);
  const bannerRef = useRef<FlatList>(null);

  const filteredArtists = selectedCategory === 'All' 
    ? ARTISTS 
    : ARTISTS.filter(a => a.category === selectedCategory);

  const numberOne = ARTISTS[0];
  const isPremium = profile?.isPremium;

  // Auto-scroll banners
  useEffect(() => {
    const interval = setInterval(() => {
      const nextIndex = (currentBanner + 1) % HERO_BANNERS.length;
      setCurrentBanner(nextIndex);
      bannerRef.current?.scrollToIndex({ index: nextIndex, animated: true });
    }, 5000);
    return () => clearInterval(interval);
  }, [currentBanner]);

  const renderBanner = ({ item, index }: { item: typeof HERO_BANNERS[0]; index: number }) => (
    <TouchableOpacity 
      style={styles.bannerSlide}
      onPress={() => {
        if (index === 1) router.push('/contests');
        else if (index === 0) router.push('/onboarding');
      }}
      activeOpacity={0.9}
    >
      <Image source={{ uri: item.image }} style={styles.bannerImage} />
      <View style={styles.bannerOverlay}>
        <View style={[styles.bannerIconBadge, { backgroundColor: item.color }]}>
          <Ionicons name={item.icon as any} size={24} color={COLORS.textPrimary} />
        </View>
        <Text style={styles.bannerTitle}>{item.title}</Text>
        <Text style={[styles.bannerSubtitle, { color: item.color }]}>{item.subtitle}</Text>
        <Text style={styles.bannerDescription}>{item.description}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <GradientHeader 
          onSearchPress={() => router.push('/search')} 
          onProfilePress={() => router.push('/profile')} 
        />

        {!isPremium && (
          <TouchableOpacity style={styles.premiumBanner} onPress={() => router.push('/premium')}>
            <Ionicons name="diamond" size={20} color={COLORS.gold} />
            <Text style={styles.premiumBannerText}>Upgrade to Premium - $12/year</Text>
            <Ionicons name="chevron-forward" size={20} color={COLORS.gold} />
          </TouchableOpacity>
        )}

        {/* Hero Banners with Text Overlays */}
        <View style={styles.bannerContainer}>
          <FlatList
            ref={bannerRef}
            data={HERO_BANNERS}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            keyExtractor={(_, index) => index.toString()}
            renderItem={renderBanner}
            onMomentumScrollEnd={(e) => {
              const index = Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH);
              setCurrentBanner(index);
            }}
            getItemLayout={(_, index) => ({
              length: SCREEN_WIDTH - 40,
              offset: (SCREEN_WIDTH - 40) * index,
              index,
            })}
          />
          <View style={styles.bannerDots}>
            {HERO_BANNERS.map((_, index) => (
              <View 
                key={index} 
                style={[
                  styles.dot, 
                  currentBanner === index && styles.dotActive
                ]} 
              />
            ))}
          </View>
        </View>

        <TouchableOpacity style={styles.numberOneCard} onPress={() => router.push(`/artist/${numberOne.id}`)}>
          <Image source={{ uri: numberOne.image }} style={styles.numberOneImage} />
          <View style={styles.numberOneInfo}>
            <View style={styles.crownBadge}><Ionicons name="trophy" size={16} color={COLORS.gold} /></View>
            <Text style={styles.numberOneLabel}>#1 ARTIST</Text>
            <Text style={styles.numberOneName}>{numberOne.name}</Text>
            <Text style={styles.numberOneCategory}>{numberOne.category}</Text>
          </View>
        </TouchableOpacity>

        <View style={styles.quickLinks}>
          {[
            { icon: 'storefront', label: 'Store', route: '/store', color: COLORS.primary },
            { icon: 'musical-notes', label: 'Beats', route: '/beats', color: '#8B5CF6' },
            { icon: 'mic', label: 'Booth', route: '/booth', color: COLORS.secondary },
            { icon: 'trophy', label: 'Contests', route: '/contests', color: COLORS.gold },
          ].map(link => (
            <TouchableOpacity key={link.label} style={styles.quickLink} onPress={() => router.push(link.route as any)}>
              <View style={[styles.quickIcon, { backgroundColor: link.color }]}>
                <Ionicons name={link.icon as any} size={20} color={COLORS.textPrimary} />
              </View>
              <Text style={styles.quickLabel}>{link.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.aiCard} onPress={() => router.push('/ai-assistant')}>
          <Image 
            source={{ uri: 'https://d64gsuwffb70l.cloudfront.net/692bf8fe6f6012747066995c_1764997736375_fd969565.jpg' }} 
            style={styles.aiImage}
          />
          <View style={styles.aiContent}>
            <Text style={styles.aiTitle}>1WAY AI Assistant</Text>
            <Text style={styles.aiDesc}>Write lyrics, get rhymes, plan videos & more</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color={COLORS.primary} />
        </TouchableOpacity>

        <View style={styles.categorySection}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryList}>
            {CATEGORIES.map((cat) => (
              <CategoryPill key={cat} label={cat} isActive={selectedCategory === cat} onPress={() => setSelectedCategory(cat)} />
            ))}
          </ScrollView>
        </View>

        <SectionHeader title="Top 10 Artists" subtitle="Most followed this week" icon="trophy" onSeeAll={() => router.push('/charts')} />
        <FlatList
          data={ARTISTS.slice(0, 10)}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalList}
          keyExtractor={(item) => item.id}
          renderItem={({ item, index }) => (
            <View style={styles.rankedCard}>
              <View style={styles.rankBadge}><Text style={styles.rankText}>{index + 1}</Text></View>
              <ArtistCard artist={item} size="medium" onPress={() => router.push(`/artist/${item.id}`)} />
            </View>
          )}
        />

        <SectionHeader title="Hot Contests" subtitle="Win prizes & recognition" icon="flame" onSeeAll={() => router.push('/contests')} />
        <FlatList
          data={CONTESTS}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalList}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <ContestCard contest={item} onPress={() => router.push('/contests')} />}
        />

        <SectionHeader title="Billboard Top 10" subtitle="Trending now" icon="trending-up" onSeeAll={() => router.push('/charts')} />
        <View style={styles.trackList}>
          {TRACKS.slice(0, 5).map((track) => (
            <TrackCard key={track.id} track={track} showRank onPress={() => playTrack(track)} />
          ))}
        </View>

        <View style={styles.featuresRow}>
          <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/analytics')}>
            <Ionicons name="stats-chart" size={28} color={COLORS.primary} />
            <Text style={styles.featureTitle}>Analytics</Text>
            <Text style={styles.featureDesc}>Track your performance</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/wallet')}>
            <Ionicons name="wallet" size={28} color={COLORS.success} />
            <Text style={styles.featureTitle}>Wallet</Text>
            <Text style={styles.featureDesc}>Manage your funds</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.featuresRow}>
          <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/fanclub')}>
            <Ionicons name="heart" size={28} color={COLORS.accent} />
            <Text style={styles.featureTitle}>Fan Club</Text>
            <Text style={styles.featureDesc}>Exclusive content</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.featureCard} onPress={() => router.push('/beats')}>
            <Ionicons name="musical-notes" size={28} color={COLORS.secondary} />
            <Text style={styles.featureTitle}>Beat Store</Text>
            <Text style={styles.featureDesc}>Buy & sell beats</Text>
          </TouchableOpacity>
        </View>

        <SectionHeader title="VIP Artists" subtitle="Premium creators" icon="star" onSeeAll={() => router.push('/artists')} />
        <FlatList
          data={ARTISTS.filter(a => a.isVIP)}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalList}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <ArtistCard artist={item} size="medium" onPress={() => router.push(`/artist/${item.id}`)} />
          )}
        />
      </ScrollView>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scrollContent: { paddingBottom: 180 },
  premiumBanner: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center',
    gap: 8, 
    backgroundColor: 'rgba(234,179,8,0.15)', 
    marginHorizontal: 20, 
    marginTop: 16,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.gold,
  },
  premiumBannerText: { color: COLORS.gold, fontWeight: '600' },
  // Hero Banner Styles
  bannerContainer: { marginTop: 16, marginHorizontal: 20 },
  bannerSlide: { 
    width: SCREEN_WIDTH - 40, 
    height: 200, 
    borderRadius: 16, 
    overflow: 'hidden',
    position: 'relative',
  },
  bannerImage: { 
    width: '100%', 
    height: '100%', 
    resizeMode: 'cover',
  },
  bannerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 20,
    justifyContent: 'center',
  },
  bannerIconBadge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  bannerTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  bannerSubtitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 8,
  },
  bannerDescription: {
    fontSize: 13,
    color: COLORS.textSecondary,
    lineHeight: 18,
  },
  bannerDots: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.textMuted,
  },
  dotActive: {
    backgroundColor: COLORS.primary,
    width: 24,
  },
  numberOneCard: { flexDirection: 'row', backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, borderRadius: 16, overflow: 'hidden', marginTop: 16 },
  numberOneImage: { width: 100, height: 100 },
  numberOneInfo: { flex: 1, padding: 12, justifyContent: 'center' },
  crownBadge: { position: 'absolute', top: 8, right: 8 },
  numberOneLabel: { fontSize: 10, color: COLORS.gold, fontWeight: '700' },
  numberOneName: { fontSize: 20, fontWeight: '800', color: COLORS.textPrimary },
  numberOneCategory: { fontSize: 12, color: COLORS.textMuted },
  quickLinks: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 20, paddingHorizontal: 10 },
  quickLink: { alignItems: 'center' },
  quickIcon: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  quickLabel: { color: COLORS.textSecondary, fontSize: 11, marginTop: 6 },
  aiCard: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: COLORS.backgroundCard, 
    marginHorizontal: 20, 
    padding: 16, 
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  aiImage: { width: 50, height: 50, borderRadius: 25 },
  aiContent: { flex: 1, marginLeft: 12 },
  aiTitle: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 16 },
  aiDesc: { color: COLORS.textMuted, fontSize: 13 },
  horizontalList: { paddingHorizontal: 20 },
  categorySection: { marginTop: 8 },
  categoryList: { paddingHorizontal: 20, paddingVertical: 8 },
  trackList: { paddingHorizontal: 20 },
  rankedCard: { marginRight: 16 },
  rankBadge: { position: 'absolute', top: -6, left: -6, zIndex: 1, backgroundColor: COLORS.primary, width: 24, height: 24, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  rankText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 11 },
  featuresRow: { flexDirection: 'row', gap: 12, paddingHorizontal: 20, marginTop: 16 },
  featureCard: { 
    flex: 1, 
    backgroundColor: COLORS.backgroundCard, 
    padding: 16, 
    borderRadius: 16, 
    alignItems: 'center' 
  },
  featureTitle: { color: COLORS.textPrimary, fontWeight: '700', marginTop: 8 },
  featureDesc: { color: COLORS.textMuted, fontSize: 12, marginTop: 4 },
});
