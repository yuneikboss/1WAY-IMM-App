import React, { useState, useEffect } from 'react';
import {
  View,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  TextInput,
  Modal,
  Alert,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { COLORS } from './constants/colors';
import MiniPlayer from './components/MiniPlayer';
import BottomNav from './components/BottomNav';
import { useAuth } from './context/AuthContext';
import { ARTISTS } from './data/artists';
import collaborationService, { 
  Collaboration, 
  Collaborator, 
  CollaborationVersion,
  SplitSheet 
} from './services/CollaborationService';

type TabType = 'active' | 'invitations' | 'completed';

export default function CollaborationsScreen() {
  const router = useRouter();
  const { profile, addNotification } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('active');
  const [collaborations, setCollaborations] = useState<Collaboration[]>([]);
  const [pendingInvitations, setPendingInvitations] = useState<Collaboration[]>([]);
  const [showNewCollabModal, setShowNewCollabModal] = useState(false);
  const [showCollabDetailModal, setShowCollabDetailModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showSplitSheetModal, setShowSplitSheetModal] = useState(false);
  const [selectedCollab, setSelectedCollab] = useState<Collaboration | null>(null);
  const [splitSheet, setSplitSheet] = useState<SplitSheet | null>(null);
  const [newCollab, setNewCollab] = useState({ title: '', description: '' });
  const [searchArtist, setSearchArtist] = useState('');
  const [messageText, setMessageText] = useState('');

  useEffect(() => {
    loadCollaborations();
  }, []);

  const loadCollaborations = () => {
    if (!profile) return;
    
    // Initialize sample data
    collaborationService.initializeSampleData(
      profile.id,
      profile.displayName,
      profile.profileImage
    );

    const allCollabs = collaborationService.getArtistCollaborations(profile.id);
    setCollaborations(allCollabs.filter(c => c.status !== 'completed' && c.status !== 'released'));
    setPendingInvitations(collaborationService.getPendingInvitations(profile.id));
  };

  const handleCreateCollab = () => {
    if (!profile || !newCollab.title) return;

    const collab = collaborationService.createCollaboration(
      newCollab.title,
      newCollab.description,
      profile.id,
      profile.displayName,
      profile.profileImage
    );

    setCollaborations([...collaborations, collab]);
    setShowNewCollabModal(false);
    setNewCollab({ title: '', description: '' });

    addNotification({
      type: 'system',
      title: 'Collaboration Created',
      message: `Your collaboration "${collab.title}" has been created!`,
    });
  };

  const handleInviteArtist = (artist: typeof ARTISTS[0], role: Collaborator['role'], split: number) => {
    if (!selectedCollab) return;

    const collaborator = collaborationService.inviteCollaborator(
      selectedCollab.id,
      artist.id,
      artist.name,
      artist.image,
      role,
      split
    );

    if (collaborator) {
      loadCollaborations();
      setShowInviteModal(false);
      
      addNotification({
        type: 'system',
        title: 'Invitation Sent',
        message: `Invitation sent to ${artist.name} for "${selectedCollab.title}"`,
      });
    }
  };

  const handleRespondToInvitation = (collabId: string, accept: boolean) => {
    if (!profile) return;

    collaborationService.respondToInvitation(collabId, profile.id, accept);
    loadCollaborations();

    const collab = collaborations.find(c => c.id === collabId) || 
                   pendingInvitations.find(c => c.id === collabId);

    addNotification({
      type: 'system',
      title: accept ? 'Invitation Accepted' : 'Invitation Declined',
      message: accept 
        ? `You joined "${collab?.title}"` 
        : `You declined the invitation to "${collab?.title}"`,
    });
  };

  const handleGenerateSplitSheet = () => {
    if (!selectedCollab) return;

    const sheet = collaborationService.generateSplitSheet(selectedCollab.id);
    if (sheet) {
      setSplitSheet(sheet);
      setShowSplitSheetModal(true);
    }
  };

  const handleSignSplitSheet = () => {
    if (!selectedCollab || !profile || !splitSheet) return;

    collaborationService.signSplitSheet(selectedCollab.id, profile.id);
    
    // Refresh split sheet
    const updatedSheet = collaborationService.generateSplitSheet(selectedCollab.id);
    setSplitSheet(updatedSheet);

    if (collaborationService.isSplitSheetComplete(selectedCollab.id)) {
      Alert.alert('Split Sheet Complete', 'All collaborators have signed the split sheet!');
    }
  };

  const handleSendMessage = () => {
    if (!selectedCollab || !profile || !messageText.trim()) return;

    collaborationService.sendMessage(
      selectedCollab.id,
      profile.id,
      profile.displayName,
      profile.profileImage,
      messageText
    );

    setMessageText('');
    
    // Refresh selected collab
    const updated = collaborationService.getCollaboration(selectedCollab.id);
    if (updated) setSelectedCollab(updated);
  };

  const openCollabDetail = (collab: Collaboration) => {
    setSelectedCollab(collab);
    setShowCollabDetailModal(true);
  };

  const filteredArtists = ARTISTS.filter(a => 
    a.name.toLowerCase().includes(searchArtist.toLowerCase()) &&
    !selectedCollab?.collaborators.some(c => c.artistId === a.id)
  );

  const renderCollabCard = (collab: Collaboration) => {
    const acceptedCollaborators = collab.collaborators.filter(c => c.status === 'accepted');
    const latestVersion = collab.versions.find(v => v.isActive);

    return (
      <TouchableOpacity 
        key={collab.id} 
        style={styles.collabCard}
        onPress={() => openCollabDetail(collab)}
      >
        <View style={styles.collabHeader}>
          <View style={styles.collabTitleRow}>
            <Text style={styles.collabTitle}>{collab.title}</Text>
            <View style={[styles.statusPill, { backgroundColor: getStatusColor(collab.status) + '20' }]}>
              <Text style={[styles.statusPillText, { color: getStatusColor(collab.status) }]}>
                {collab.status.replace('_', ' ')}
              </Text>
            </View>
          </View>
          {collab.description && (
            <Text style={styles.collabDesc} numberOfLines={2}>{collab.description}</Text>
          )}
        </View>

        {/* Collaborators */}
        <View style={styles.collaboratorsRow}>
          <View style={styles.avatarStack}>
            {acceptedCollaborators.slice(0, 4).map((c, index) => (
              <Image 
                key={c.id} 
                source={{ uri: c.artistImage }} 
                style={[styles.stackAvatar, { marginLeft: index > 0 ? -10 : 0 }]} 
              />
            ))}
            {acceptedCollaborators.length > 4 && (
              <View style={[styles.stackAvatar, styles.moreAvatar, { marginLeft: -10 }]}>
                <Text style={styles.moreAvatarText}>+{acceptedCollaborators.length - 4}</Text>
              </View>
            )}
          </View>
          <Text style={styles.collaboratorsText}>
            {acceptedCollaborators.length} collaborator{acceptedCollaborators.length !== 1 ? 's' : ''}
          </Text>
        </View>

        {/* Version Info */}
        {latestVersion && (
          <View style={styles.versionInfo}>
            <Ionicons name="git-branch" size={14} color={COLORS.textMuted} />
            <Text style={styles.versionText}>
              v{latestVersion.versionNumber} - {latestVersion.name}
            </Text>
          </View>
        )}

        {/* Footer */}
        <View style={styles.collabFooter}>
          <View style={styles.collabMeta}>
            <Ionicons name="chatbubble-outline" size={14} color={COLORS.textMuted} />
            <Text style={styles.collabMetaText}>{collab.messages.length}</Text>
            <Ionicons name="layers-outline" size={14} color={COLORS.textMuted} style={{ marginLeft: 12 }} />
            <Text style={styles.collabMetaText}>{collab.versions.length}</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
        </View>
      </TouchableOpacity>
    );
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'draft': return COLORS.textMuted;
      case 'in_progress': return COLORS.primary;
      case 'review': return COLORS.gold;
      case 'completed': return COLORS.success;
      case 'released': return COLORS.accent;
      default: return COLORS.textMuted;
    }
  };

  const getRoleColor = (role: string): string => {
    switch (role) {
      case 'lead': return COLORS.gold;
      case 'featured': return COLORS.primary;
      case 'producer': return COLORS.secondary;
      case 'writer': return COLORS.accent;
      case 'mixer': return COLORS.success;
      default: return COLORS.textMuted;
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.title}>Collaborations</Text>
          <TouchableOpacity onPress={() => setShowNewCollabModal(true)} style={styles.addBtn}>
            <Ionicons name="add" size={24} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        {/* Tabs */}
        <View style={styles.tabContainer}>
          {(['active', 'invitations', 'completed'] as TabType[]).map(tab => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeTab === tab && styles.tabActive]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </Text>
              {tab === 'invitations' && pendingInvitations.length > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{pendingInvitations.length}</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Content */}
        {activeTab === 'active' && (
          <>
            {collaborations.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="people-outline" size={60} color={COLORS.textMuted} />
                <Text style={styles.emptyTitle}>No Active Collaborations</Text>
                <Text style={styles.emptyText}>Start a new collaboration with other artists</Text>
                <TouchableOpacity 
                  style={styles.emptyBtn}
                  onPress={() => setShowNewCollabModal(true)}
                >
                  <Text style={styles.emptyBtnText}>Create Collaboration</Text>
                </TouchableOpacity>
              </View>
            ) : (
              collaborations.map(renderCollabCard)
            )}
          </>
        )}

        {activeTab === 'invitations' && (
          <>
            {pendingInvitations.length === 0 ? (
              <View style={styles.emptyState}>
                <Ionicons name="mail-outline" size={60} color={COLORS.textMuted} />
                <Text style={styles.emptyTitle}>No Pending Invitations</Text>
                <Text style={styles.emptyText}>You'll see collaboration invites here</Text>
              </View>
            ) : (
              pendingInvitations.map(collab => (
                <View key={collab.id} style={styles.invitationCard}>
                  <View style={styles.invitationHeader}>
                    <Text style={styles.invitationTitle}>{collab.title}</Text>
                    <Text style={styles.invitationFrom}>
                      from {collab.collaborators.find(c => c.artistId === collab.ownerId)?.artistName}
                    </Text>
                  </View>
                  {collab.description && (
                    <Text style={styles.invitationDesc}>{collab.description}</Text>
                  )}
                  <View style={styles.invitationActions}>
                    <TouchableOpacity 
                      style={styles.declineBtn}
                      onPress={() => handleRespondToInvitation(collab.id, false)}
                    >
                      <Text style={styles.declineBtnText}>Decline</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.acceptBtn}
                      onPress={() => handleRespondToInvitation(collab.id, true)}
                    >
                      <Text style={styles.acceptBtnText}>Accept</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              ))
            )}
          </>
        )}

        {activeTab === 'completed' && (
          <View style={styles.emptyState}>
            <Ionicons name="checkmark-circle-outline" size={60} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Completed Collaborations</Text>
            <Text style={styles.emptyText}>Finished projects will appear here</Text>
          </View>
        )}
      </ScrollView>

      {/* New Collaboration Modal */}
      <Modal visible={showNewCollabModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>New Collaboration</Text>
              <TouchableOpacity onPress={() => setShowNewCollabModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <Text style={styles.inputLabel}>Project Title</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter project title"
              placeholderTextColor={COLORS.textMuted}
              value={newCollab.title}
              onChangeText={text => setNewCollab({ ...newCollab, title: text })}
            />

            <Text style={styles.inputLabel}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Describe your project..."
              placeholderTextColor={COLORS.textMuted}
              multiline
              numberOfLines={4}
              value={newCollab.description}
              onChangeText={text => setNewCollab({ ...newCollab, description: text })}
            />

            <TouchableOpacity style={styles.createBtn} onPress={handleCreateCollab}>
              <Text style={styles.createBtnText}>Create Collaboration</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Collaboration Detail Modal */}
      <Modal visible={showCollabDetailModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { maxHeight: '95%' }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedCollab?.title}</Text>
              <TouchableOpacity onPress={() => setShowCollabDetailModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Collaborators Section */}
              <View style={styles.detailSection}>
                <View style={styles.sectionHeader}>
                  <Text style={styles.sectionTitle}>Collaborators</Text>
                  <TouchableOpacity onPress={() => setShowInviteModal(true)}>
                    <Ionicons name="person-add" size={20} color={COLORS.primary} />
                  </TouchableOpacity>
                </View>
                {selectedCollab?.collaborators.map(collab => (
                  <View key={collab.id} style={styles.collaboratorItem}>
                    <Image source={{ uri: collab.artistImage }} style={styles.collaboratorAvatar} />
                    <View style={styles.collaboratorInfo}>
                      <Text style={styles.collaboratorName}>{collab.artistName}</Text>
                      <View style={styles.collaboratorMeta}>
                        <View style={[styles.roleBadge, { backgroundColor: getRoleColor(collab.role) + '20' }]}>
                          <Text style={[styles.roleBadgeText, { color: getRoleColor(collab.role) }]}>
                            {collab.role}
                          </Text>
                        </View>
                        <Text style={styles.splitText}>{collab.splitPercentage}% split</Text>
                      </View>
                    </View>
                    <View style={[
                      styles.statusDot,
                      { backgroundColor: collab.status === 'accepted' ? COLORS.success : 
                                        collab.status === 'pending' ? COLORS.gold : COLORS.error }
                    ]} />
                  </View>
                ))}
                <TouchableOpacity style={styles.splitSheetBtn} onPress={handleGenerateSplitSheet}>
                  <Ionicons name="document-text" size={18} color={COLORS.primary} />
                  <Text style={styles.splitSheetBtnText}>View Split Sheet</Text>
                </TouchableOpacity>
              </View>

              {/* Versions Section */}
              <View style={styles.detailSection}>
                <Text style={styles.sectionTitle}>Version History</Text>
                {selectedCollab?.versions.length === 0 ? (
                  <Text style={styles.emptyVersionText}>No versions yet</Text>
                ) : (
                  selectedCollab?.versions.map(version => (
                    <View key={version.id} style={[
                      styles.versionItem,
                      version.isActive && styles.versionItemActive
                    ]}>
                      <View style={styles.versionIcon}>
                        <Ionicons 
                          name={version.isActive ? 'checkmark-circle' : 'ellipse-outline'} 
                          size={20} 
                          color={version.isActive ? COLORS.success : COLORS.textMuted} 
                        />
                      </View>
                      <View style={styles.versionDetails}>
                        <Text style={styles.versionName}>v{version.versionNumber} - {version.name}</Text>
                        <Text style={styles.versionNotes}>{version.notes}</Text>
                        <Text style={styles.versionDate}>
                          {new Date(version.createdAt).toLocaleDateString()}
                        </Text>
                      </View>
                      {!version.isActive && (
                        <TouchableOpacity style={styles.revertBtn}>
                          <Text style={styles.revertBtnText}>Revert</Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  ))
                )}
              </View>

              {/* Messages Section */}
              <View style={styles.detailSection}>
                <Text style={styles.sectionTitle}>Messages</Text>
                <View style={styles.messagesContainer}>
                  {selectedCollab?.messages.slice(-5).map(msg => (
                    <View key={msg.id} style={styles.messageItem}>
                      <Image source={{ uri: msg.senderImage }} style={styles.messageAvatar} />
                      <View style={styles.messageBubble}>
                        <Text style={styles.messageSender}>{msg.senderName}</Text>
                        <Text style={styles.messageText}>{msg.text}</Text>
                        <Text style={styles.messageTime}>
                          {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                      </View>
                    </View>
                  ))}
                </View>
                <View style={styles.messageInputRow}>
                  <TextInput
                    style={styles.messageInput}
                    placeholder="Type a message..."
                    placeholderTextColor={COLORS.textMuted}
                    value={messageText}
                    onChangeText={setMessageText}
                  />
                  <TouchableOpacity style={styles.sendBtn} onPress={handleSendMessage}>
                    <Ionicons name="send" size={20} color="#fff" />
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Invite Artist Modal */}
      <Modal visible={showInviteModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Invite Artist</Text>
              <TouchableOpacity onPress={() => setShowInviteModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.searchInput}
              placeholder="Search artists..."
              placeholderTextColor={COLORS.textMuted}
              value={searchArtist}
              onChangeText={setSearchArtist}
            />

            <FlatList
              data={filteredArtists.slice(0, 6)}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <TouchableOpacity 
                  style={styles.artistItem}
                  onPress={() => handleInviteArtist(item, 'featured', 25)}
                >
                  <Image source={{ uri: item.image }} style={styles.artistAvatar} />
                  <View style={styles.artistInfo}>
                    <Text style={styles.artistName}>{item.name}</Text>
                    <Text style={styles.artistGenre}>{item.genre}</Text>
                  </View>
                  <Ionicons name="add-circle" size={24} color={COLORS.primary} />
                </TouchableOpacity>
              )}
              style={{ maxHeight: 300 }}
            />
          </View>
        </View>
      </Modal>

      {/* Split Sheet Modal */}
      <Modal visible={showSplitSheetModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Split Sheet</Text>
              <TouchableOpacity onPress={() => setShowSplitSheetModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.textPrimary} />
              </TouchableOpacity>
            </View>

            {splitSheet && (
              <>
                <Text style={styles.splitSheetTitle}>{splitSheet.title}</Text>
                
                <View style={styles.splitsList}>
                  {splitSheet.splits.map((split, index) => (
                    <View key={index} style={styles.splitItem}>
                      <View style={styles.splitInfo}>
                        <Text style={styles.splitName}>{split.artistName}</Text>
                        <Text style={styles.splitRole}>{split.role}</Text>
                      </View>
                      <View style={styles.splitPercentContainer}>
                        <View style={[styles.splitBar, { width: `${split.percentage}%` }]} />
                        <Text style={styles.splitPercent}>{split.percentage}%</Text>
                      </View>
                      {splitSheet.signedBy.includes(split.artistId) ? (
                        <Ionicons name="checkmark-circle" size={24} color={COLORS.success} />
                      ) : (
                        <Ionicons name="ellipse-outline" size={24} color={COLORS.textMuted} />
                      )}
                    </View>
                  ))}
                </View>

                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={[
                    styles.totalValue,
                    { color: splitSheet.isValid ? COLORS.success : COLORS.error }
                  ]}>
                    {splitSheet.totalPercentage}%
                  </Text>
                </View>

                {!splitSheet.signedBy.includes(profile?.id || '') && (
                  <TouchableOpacity style={styles.signBtn} onPress={handleSignSplitSheet}>
                    <Ionicons name="create" size={20} color="#fff" />
                    <Text style={styles.signBtnText}>Sign Split Sheet</Text>
                  </TouchableOpacity>
                )}

                <Text style={styles.signedCount}>
                  {splitSheet.signedBy.length} of {splitSheet.splits.length} signatures
                </Text>
              </>
            )}
          </View>
        </View>
      </Modal>

      <MiniPlayer />
      <BottomNav />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingBottom: 180 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 24, fontWeight: '800', color: COLORS.textPrimary },
  addBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: COLORS.backgroundCard, justifyContent: 'center', alignItems: 'center' },
  tabContainer: { flexDirection: 'row', paddingHorizontal: 20, gap: 8, marginBottom: 20 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, borderRadius: 12, backgroundColor: COLORS.backgroundCard },
  tabActive: { backgroundColor: COLORS.primary },
  tabText: { fontSize: 14, fontWeight: '600', color: COLORS.textMuted },
  tabTextActive: { color: COLORS.textPrimary },
  badge: { backgroundColor: COLORS.error, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 10 },
  badgeText: { color: '#fff', fontSize: 10, fontWeight: '700' },
  collabCard: { backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, borderRadius: 16, padding: 16, marginBottom: 12 },
  collabHeader: { marginBottom: 12 },
  collabTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  collabTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textPrimary, flex: 1 },
  statusPill: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusPillText: { fontSize: 11, fontWeight: '600', textTransform: 'capitalize' },
  collabDesc: { fontSize: 13, color: COLORS.textMuted, marginTop: 4 },
  collaboratorsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  avatarStack: { flexDirection: 'row' },
  stackAvatar: { width: 28, height: 28, borderRadius: 14, borderWidth: 2, borderColor: COLORS.backgroundCard },
  moreAvatar: { backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  moreAvatarText: { color: '#fff', fontSize: 10, fontWeight: '600' },
  collaboratorsText: { fontSize: 12, color: COLORS.textMuted, marginLeft: 8 },
  versionInfo: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 12 },
  versionText: { fontSize: 12, color: COLORS.textMuted },
  collabFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 12, borderTopWidth: 1, borderTopColor: COLORS.backgroundLight },
  collabMeta: { flexDirection: 'row', alignItems: 'center' },
  collabMetaText: { fontSize: 12, color: COLORS.textMuted, marginLeft: 4 },
  emptyState: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 40 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary, marginTop: 16 },
  emptyText: { fontSize: 14, color: COLORS.textMuted, marginTop: 8, textAlign: 'center' },
  emptyBtn: { backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 20, marginTop: 20 },
  emptyBtnText: { color: '#fff', fontWeight: '600' },
  invitationCard: { backgroundColor: COLORS.backgroundCard, marginHorizontal: 20, borderRadius: 16, padding: 16, marginBottom: 12 },
  invitationHeader: { marginBottom: 8 },
  invitationTitle: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary },
  invitationFrom: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  invitationDesc: { fontSize: 13, color: COLORS.textSecondary, marginBottom: 12 },
  invitationActions: { flexDirection: 'row', gap: 12 },
  declineBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, backgroundColor: COLORS.backgroundLight, alignItems: 'center' },
  declineBtnText: { color: COLORS.textMuted, fontWeight: '600' },
  acceptBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, backgroundColor: COLORS.primary, alignItems: 'center' },
  acceptBtnText: { color: '#fff', fontWeight: '600' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: COLORS.backgroundCard, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  modalTitle: { fontSize: 20, fontWeight: '700', color: COLORS.textPrimary },
  inputLabel: { fontSize: 14, fontWeight: '600', color: COLORS.textMuted, marginBottom: 8 },
  input: { backgroundColor: COLORS.background, borderRadius: 12, padding: 16, fontSize: 16, color: COLORS.textPrimary, marginBottom: 16 },
  textArea: { height: 100, textAlignVertical: 'top' },
  createBtn: { backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 8 },
  createBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  detailSection: { marginBottom: 24 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary, marginBottom: 12 },
  collaboratorItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  collaboratorAvatar: { width: 40, height: 40, borderRadius: 20, marginRight: 12 },
  collaboratorInfo: { flex: 1 },
  collaboratorName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  collaboratorMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  roleBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  roleBadgeText: { fontSize: 10, fontWeight: '600', textTransform: 'capitalize' },
  splitText: { fontSize: 11, color: COLORS.textMuted },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  splitSheetBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, borderRadius: 12, backgroundColor: COLORS.backgroundLight, marginTop: 12 },
  splitSheetBtnText: { color: COLORS.primary, fontWeight: '600' },
  emptyVersionText: { fontSize: 13, color: COLORS.textMuted, fontStyle: 'italic' },
  versionItem: { flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  versionItemActive: { backgroundColor: COLORS.success + '10', marginHorizontal: -16, paddingHorizontal: 16, borderRadius: 8 },
  versionIcon: { marginRight: 12, marginTop: 2 },
  versionDetails: { flex: 1 },
  versionName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  versionNotes: { fontSize: 12, color: COLORS.textMuted, marginTop: 2 },
  versionDate: { fontSize: 11, color: COLORS.textMuted, marginTop: 4 },
  revertBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, backgroundColor: COLORS.backgroundLight },
  revertBtnText: { fontSize: 12, color: COLORS.primary, fontWeight: '600' },
  messagesContainer: { maxHeight: 200 },
  messageItem: { flexDirection: 'row', marginBottom: 12 },
  messageAvatar: { width: 32, height: 32, borderRadius: 16, marginRight: 8 },
  messageBubble: { flex: 1, backgroundColor: COLORS.backgroundLight, borderRadius: 12, padding: 10 },
  messageSender: { fontSize: 12, fontWeight: '600', color: COLORS.primary },
  messageText: { fontSize: 13, color: COLORS.textPrimary, marginTop: 2 },
  messageTime: { fontSize: 10, color: COLORS.textMuted, marginTop: 4 },
  messageInputRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  messageInput: { flex: 1, backgroundColor: COLORS.background, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 14, color: COLORS.textPrimary },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center' },
  searchInput: { backgroundColor: COLORS.background, borderRadius: 12, padding: 16, fontSize: 16, color: COLORS.textPrimary, marginBottom: 16 },
  artistItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  artistAvatar: { width: 44, height: 44, borderRadius: 22, marginRight: 12 },
  artistInfo: { flex: 1 },
  artistName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  artistGenre: { fontSize: 12, color: COLORS.textMuted },
  splitSheetTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textPrimary, textAlign: 'center', marginBottom: 20 },
  splitsList: { marginBottom: 16 },
  splitItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.backgroundLight },
  splitInfo: { width: 100 },
  splitName: { fontSize: 14, fontWeight: '600', color: COLORS.textPrimary },
  splitRole: { fontSize: 11, color: COLORS.textMuted, textTransform: 'capitalize' },
  splitPercentContainer: { flex: 1, marginHorizontal: 12 },
  splitBar: { height: 8, backgroundColor: COLORS.primary, borderRadius: 4, marginBottom: 4 },
  splitPercent: { fontSize: 12, fontWeight: '600', color: COLORS.textPrimary },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 12, borderTopWidth: 2, borderTopColor: COLORS.backgroundLight },
  totalLabel: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary },
  totalValue: { fontSize: 16, fontWeight: '700' },
  signBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 12, marginTop: 16 },
  signBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  signedCount: { textAlign: 'center', fontSize: 12, color: COLORS.textMuted, marginTop: 12 },
});
