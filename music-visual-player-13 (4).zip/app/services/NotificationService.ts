import { Platform } from 'react-native';

// Notification types
export type NotificationType = 
  | 'vote_received'
  | 'contest_advance'
  | 'contest_eliminated'
  | 'message_received'
  | 'content_liked'
  | 'content_purchased'
  | 'payout_complete'
  | 'system';

export interface PushNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  data?: Record<string, any>;
  timestamp: number;
}

// Notification permission status
let permissionGranted = false;
let expoPushToken: string | null = null;

// Notification listeners
const listeners: ((notification: PushNotification) => void)[] = [];

// Initialize notifications (simplified for web/expo compatibility)
export async function initializeNotifications(): Promise<boolean> {
  try {
    // For web platform, use a simplified approach
    if (Platform.OS === 'web') {
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        permissionGranted = permission === 'granted';
        return permissionGranted;
      }
      return false;
    }
    
    // For native platforms, we'd use expo-notifications
    // This is a fallback that works without the native module
    permissionGranted = true;
    return true;
  } catch (error) {
    console.log('Notification initialization error:', error);
    return false;
  }
}

// Request notification permissions
export async function requestPermissions(): Promise<boolean> {
  return initializeNotifications();
}

// Get push token
export function getPushToken(): string | null {
  return expoPushToken;
}

// Check if notifications are enabled
export function areNotificationsEnabled(): boolean {
  return permissionGranted;
}

// Add notification listener
export function addNotificationListener(callback: (notification: PushNotification) => void): () => void {
  listeners.push(callback);
  return () => {
    const index = listeners.indexOf(callback);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  };
}

// Send local notification
export async function sendLocalNotification(notification: Omit<PushNotification, 'id' | 'timestamp'>): Promise<void> {
  const fullNotification: PushNotification = {
    ...notification,
    id: Date.now().toString(),
    timestamp: Date.now(),
  };

  // Notify all listeners
  listeners.forEach(listener => listener(fullNotification));

  // Show browser notification on web
  if (Platform.OS === 'web' && permissionGranted && 'Notification' in window) {
    new Notification(notification.title, {
      body: notification.body,
      icon: '/icon.png',
      tag: fullNotification.id,
    });
  }
}

// Notification helper functions for specific events
export const NotificationHelpers = {
  // Vote received notification
  voteReceived: async (artistName: string, contestName: string, totalVotes: number) => {
    await sendLocalNotification({
      type: 'vote_received',
      title: 'New Vote!',
      body: `Someone voted for you in ${contestName}! Total votes: ${totalVotes}`,
      data: { artistName, contestName, totalVotes },
    });
  },

  // Contest advancement notification
  contestAdvance: async (contestName: string, newRound: string, position: number) => {
    await sendLocalNotification({
      type: 'contest_advance',
      title: 'Congratulations! You Advanced!',
      body: `You made it to ${newRound} in ${contestName}! Current position: #${position}`,
      data: { contestName, newRound, position },
    });
  },

  // Contest elimination notification
  contestEliminated: async (contestName: string, finalPosition: number) => {
    await sendLocalNotification({
      type: 'contest_eliminated',
      title: 'Contest Update',
      body: `Your run in ${contestName} has ended. Final position: #${finalPosition}. Keep creating!`,
      data: { contestName, finalPosition },
    });
  },

  // Message received notification
  messageReceived: async (senderName: string, messagePreview: string) => {
    await sendLocalNotification({
      type: 'message_received',
      title: `New message from ${senderName}`,
      body: messagePreview.length > 50 ? messagePreview.substring(0, 50) + '...' : messagePreview,
      data: { senderName, messagePreview },
    });
  },

  // Content liked notification
  contentLiked: async (contentType: string, contentName: string, likerName: string) => {
    await sendLocalNotification({
      type: 'content_liked',
      title: 'New Like!',
      body: `${likerName} liked your ${contentType}: "${contentName}"`,
      data: { contentType, contentName, likerName },
    });
  },

  // Content purchased notification
  contentPurchased: async (contentType: string, contentName: string, buyerName: string, amount: number) => {
    await sendLocalNotification({
      type: 'content_purchased',
      title: 'New Sale!',
      body: `${buyerName} purchased your ${contentType} "${contentName}" for $${amount.toFixed(2)}!`,
      data: { contentType, contentName, buyerName, amount },
    });
  },

  // Payout complete notification
  payoutComplete: async (amount: number, method: string) => {
    await sendLocalNotification({
      type: 'payout_complete',
      title: 'Payout Complete!',
      body: `$${amount.toFixed(2)} has been sent to your ${method}`,
      data: { amount, method },
    });
  },

  // System notification
  system: async (title: string, body: string, data?: Record<string, any>) => {
    await sendLocalNotification({
      type: 'system',
      title,
      body,
      data,
    });
  },
};

// Schedule notification for later
export async function scheduleNotification(
  notification: Omit<PushNotification, 'id' | 'timestamp'>,
  delaySeconds: number
): Promise<string> {
  const notificationId = Date.now().toString();
  
  setTimeout(() => {
    sendLocalNotification(notification);
  }, delaySeconds * 1000);

  return notificationId;
}

// Cancel scheduled notification
export async function cancelScheduledNotification(notificationId: string): Promise<void> {
  // In a real implementation, we'd track and cancel scheduled notifications
  console.log('Cancelling notification:', notificationId);
}

// Cancel all notifications
export async function cancelAllNotifications(): Promise<void> {
  // Clear all pending notifications
  console.log('Cancelling all notifications');
}

// Get notification badge count
export async function getBadgeCount(): Promise<number> {
  return 0;
}

// Set notification badge count
export async function setBadgeCount(count: number): Promise<void> {
  // Set badge count (iOS only in native)
  console.log('Setting badge count:', count);
}

export default {
  initializeNotifications,
  requestPermissions,
  getPushToken,
  areNotificationsEnabled,
  addNotificationListener,
  sendLocalNotification,
  scheduleNotification,
  cancelScheduledNotification,
  cancelAllNotifications,
  getBadgeCount,
  setBadgeCount,
  ...NotificationHelpers,
};
