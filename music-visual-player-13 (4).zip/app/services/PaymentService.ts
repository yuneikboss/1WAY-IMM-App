import { supabase } from '../lib/supabase';

// Payment types
export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  client_secret: string;
}

export interface Receipt {
  id: string;
  type: 'deposit' | 'payout' | 'subscription' | 'purchase' | 'sale';
  amount: number;
  fee: number;
  net?: number;
  description: string;
  status: 'completed' | 'pending' | 'failed';
  timestamp: string;
  paymentMethod?: string;
}

export interface CheckoutSession {
  sessionId: string;
  paymentIntent: PaymentIntent;
  amount: number;
  fee: number;
  net: number;
  currency: string;
  expiresAt: number;
}

export interface Subscription {
  id: string;
  status: string;
  current_period_start: number;
  current_period_end: number;
  features: string[];
}

export interface Payout {
  id: string;
  amount: number;
  fee: number;
  net: number;
  status: string;
  estimatedArrival: string;
}

// Create checkout session for adding funds
export async function createCheckoutSession(
  amount: number,
  userId: string,
  email: string,
  paymentMethod: string
): Promise<CheckoutSession | null> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'create_checkout_session',
        amount,
        userId,
        email,
        paymentMethod,
        currency: 'usd',
      },
    });

    if (error) throw error;
    if (!data.success) throw new Error(data.error);

    return data as CheckoutSession;
  } catch (error) {
    console.error('Failed to create checkout session:', error);
    return null;
  }
}

// Confirm payment
export async function confirmPayment(
  paymentIntentId: string,
  paymentMethodId: string,
  amount: number,
  metadata: Record<string, string>
): Promise<{ success: boolean; receipt?: Receipt; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'confirm_payment',
        paymentIntentId,
        paymentMethodId,
        amount,
        metadata,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      receipt: data.receipt,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to confirm payment:', error);
    return { success: false, error: 'Payment confirmation failed' };
  }
}

// Subscribe to premium
export async function subscribeToPremium(
  userId: string,
  email: string,
  paymentMethodId: string
): Promise<{ success: boolean; subscription?: Subscription; receipt?: Receipt; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'subscribe_premium',
        userId,
        email,
        paymentMethodId,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      subscription: data.subscription ? {
        ...data.subscription,
        features: data.features,
      } : undefined,
      receipt: data.receipt,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to subscribe to premium:', error);
    return { success: false, error: 'Subscription failed' };
  }
}

// Cancel subscription
export async function cancelSubscription(
  subscriptionId: string,
  cancelImmediately: boolean = false
): Promise<{ success: boolean; message?: string; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'cancel_subscription',
        subscriptionId,
        cancelImmediately,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      message: data.message,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to cancel subscription:', error);
    return { success: false, error: 'Cancellation failed' };
  }
}

// Request payout
export async function requestPayout(
  amount: number,
  destination: string,
  method: 'instant' | 'standard' | 'debit_card' | 'bank',
  userId: string
): Promise<{ success: boolean; payout?: Payout; receipt?: Receipt; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'request_payout',
        amount,
        destination,
        method,
        userId,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      payout: data.payout ? {
        id: data.payout.id,
        amount: data.amount,
        fee: data.fee,
        net: data.net,
        status: data.payout.status,
        estimatedArrival: data.estimatedArrival,
      } : undefined,
      receipt: data.receipt,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to request payout:', error);
    return { success: false, error: 'Payout request failed' };
  }
}

// Purchase microphone
export async function purchaseMicrophone(
  micId: string,
  price: number,
  userId: string,
  paymentMethodId: string
): Promise<{ success: boolean; receipt?: Receipt; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'purchase_mic',
        micId,
        price,
        userId,
        paymentMethodId,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      receipt: data.receipt,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to purchase microphone:', error);
    return { success: false, error: 'Purchase failed' };
  }
}

// Process sale
export async function processSale(
  sellerId: string,
  buyerId: string,
  contentType: string,
  contentId: string,
  amount: number
): Promise<{ success: boolean; saleId?: string; netAmount?: number; receipt?: Receipt; error?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'process_sale',
        sellerId,
        buyerId,
        contentType,
        contentId,
        amount,
      },
    });

    if (error) throw error;

    return {
      success: data.success,
      saleId: data.saleId,
      netAmount: data.netAmount,
      receipt: data.receipt,
      error: data.error,
    };
  } catch (error) {
    console.error('Failed to process sale:', error);
    return { success: false, error: 'Sale processing failed' };
  }
}

// Get payment methods
export async function getPaymentMethods(): Promise<{
  methods: Array<{ id: string; name: string; icon: string; fee: string; instant: boolean }>;
  payoutMethods: Array<{ id: string; name: string; fee: string; speed: string }>;
} | null> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: { action: 'get_payment_methods' },
    });

    if (error) throw error;

    return {
      methods: data.methods,
      payoutMethods: data.payoutMethods,
    };
  } catch (error) {
    console.error('Failed to get payment methods:', error);
    return null;
  }
}

// Get transaction history
export async function getTransactionHistory(
  userId: string,
  limit: number = 50,
  offset: number = 0
): Promise<{ transactions: Receipt[]; total: number } | null> {
  try {
    const { data, error } = await supabase.functions.invoke('stripe-payments', {
      body: {
        action: 'get_transactions',
        userId,
        limit,
        offset,
      },
    });

    if (error) throw error;

    return {
      transactions: data.transactions,
      total: data.total,
    };
  } catch (error) {
    console.error('Failed to get transaction history:', error);
    return null;
  }
}

// Calculate fee preview
export function calculateFeePreview(
  amount: number,
  paymentMethod: string,
  action: 'add_funds' | 'payout'
): { fee: number; net: number } {
  let feeRate = 0;
  let flatFee = 0;

  if (action === 'add_funds') {
    if (paymentMethod === 'bank' || paymentMethod === 'ach') {
      feeRate = 0.008;
    } else {
      feeRate = 0.029;
      flatFee = 0.30;
    }
  } else if (action === 'payout') {
    if (paymentMethod === 'instant' || paymentMethod === 'debit_card') {
      feeRate = 0.01;
    }
  }

  const fee = Math.round((amount * feeRate + flatFee) * 100) / 100;
  const net = Math.round((amount - fee) * 100) / 100;

  return { fee, net };
}

export default {
  createCheckoutSession,
  confirmPayment,
  subscribeToPremium,
  cancelSubscription,
  requestPayout,
  purchaseMicrophone,
  processSale,
  getPaymentMethods,
  getTransactionHistory,
  calculateFeePreview,
};
