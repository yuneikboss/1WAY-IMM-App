import { Share, Platform, Linking } from 'react-native';

export interface ShareContent {
  type: 'track' | 'contest_entry' | 'achievement' | 'profile' | 'collaboration';
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  url?: string;
}

export interface ShareAnalytics {
  id: string;
  contentId: string;
  contentType: string;
  platform: 'instagram' | 'twitter' | 'tiktok' | 'facebook' | 'other';
  timestamp: number;
  clicks: number;
  views: number;
  conversions: number;
}

export interface DeepLinkData {
  type: string;
  id: string;
  referrer?: string;
  campaign?: string;
}

const APP_SCHEME = 'oneway';
const APP_DOMAIN = 'app.1way.music';
const WEB_DOMAIN = 'https://1way.music';

class SocialSharingService {
  private shareAnalytics: ShareAnalytics[] = [];

  // Generate deep link URL
  generateDeepLink(content: ShareContent, platform?: string): string {
    const baseUrl = `${WEB_DOMAIN}/share`;
    const params = new URLSearchParams({
      type: content.type,
      id: content.id,
      ...(platform && { ref: platform }),
    });
    return `${baseUrl}?${params.toString()}`;
  }

  // Generate app-specific deep link
  generateAppLink(content: ShareContent): string {
    return `${APP_SCHEME}://${content.type}/${content.id}`;
  }

  // Parse incoming deep link
  parseDeepLink(url: string): DeepLinkData | null {
    try {
      // Handle app scheme links
      if (url.startsWith(APP_SCHEME)) {
        const path = url.replace(`${APP_SCHEME}://`, '');
        const parts = path.split('/');
        return {
          type: parts[0],
          id: parts[1],
        };
      }

      // Handle web links
      const urlObj = new URL(url);
      const params = urlObj.searchParams;
      return {
        type: params.get('type') || '',
        id: params.get('id') || '',
        referrer: params.get('ref') || undefined,
        campaign: params.get('campaign') || undefined,
      };
    } catch {
      return null;
    }
  }

  // Share to native share sheet
  async shareNative(content: ShareContent): Promise<{ success: boolean; platform?: string }> {
    try {
      const shareUrl = this.generateDeepLink(content);
      const message = `${content.title}\n\n${content.description}\n\n${shareUrl}`;

      const result = await Share.share({
        message,
        url: shareUrl,
        title: content.title,
      });

      if (result.action === Share.sharedAction) {
        const platform = result.activityType?.toLowerCase().includes('twitter') ? 'twitter' :
                        result.activityType?.toLowerCase().includes('instagram') ? 'instagram' :
                        result.activityType?.toLowerCase().includes('facebook') ? 'facebook' :
                        result.activityType?.toLowerCase().includes('tiktok') ? 'tiktok' : 'other';
        
        this.trackShare(content, platform as any);
        return { success: true, platform };
      }

      return { success: false };
    } catch (error) {
      console.error('Share failed:', error);
      return { success: false };
    }
  }

  // Share to specific platform
  async shareToPlatform(
    content: ShareContent,
    platform: 'instagram' | 'twitter' | 'tiktok' | 'facebook'
  ): Promise<boolean> {
    const shareUrl = encodeURIComponent(this.generateDeepLink(content, platform));
    const text = encodeURIComponent(`${content.title} - ${content.description}`);
    
    let platformUrl = '';

    switch (platform) {
      case 'twitter':
        platformUrl = `https://twitter.com/intent/tweet?text=${text}&url=${shareUrl}`;
        break;
      case 'facebook':
        platformUrl = `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${text}`;
        break;
      case 'instagram':
        // Instagram doesn't have a direct share URL, use native share
        return (await this.shareNative(content)).success;
      case 'tiktok':
        // TikTok doesn't have a direct share URL, use native share
        return (await this.shareNative(content)).success;
    }

    try {
      const canOpen = await Linking.canOpenURL(platformUrl);
      if (canOpen) {
        await Linking.openURL(platformUrl);
        this.trackShare(content, platform);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  // Track share analytics
  trackShare(content: ShareContent, platform: ShareAnalytics['platform']): void {
    const analytics: ShareAnalytics = {
      id: Date.now().toString(),
      contentId: content.id,
      contentType: content.type,
      platform,
      timestamp: Date.now(),
      clicks: 0,
      views: 0,
      conversions: 0,
    };
    this.shareAnalytics.push(analytics);
  }

  // Get share analytics for content
  getShareAnalytics(contentId: string): ShareAnalytics[] {
    return this.shareAnalytics.filter(a => a.contentId === contentId);
  }

  // Get all share analytics
  getAllShareAnalytics(): ShareAnalytics[] {
    return [...this.shareAnalytics];
  }

  // Get share stats summary
  getShareStats(): {
    totalShares: number;
    byPlatform: { [key: string]: number };
    totalClicks: number;
    totalViews: number;
    totalConversions: number;
  } {
    const stats = {
      totalShares: this.shareAnalytics.length,
      byPlatform: {} as { [key: string]: number },
      totalClicks: 0,
      totalViews: 0,
      totalConversions: 0,
    };

    this.shareAnalytics.forEach(a => {
      stats.byPlatform[a.platform] = (stats.byPlatform[a.platform] || 0) + 1;
      stats.totalClicks += a.clicks;
      stats.totalViews += a.views;
      stats.totalConversions += a.conversions;
    });

    return stats;
  }

  // Update analytics when link is clicked
  recordClick(shareId: string): void {
    const analytics = this.shareAnalytics.find(a => a.id === shareId);
    if (analytics) {
      analytics.clicks++;
    }
  }

  // Update analytics when content is viewed
  recordView(shareId: string): void {
    const analytics = this.shareAnalytics.find(a => a.id === shareId);
    if (analytics) {
      analytics.views++;
    }
  }

  // Update analytics when conversion happens (follow, purchase, etc.)
  recordConversion(shareId: string): void {
    const analytics = this.shareAnalytics.find(a => a.id === shareId);
    if (analytics) {
      analytics.conversions++;
    }
  }

  // Generate shareable achievement card data
  generateAchievementCard(
    type: 'milestone_plays' | 'contest_win' | 'earnings' | 'followers',
    value: number,
    artistName: string,
    trackName?: string
  ): ShareContent {
    let title = '';
    let description = '';

    switch (type) {
      case 'milestone_plays':
        title = `${this.formatNumber(value)} Plays Milestone!`;
        description = trackName 
          ? `${artistName}'s track "${trackName}" just hit ${this.formatNumber(value)} plays on 1WAY!`
          : `${artistName} just hit ${this.formatNumber(value)} total plays on 1WAY!`;
        break;
      case 'contest_win':
        title = 'Contest Winner!';
        description = `${artistName} just won a contest on 1WAY! Congratulations!`;
        break;
      case 'earnings':
        title = `$${value.toFixed(0)} Earned!`;
        description = `${artistName} has earned $${value.toFixed(0)} on 1WAY! Join the music revolution.`;
        break;
      case 'followers':
        title = `${this.formatNumber(value)} Followers!`;
        description = `${artistName} just reached ${this.formatNumber(value)} followers on 1WAY!`;
        break;
    }

    return {
      type: 'achievement',
      id: `achievement_${type}_${Date.now()}`,
      title,
      description,
    };
  }

  private formatNumber(num: number): string {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  }
}

export const socialSharingService = new SocialSharingService();
export default socialSharingService;
