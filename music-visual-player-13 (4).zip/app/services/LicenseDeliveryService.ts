// License Delivery Service for Beat Marketplace
// Handles PDF license generation, email delivery, and purchase history

export interface LicenseType {
  id: 'mp3' | 'wav' | 'stems' | 'exclusive';
  name: string;
  description: string;
  streams: number | 'unlimited';
  downloads: number | 'unlimited';
  radioPlay: boolean;
  musicVideo: boolean;
  livePerformance: boolean;
  ownership: 'lease' | 'exclusive';
  duration: string;
  fileFormats: string[];
}

export interface PurchasedBeat {
  id: string;
  beatId: string;
  beatTitle: string;
  producerName: string;
  producerId: string;
  coverImage: string;
  licenseType: LicenseType['id'];
  licenseName: string;
  price: number;
  purchaseDate: number;
  expiryDate?: number;
  downloadUrl: string;
  licenseUrl: string;
  downloadCount: number;
  maxDownloads: number;
  isActive: boolean;
}

export interface LicenseAgreement {
  id: string;
  purchaseId: string;
  beatTitle: string;
  producerName: string;
  buyerName: string;
  buyerEmail: string;
  licenseType: LicenseType;
  purchaseDate: string;
  price: number;
  terms: string[];
  restrictions: string[];
  signature?: string;
  signedDate?: string;
}

// License type definitions
export const LICENSE_TYPES: Record<string, LicenseType> = {
  mp3: {
    id: 'mp3',
    name: 'MP3 Lease',
    description: 'Basic lease for streaming and promotional use',
    streams: 5000,
    downloads: 2500,
    radioPlay: false,
    musicVideo: false,
    livePerformance: true,
    ownership: 'lease',
    duration: '1 year',
    fileFormats: ['MP3 (320kbps)'],
  },
  wav: {
    id: 'wav',
    name: 'WAV Lease',
    description: 'Premium lease with higher quality audio',
    streams: 10000,
    downloads: 5000,
    radioPlay: true,
    musicVideo: false,
    livePerformance: true,
    ownership: 'lease',
    duration: '2 years',
    fileFormats: ['MP3 (320kbps)', 'WAV (24-bit)'],
  },
  stems: {
    id: 'stems',
    name: 'Trackout License',
    description: 'Full stems for professional mixing',
    streams: 25000,
    downloads: 10000,
    radioPlay: true,
    musicVideo: true,
    livePerformance: true,
    ownership: 'lease',
    duration: '3 years',
    fileFormats: ['MP3 (320kbps)', 'WAV (24-bit)', 'Stems (WAV)'],
  },
  exclusive: {
    id: 'exclusive',
    name: 'Exclusive Rights',
    description: 'Full ownership - beat removed from marketplace',
    streams: 'unlimited',
    downloads: 'unlimited',
    radioPlay: true,
    musicVideo: true,
    livePerformance: true,
    ownership: 'exclusive',
    duration: 'Lifetime',
    fileFormats: ['MP3 (320kbps)', 'WAV (24-bit)', 'Stems (WAV)', 'Project Files'],
  },
};

// Generate license agreement content
export function generateLicenseAgreement(
  beatTitle: string,
  producerName: string,
  buyerName: string,
  buyerEmail: string,
  licenseType: LicenseType['id'],
  price: number
): LicenseAgreement {
  const license = LICENSE_TYPES[licenseType];
  const purchaseDate = new Date().toISOString();
  
  const terms: string[] = [
    `This license grants ${buyerName} the right to use the beat "${beatTitle}" produced by ${producerName}.`,
    `License Type: ${license.name}`,
    `Maximum Streams: ${license.streams === 'unlimited' ? 'Unlimited' : license.streams.toLocaleString()}`,
    `Maximum Downloads/Sales: ${license.downloads === 'unlimited' ? 'Unlimited' : license.downloads.toLocaleString()}`,
    `Radio Play: ${license.radioPlay ? 'Permitted' : 'Not Permitted'}`,
    `Music Video: ${license.musicVideo ? 'Permitted' : 'Not Permitted'}`,
    `Live Performance: ${license.livePerformance ? 'Permitted' : 'Not Permitted'}`,
    `License Duration: ${license.duration}`,
    `File Formats Included: ${license.fileFormats.join(', ')}`,
  ];

  const restrictions: string[] = [];
  
  if (license.ownership === 'lease') {
    restrictions.push('This is a non-exclusive lease. The producer retains ownership and may license this beat to other artists.');
    restrictions.push('You may not resell, redistribute, or transfer this license to any third party.');
    restrictions.push('You must credit the producer in all releases using this beat.');
    restrictions.push(`This license expires after ${license.duration} from the purchase date.`);
  } else {
    restrictions.push('This is an exclusive license. The beat will be removed from the marketplace.');
    restrictions.push('You own full rights to use this beat without limitations.');
    restrictions.push('Producer credit is appreciated but not required.');
    restrictions.push('This license never expires.');
  }

  return {
    id: `LIC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    purchaseId: `PUR-${Date.now()}`,
    beatTitle,
    producerName,
    buyerName,
    buyerEmail,
    licenseType: license,
    purchaseDate,
    price,
    terms,
    restrictions,
  };
}

// Generate PDF content (returns base64 string representation)
export function generateLicensePDF(agreement: LicenseAgreement): string {
  // In a real implementation, this would use a PDF library
  // For now, we'll return a formatted text representation
  const pdfContent = `
================================================================================
                           BEAT LICENSE AGREEMENT
================================================================================

License ID: ${agreement.id}
Purchase ID: ${agreement.purchaseId}
Date: ${new Date(agreement.purchaseDate).toLocaleDateString()}

--------------------------------------------------------------------------------
                              PARTIES
--------------------------------------------------------------------------------

LICENSOR (Producer): ${agreement.producerName}
LICENSEE (Buyer): ${agreement.buyerName}
Email: ${agreement.buyerEmail}

--------------------------------------------------------------------------------
                           BEAT INFORMATION
--------------------------------------------------------------------------------

Beat Title: "${agreement.beatTitle}"
License Type: ${agreement.licenseType.name}
Purchase Price: $${agreement.price.toFixed(2)}

--------------------------------------------------------------------------------
                           LICENSE TERMS
--------------------------------------------------------------------------------

${agreement.terms.map((term, i) => `${i + 1}. ${term}`).join('\n')}

--------------------------------------------------------------------------------
                           RESTRICTIONS
--------------------------------------------------------------------------------

${agreement.restrictions.map((r, i) => `${i + 1}. ${r}`).join('\n')}

--------------------------------------------------------------------------------
                           USAGE RIGHTS
--------------------------------------------------------------------------------

Streaming Limit: ${agreement.licenseType.streams === 'unlimited' ? 'Unlimited' : agreement.licenseType.streams.toLocaleString()}
Download/Sales Limit: ${agreement.licenseType.downloads === 'unlimited' ? 'Unlimited' : agreement.licenseType.downloads.toLocaleString()}
Radio Play: ${agreement.licenseType.radioPlay ? 'YES' : 'NO'}
Music Video: ${agreement.licenseType.musicVideo ? 'YES' : 'NO'}
Live Performance: ${agreement.licenseType.livePerformance ? 'YES' : 'NO'}
License Duration: ${agreement.licenseType.duration}

--------------------------------------------------------------------------------
                           FILE FORMATS INCLUDED
--------------------------------------------------------------------------------

${agreement.licenseType.fileFormats.map(f => `• ${f}`).join('\n')}

--------------------------------------------------------------------------------
                           LEGAL NOTICE
--------------------------------------------------------------------------------

By purchasing this license, the Licensee agrees to all terms and conditions
outlined in this agreement. Violation of any terms may result in legal action
and revocation of the license.

This agreement is legally binding upon acceptance of payment.

================================================================================
                    Thank you for your purchase!
                         1WAY Music Platform
================================================================================
`;

  // Convert to base64 for storage/transmission
  return Buffer.from ? Buffer.from(pdfContent).toString('base64') : btoa(pdfContent);
}

// Purchase history storage (in-memory for demo, would use database in production)
let purchaseHistory: PurchasedBeat[] = [];

// Add purchase to history
export function addPurchaseToHistory(purchase: Omit<PurchasedBeat, 'id' | 'downloadCount'>): PurchasedBeat {
  const newPurchase: PurchasedBeat = {
    ...purchase,
    id: `PUR-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    downloadCount: 0,
  };
  
  purchaseHistory.push(newPurchase);
  return newPurchase;
}

// Get purchase history for user
export function getPurchaseHistory(): PurchasedBeat[] {
  return [...purchaseHistory];
}

// Get specific purchase
export function getPurchaseById(purchaseId: string): PurchasedBeat | undefined {
  return purchaseHistory.find(p => p.id === purchaseId);
}

// Increment download count
export function incrementDownloadCount(purchaseId: string): boolean {
  const purchase = purchaseHistory.find(p => p.id === purchaseId);
  if (purchase && purchase.downloadCount < purchase.maxDownloads) {
    purchase.downloadCount++;
    return true;
  }
  return false;
}

// Check if download is available
export function canDownload(purchaseId: string): { canDownload: boolean; reason?: string } {
  const purchase = purchaseHistory.find(p => p.id === purchaseId);
  
  if (!purchase) {
    return { canDownload: false, reason: 'Purchase not found' };
  }
  
  if (!purchase.isActive) {
    return { canDownload: false, reason: 'License has been revoked' };
  }
  
  if (purchase.expiryDate && purchase.expiryDate < Date.now()) {
    return { canDownload: false, reason: 'License has expired' };
  }
  
  if (purchase.downloadCount >= purchase.maxDownloads) {
    return { canDownload: false, reason: 'Maximum downloads reached' };
  }
  
  return { canDownload: true };
}

// Send email notification (mock implementation)
export async function sendLicenseEmail(
  email: string,
  buyerName: string,
  beatTitle: string,
  licenseType: string,
  downloadUrl: string,
  licenseUrl: string
): Promise<boolean> {
  // In production, this would integrate with an email service
  console.log(`
    Sending license email to: ${email}
    Subject: Your Beat Purchase - ${beatTitle}
    
    Dear ${buyerName},
    
    Thank you for your purchase!
    
    Beat: ${beatTitle}
    License: ${licenseType}
    
    Download your files: ${downloadUrl}
    View your license: ${licenseUrl}
    
    Best regards,
    1WAY Music Platform
  `);
  
  return true;
}

// Process complete beat purchase
export async function processBeatPurchase(
  beatId: string,
  beatTitle: string,
  producerName: string,
  producerId: string,
  coverImage: string,
  licenseType: LicenseType['id'],
  price: number,
  buyerName: string,
  buyerEmail: string
): Promise<{ success: boolean; purchase?: PurchasedBeat; agreement?: LicenseAgreement; error?: string }> {
  try {
    // Generate license agreement
    const agreement = generateLicenseAgreement(
      beatTitle,
      producerName,
      buyerName,
      buyerEmail,
      licenseType,
      price
    );
    
    // Generate PDF
    const pdfContent = generateLicensePDF(agreement);
    
    // Create download URLs (mock)
    const downloadUrl = `https://1way.app/downloads/${beatId}/${licenseType}`;
    const licenseUrl = `https://1way.app/licenses/${agreement.id}`;
    
    // Calculate expiry date based on license type
    const license = LICENSE_TYPES[licenseType];
    let expiryDate: number | undefined;
    
    if (license.ownership === 'lease') {
      const years = parseInt(license.duration) || 1;
      expiryDate = Date.now() + (years * 365 * 24 * 60 * 60 * 1000);
    }
    
    // Determine max downloads
    const maxDownloads = license.ownership === 'exclusive' ? 999 : 
                         licenseType === 'mp3' ? 3 :
                         licenseType === 'wav' ? 5 :
                         licenseType === 'stems' ? 10 : 999;
    
    // Add to purchase history
    const purchase = addPurchaseToHistory({
      beatId,
      beatTitle,
      producerName,
      producerId,
      coverImage,
      licenseType,
      licenseName: license.name,
      price,
      purchaseDate: Date.now(),
      expiryDate,
      downloadUrl,
      licenseUrl,
      maxDownloads,
      isActive: true,
    });
    
    // Send email notification
    await sendLicenseEmail(
      buyerEmail,
      buyerName,
      beatTitle,
      license.name,
      downloadUrl,
      licenseUrl
    );
    
    return {
      success: true,
      purchase,
      agreement,
    };
  } catch (error) {
    console.error('Failed to process beat purchase:', error);
    return {
      success: false,
      error: 'Failed to process purchase',
    };
  }
}

export default {
  LICENSE_TYPES,
  generateLicenseAgreement,
  generateLicensePDF,
  addPurchaseToHistory,
  getPurchaseHistory,
  getPurchaseById,
  incrementDownloadCount,
  canDownload,
  sendLicenseEmail,
  processBeatPurchase,
};
