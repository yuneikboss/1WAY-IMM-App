// Media Upload Service
// Handles file uploads with validation, progress tracking, and integration with user profile

import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';

export interface UploadFile {
  id: string;
  uri: string;
  name: string;
  type: 'music' | 'video' | 'picture';
  mimeType: string;
  size: number;
  duration?: number;
}

export interface UploadProgress {
  fileId: string;
  progress: number; // 0-100
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'failed';
  error?: string;
}

export interface UploadResult {
  success: boolean;
  file?: UploadFile;
  error?: string;
}

// File type configurations
export const FILE_CONFIGS = {
  music: {
    mimeTypes: ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav', 'audio/aac', 'audio/m4a'],
    extensions: ['.mp3', '.wav', '.aac', '.m4a'],
    maxSize: 50 * 1024 * 1024, // 50MB
    maxSizeLabel: '50MB',
  },
  video: {
    mimeTypes: ['video/mp4', 'video/quicktime', 'video/x-m4v', 'video/mpeg'],
    extensions: ['.mp4', '.mov', '.m4v', '.mpeg'],
    maxSize: 500 * 1024 * 1024, // 500MB
    maxSizeLabel: '500MB',
  },
  picture: {
    mimeTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/heic'],
    extensions: ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.heic'],
    maxSize: 10 * 1024 * 1024, // 10MB
    maxSizeLabel: '10MB',
  },
};

// Upload progress listeners
type ProgressListener = (progress: UploadProgress) => void;
const progressListeners: Map<string, ProgressListener[]> = new Map();

// Add progress listener
export function addProgressListener(fileId: string, listener: ProgressListener): () => void {
  const listeners = progressListeners.get(fileId) || [];
  listeners.push(listener);
  progressListeners.set(fileId, listeners);
  
  return () => {
    const current = progressListeners.get(fileId) || [];
    progressListeners.set(fileId, current.filter(l => l !== listener));
  };
}

// Notify progress listeners
function notifyProgress(progress: UploadProgress) {
  const listeners = progressListeners.get(progress.fileId) || [];
  listeners.forEach(listener => listener(progress));
}

// Validate file type
export function validateFileType(
  mimeType: string,
  fileName: string,
  type: 'music' | 'video' | 'picture'
): { valid: boolean; error?: string } {
  const config = FILE_CONFIGS[type];
  
  // Check MIME type
  const mimeValid = config.mimeTypes.some(mime => 
    mimeType.toLowerCase().includes(mime.split('/')[1]) || mimeType === mime
  );
  
  // Check extension
  const extension = fileName.toLowerCase().substring(fileName.lastIndexOf('.'));
  const extValid = config.extensions.includes(extension);
  
  if (!mimeValid && !extValid) {
    return {
      valid: false,
      error: `Invalid file type. Supported formats: ${config.extensions.join(', ')}`,
    };
  }
  
  return { valid: true };
}

// Validate file size
export function validateFileSize(
  size: number,
  type: 'music' | 'video' | 'picture'
): { valid: boolean; error?: string } {
  const config = FILE_CONFIGS[type];
  
  if (size > config.maxSize) {
    return {
      valid: false,
      error: `File too large. Maximum size: ${config.maxSizeLabel}`,
    };
  }
  
  return { valid: true };
}

// Format file size for display
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

// Request permissions
export async function requestPermissions(): Promise<{ camera: boolean; mediaLibrary: boolean }> {
  const [cameraResult, mediaResult] = await Promise.all([
    ImagePicker.requestCameraPermissionsAsync(),
    ImagePicker.requestMediaLibraryPermissionsAsync(),
  ]);
  
  return {
    camera: cameraResult.status === 'granted',
    mediaLibrary: mediaResult.status === 'granted',
  };
}

// Pick image from library
export async function pickImage(options?: {
  allowsEditing?: boolean;
  quality?: number;
}): Promise<UploadResult> {
  try {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: options?.allowsEditing ?? false,
      quality: options?.quality ?? 0.8,
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Selection cancelled' };
    }
    
    const asset = result.assets[0];
    const fileName = asset.uri.split('/').pop() || `image_${Date.now()}.jpg`;
    const fileSize = asset.fileSize || 0;
    
    // Validate
    const sizeValidation = validateFileSize(fileSize, 'picture');
    if (!sizeValidation.valid) {
      return { success: false, error: sizeValidation.error };
    }
    
    const file: UploadFile = {
      id: `img_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: fileName,
      type: 'picture',
      mimeType: asset.mimeType || 'image/jpeg',
      size: fileSize,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to pick image:', error);
    return { success: false, error: 'Failed to select image' };
  }
}

// Take photo with camera
export async function takePhoto(options?: {
  allowsEditing?: boolean;
  quality?: number;
}): Promise<UploadResult> {
  try {
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: options?.allowsEditing ?? false,
      quality: options?.quality ?? 0.8,
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Capture cancelled' };
    }
    
    const asset = result.assets[0];
    const fileName = `photo_${Date.now()}.jpg`;
    const fileSize = asset.fileSize || 0;
    
    const file: UploadFile = {
      id: `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: fileName,
      type: 'picture',
      mimeType: 'image/jpeg',
      size: fileSize,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to take photo:', error);
    return { success: false, error: 'Failed to capture photo' };
  }
}

// Pick video from library
export async function pickVideo(): Promise<UploadResult> {
  try {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: false,
      quality: 1,
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Selection cancelled' };
    }
    
    const asset = result.assets[0];
    const fileName = asset.uri.split('/').pop() || `video_${Date.now()}.mp4`;
    const fileSize = asset.fileSize || 0;
    
    // Validate
    const sizeValidation = validateFileSize(fileSize, 'video');
    if (!sizeValidation.valid) {
      return { success: false, error: sizeValidation.error };
    }
    
    const file: UploadFile = {
      id: `vid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: fileName,
      type: 'video',
      mimeType: asset.mimeType || 'video/mp4',
      size: fileSize,
      duration: asset.duration,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to pick video:', error);
    return { success: false, error: 'Failed to select video' };
  }
}

// Record video with camera
export async function recordVideo(): Promise<UploadResult> {
  try {
    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: false,
      quality: 1,
      videoMaxDuration: 300, // 5 minutes max
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Recording cancelled' };
    }
    
    const asset = result.assets[0];
    const fileName = `recording_${Date.now()}.mp4`;
    const fileSize = asset.fileSize || 0;
    
    const file: UploadFile = {
      id: `rec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: fileName,
      type: 'video',
      mimeType: 'video/mp4',
      size: fileSize,
      duration: asset.duration,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to record video:', error);
    return { success: false, error: 'Failed to record video' };
  }
}

// Pick audio file using document picker
export async function pickAudio(): Promise<UploadResult> {
  try {
    const result = await DocumentPicker.getDocumentAsync({
      type: FILE_CONFIGS.music.mimeTypes,
      copyToCacheDirectory: true,
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Selection cancelled' };
    }
    
    const asset = result.assets[0];
    
    // Validate type
    const typeValidation = validateFileType(asset.mimeType || '', asset.name, 'music');
    if (!typeValidation.valid) {
      return { success: false, error: typeValidation.error };
    }
    
    // Validate size
    const sizeValidation = validateFileSize(asset.size || 0, 'music');
    if (!sizeValidation.valid) {
      return { success: false, error: sizeValidation.error };
    }
    
    const file: UploadFile = {
      id: `audio_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: asset.name,
      type: 'music',
      mimeType: asset.mimeType || 'audio/mpeg',
      size: asset.size || 0,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to pick audio:', error);
    return { success: false, error: 'Failed to select audio file' };
  }
}

// Pick any document
export async function pickDocument(type: 'music' | 'video' | 'picture'): Promise<UploadResult> {
  try {
    const config = FILE_CONFIGS[type];
    
    const result = await DocumentPicker.getDocumentAsync({
      type: config.mimeTypes,
      copyToCacheDirectory: true,
    });
    
    if (result.canceled || !result.assets?.[0]) {
      return { success: false, error: 'Selection cancelled' };
    }
    
    const asset = result.assets[0];
    
    // Validate type
    const typeValidation = validateFileType(asset.mimeType || '', asset.name, type);
    if (!typeValidation.valid) {
      return { success: false, error: typeValidation.error };
    }
    
    // Validate size
    const sizeValidation = validateFileSize(asset.size || 0, type);
    if (!sizeValidation.valid) {
      return { success: false, error: sizeValidation.error };
    }
    
    const file: UploadFile = {
      id: `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      uri: asset.uri,
      name: asset.name,
      type,
      mimeType: asset.mimeType || '',
      size: asset.size || 0,
    };
    
    return { success: true, file };
  } catch (error) {
    console.error('Failed to pick document:', error);
    return { success: false, error: 'Failed to select file' };
  }
}

// Simulate upload with progress
export async function uploadFile(
  file: UploadFile,
  onProgress?: (progress: number) => void
): Promise<{ success: boolean; url?: string; error?: string }> {
  const fileId = file.id;
  
  try {
    // Simulate upload progress
    for (let progress = 0; progress <= 100; progress += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      
      const progressUpdate: UploadProgress = {
        fileId,
        progress,
        status: progress < 100 ? 'uploading' : 'processing',
      };
      
      notifyProgress(progressUpdate);
      onProgress?.(progress);
    }
    
    // Simulate processing
    await new Promise(resolve => setTimeout(resolve, 500));
    
    notifyProgress({
      fileId,
      progress: 100,
      status: 'completed',
    });
    
    // Return mock URL
    const url = `https://1way.app/media/${file.type}/${file.id}`;
    
    return { success: true, url };
  } catch (error) {
    notifyProgress({
      fileId,
      progress: 0,
      status: 'failed',
      error: 'Upload failed',
    });
    
    return { success: false, error: 'Upload failed' };
  }
}

// Delete uploaded file
export async function deleteFile(fileId: string): Promise<boolean> {
  // In production, this would delete from storage
  console.log(`Deleting file: ${fileId}`);
  return true;
}

// Get supported formats text
export function getSupportedFormatsText(type: 'music' | 'video' | 'picture'): string {
  const config = FILE_CONFIGS[type];
  return `Supported: ${config.extensions.join(', ')} (max ${config.maxSizeLabel})`;
}

export default {
  FILE_CONFIGS,
  validateFileType,
  validateFileSize,
  formatFileSize,
  requestPermissions,
  pickImage,
  takePhoto,
  pickVideo,
  recordVideo,
  pickAudio,
  pickDocument,
  uploadFile,
  deleteFile,
  addProgressListener,
  getSupportedFormatsText,
};
