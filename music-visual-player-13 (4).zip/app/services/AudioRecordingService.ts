import { Platform } from 'react-native';

// Recording state types
export type RecordingState = 'idle' | 'recording' | 'paused' | 'stopped';

export interface RecordingInfo {
  uri: string;
  duration: number;
  size: number;
  format: string;
  sampleRate: number;
  channels: number;
  bitRate: number;
}

export interface AudioEffect {
  id: string;
  name: string;
  enabled: boolean;
  value: number;
}

// Audio recording configuration
const RECORDING_OPTIONS = {
  android: {
    extension: '.m4a',
    outputFormat: 'mpeg4',
    audioEncoder: 'aac',
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
  },
  ios: {
    extension: '.m4a',
    outputFormat: 'mpeg4',
    audioQuality: 'high',
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: 'audio/webm',
    audioBitsPerSecond: 128000,
  },
};

// Recording state
let recordingState: RecordingState = 'idle';
let mediaRecorder: MediaRecorder | null = null;
let audioChunks: Blob[] = [];
let recordingStartTime: number = 0;
let currentRecordingUri: string | null = null;

// Audio context for effects and visualization
let audioContext: AudioContext | null = null;
let analyserNode: AnalyserNode | null = null;
let mediaStreamSource: MediaStreamAudioSourceNode | null = null;
let mediaStream: MediaStream | null = null;

// Waveform data
let waveformData: number[] = [];
const waveformListeners: ((data: number[]) => void)[] = [];

// Initialize audio context
async function initAudioContext(): Promise<boolean> {
  try {
    if (Platform.OS === 'web') {
      audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      analyserNode = audioContext.createAnalyser();
      analyserNode.fftSize = 256;
      return true;
    }
    return true;
  } catch (error) {
    console.error('Failed to initialize audio context:', error);
    return false;
  }
}

// Request microphone permissions
export async function requestMicrophonePermission(): Promise<boolean> {
  try {
    if (Platform.OS === 'web') {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      return true;
    }
    return true;
  } catch (error) {
    console.error('Microphone permission denied:', error);
    return false;
  }
}

// Start recording
export async function startRecording(): Promise<boolean> {
  try {
    if (recordingState === 'recording') {
      return false;
    }

    await initAudioContext();

    if (Platform.OS === 'web') {
      mediaStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100,
        }
      });

      // Set up analyser for waveform visualization
      if (audioContext && analyserNode) {
        mediaStreamSource = audioContext.createMediaStreamSource(mediaStream);
        mediaStreamSource.connect(analyserNode);
        startWaveformAnalysis();
      }

      // Create media recorder
      mediaRecorder = new MediaRecorder(mediaStream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000,
      });

      audioChunks = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data);
        }
      };

      mediaRecorder.start(100); // Collect data every 100ms
      recordingStartTime = Date.now();
      recordingState = 'recording';
      return true;
    }

    // For native platforms, we'd use expo-av
    recordingState = 'recording';
    recordingStartTime = Date.now();
    return true;
  } catch (error) {
    console.error('Failed to start recording:', error);
    return false;
  }
}

// Pause recording
export async function pauseRecording(): Promise<boolean> {
  try {
    if (recordingState !== 'recording') {
      return false;
    }

    if (Platform.OS === 'web' && mediaRecorder) {
      mediaRecorder.pause();
    }

    recordingState = 'paused';
    return true;
  } catch (error) {
    console.error('Failed to pause recording:', error);
    return false;
  }
}

// Resume recording
export async function resumeRecording(): Promise<boolean> {
  try {
    if (recordingState !== 'paused') {
      return false;
    }

    if (Platform.OS === 'web' && mediaRecorder) {
      mediaRecorder.resume();
    }

    recordingState = 'recording';
    return true;
  } catch (error) {
    console.error('Failed to resume recording:', error);
    return false;
  }
}

// Stop recording
export async function stopRecording(): Promise<RecordingInfo | null> {
  try {
    if (recordingState !== 'recording' && recordingState !== 'paused') {
      return null;
    }

    const duration = Date.now() - recordingStartTime;

    if (Platform.OS === 'web' && mediaRecorder) {
      return new Promise((resolve) => {
        mediaRecorder!.onstop = () => {
          const blob = new Blob(audioChunks, { type: 'audio/webm' });
          currentRecordingUri = URL.createObjectURL(blob);
          
          // Clean up
          stopWaveformAnalysis();
          if (mediaStream) {
            mediaStream.getTracks().forEach(track => track.stop());
          }
          if (mediaStreamSource) {
            mediaStreamSource.disconnect();
          }

          recordingState = 'stopped';

          resolve({
            uri: currentRecordingUri,
            duration: duration,
            size: blob.size,
            format: 'webm',
            sampleRate: 44100,
            channels: 2,
            bitRate: 128000,
          });
        };

        mediaRecorder!.stop();
      });
    }

    recordingState = 'stopped';
    return {
      uri: `recording_${Date.now()}.m4a`,
      duration,
      size: Math.floor(duration * 16), // Approximate size
      format: 'm4a',
      sampleRate: 44100,
      channels: 2,
      bitRate: 128000,
    };
  } catch (error) {
    console.error('Failed to stop recording:', error);
    return null;
  }
}

// Get current recording state
export function getRecordingState(): RecordingState {
  return recordingState;
}

// Get recording duration
export function getRecordingDuration(): number {
  if (recordingState === 'idle') return 0;
  return Date.now() - recordingStartTime;
}

// Waveform analysis
function startWaveformAnalysis() {
  if (!analyserNode) return;

  const bufferLength = analyserNode.frequencyBinCount;
  const dataArray = new Uint8Array(bufferLength);

  const analyze = () => {
    if (recordingState !== 'recording') return;

    analyserNode!.getByteFrequencyData(dataArray);
    
    // Convert to normalized values (0-1)
    waveformData = Array.from(dataArray).map(v => v / 255);
    
    // Notify listeners
    waveformListeners.forEach(listener => listener(waveformData));

    requestAnimationFrame(analyze);
  };

  analyze();
}

function stopWaveformAnalysis() {
  waveformData = [];
}

// Add waveform listener
export function addWaveformListener(callback: (data: number[]) => void): () => void {
  waveformListeners.push(callback);
  return () => {
    const index = waveformListeners.indexOf(callback);
    if (index > -1) {
      waveformListeners.splice(index, 1);
    }
  };
}

// Get current waveform data
export function getWaveformData(): number[] {
  return waveformData;
}

// Audio effects
const defaultEffects: AudioEffect[] = [
  { id: 'reverb', name: 'Reverb', enabled: false, value: 0.5 },
  { id: 'delay', name: 'Delay', enabled: false, value: 0.3 },
  { id: 'compression', name: 'Compression', enabled: false, value: 0.5 },
  { id: 'eq', name: 'EQ', enabled: false, value: 0.5 },
  { id: 'autotune', name: 'Auto-Tune', enabled: false, value: 0.5 },
  { id: 'distortion', name: 'Distortion', enabled: false, value: 0.2 },
];

let activeEffects: AudioEffect[] = [...defaultEffects];

// Get available effects
export function getAvailableEffects(): AudioEffect[] {
  return activeEffects;
}

// Toggle effect
export function toggleEffect(effectId: string): AudioEffect[] {
  activeEffects = activeEffects.map(effect => 
    effect.id === effectId ? { ...effect, enabled: !effect.enabled } : effect
  );
  return activeEffects;
}

// Set effect value
export function setEffectValue(effectId: string, value: number): AudioEffect[] {
  activeEffects = activeEffects.map(effect => 
    effect.id === effectId ? { ...effect, value: Math.max(0, Math.min(1, value)) } : effect
  );
  return activeEffects;
}

// Reset all effects
export function resetEffects(): AudioEffect[] {
  activeEffects = [...defaultEffects];
  return activeEffects;
}

// Apply effects to recording (simulated - in production would use Web Audio API nodes)
export async function applyEffectsToRecording(recordingUri: string): Promise<string> {
  // In a real implementation, this would:
  // 1. Load the audio file
  // 2. Create audio nodes for each enabled effect
  // 3. Process the audio through the effect chain
  // 4. Export the processed audio
  
  const enabledEffects = activeEffects.filter(e => e.enabled);
  console.log('Applying effects:', enabledEffects.map(e => e.name).join(', '));
  
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return recordingUri; // Return same URI (in production, return processed file)
}

// Save recording locally
export async function saveRecordingLocally(recordingInfo: RecordingInfo, name: string): Promise<string> {
  // In a real implementation, this would save to device storage
  const savedUri = `local://recordings/${name}_${Date.now()}.${recordingInfo.format}`;
  console.log('Saving recording to:', savedUri);
  return savedUri;
}

// Get saved recordings
export async function getSavedRecordings(): Promise<RecordingInfo[]> {
  // In a real implementation, this would read from device storage
  return [];
}

// Delete recording
export async function deleteRecording(uri: string): Promise<boolean> {
  try {
    if (Platform.OS === 'web' && uri.startsWith('blob:')) {
      URL.revokeObjectURL(uri);
    }
    return true;
  } catch (error) {
    console.error('Failed to delete recording:', error);
    return false;
  }
}

// Export recording to different format
export async function exportRecording(uri: string, format: 'mp3' | 'wav' | 'm4a'): Promise<string> {
  // In a real implementation, this would convert the audio format
  console.log(`Exporting ${uri} to ${format}`);
  return uri;
}

// Clean up resources
export function cleanup() {
  if (mediaRecorder && recordingState === 'recording') {
    mediaRecorder.stop();
  }
  if (mediaStream) {
    mediaStream.getTracks().forEach(track => track.stop());
  }
  if (mediaStreamSource) {
    mediaStreamSource.disconnect();
  }
  if (audioContext) {
    audioContext.close();
  }
  
  recordingState = 'idle';
  mediaRecorder = null;
  mediaStream = null;
  mediaStreamSource = null;
  audioContext = null;
  analyserNode = null;
  audioChunks = [];
  waveformData = [];
}

export default {
  requestMicrophonePermission,
  startRecording,
  pauseRecording,
  resumeRecording,
  stopRecording,
  getRecordingState,
  getRecordingDuration,
  addWaveformListener,
  getWaveformData,
  getAvailableEffects,
  toggleEffect,
  setEffectValue,
  resetEffects,
  applyEffectsToRecording,
  saveRecordingLocally,
  getSavedRecordings,
  deleteRecording,
  exportRecording,
  cleanup,
};
