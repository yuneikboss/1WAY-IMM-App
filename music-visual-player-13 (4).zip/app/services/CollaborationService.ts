export interface Collaborator {
  id: string;
  artistId: string;
  artistName: string;
  artistImage: string;
  role: 'lead' | 'featured' | 'producer' | 'writer' | 'mixer';
  splitPercentage: number;
  status: 'pending' | 'accepted' | 'declined';
  joinedAt?: number;
}

export interface CollaborationVersion {
  id: string;
  versionNumber: number;
  name: string;
  audioUri: string;
  duration: number;
  createdBy: string;
  createdAt: number;
  notes: string;
  isActive: boolean;
}

export interface CollaborationMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderImage: string;
  text: string;
  timestamp: number;
  attachmentUri?: string;
  attachmentType?: 'audio' | 'image' | 'file';
}

export interface Collaboration {
  id: string;
  title: string;
  description: string;
  coverImage?: string;
  ownerId: string;
  collaborators: Collaborator[];
  versions: CollaborationVersion[];
  messages: CollaborationMessage[];
  status: 'draft' | 'in_progress' | 'review' | 'completed' | 'released';
  createdAt: number;
  updatedAt: number;
  deadline?: number;
  genre?: string;
  bpm?: number;
  key?: string;
}

export interface SplitSheet {
  collaborationId: string;
  title: string;
  splits: {
    artistId: string;
    artistName: string;
    percentage: number;
    role: string;
  }[];
  totalPercentage: number;
  isValid: boolean;
  createdAt: number;
  signedBy: string[];
}

class CollaborationService {
  private collaborations: Collaboration[] = [];
  private splitSheets: SplitSheet[] = [];

  // Create a new collaboration
  createCollaboration(
    title: string,
    description: string,
    ownerId: string,
    ownerName: string,
    ownerImage: string
  ): Collaboration {
    const collaboration: Collaboration = {
      id: Date.now().toString(),
      title,
      description,
      ownerId,
      collaborators: [
        {
          id: `collab_${Date.now()}`,
          artistId: ownerId,
          artistName: ownerName,
          artistImage: ownerImage,
          role: 'lead',
          splitPercentage: 100,
          status: 'accepted',
          joinedAt: Date.now(),
        },
      ],
      versions: [],
      messages: [],
      status: 'draft',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.collaborations.push(collaboration);
    return collaboration;
  }

  // Invite collaborator
  inviteCollaborator(
    collaborationId: string,
    artistId: string,
    artistName: string,
    artistImage: string,
    role: Collaborator['role'],
    splitPercentage: number
  ): Collaborator | null {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return null;

    // Check if already invited
    if (collab.collaborators.some(c => c.artistId === artistId)) {
      return null;
    }

    const collaborator: Collaborator = {
      id: `collab_${Date.now()}`,
      artistId,
      artistName,
      artistImage,
      role,
      splitPercentage,
      status: 'pending',
    };

    collab.collaborators.push(collaborator);
    collab.updatedAt = Date.now();

    // Adjust owner's split
    this.redistributeSplits(collaborationId);

    return collaborator;
  }

  // Accept/decline invitation
  respondToInvitation(
    collaborationId: string,
    artistId: string,
    accept: boolean
  ): boolean {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return false;

    const collaborator = collab.collaborators.find(c => c.artistId === artistId);
    if (!collaborator) return false;

    collaborator.status = accept ? 'accepted' : 'declined';
    if (accept) {
      collaborator.joinedAt = Date.now();
    }
    collab.updatedAt = Date.now();

    return true;
  }

  // Update split percentages
  updateSplits(
    collaborationId: string,
    splits: { artistId: string; percentage: number }[]
  ): boolean {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return false;

    const totalPercentage = splits.reduce((sum, s) => sum + s.percentage, 0);
    if (totalPercentage !== 100) return false;

    splits.forEach(split => {
      const collaborator = collab.collaborators.find(c => c.artistId === split.artistId);
      if (collaborator) {
        collaborator.splitPercentage = split.percentage;
      }
    });

    collab.updatedAt = Date.now();
    return true;
  }

  // Redistribute splits evenly among accepted collaborators
  private redistributeSplits(collaborationId: string): void {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return;

    const acceptedCollaborators = collab.collaborators.filter(
      c => c.status === 'accepted' || c.status === 'pending'
    );
    const splitPercentage = Math.floor(100 / acceptedCollaborators.length);
    const remainder = 100 - splitPercentage * acceptedCollaborators.length;

    acceptedCollaborators.forEach((c, index) => {
      c.splitPercentage = splitPercentage + (index === 0 ? remainder : 0);
    });
  }

  // Add a new version
  addVersion(
    collaborationId: string,
    name: string,
    audioUri: string,
    duration: number,
    createdBy: string,
    notes: string
  ): CollaborationVersion | null {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return null;

    // Deactivate previous versions
    collab.versions.forEach(v => (v.isActive = false));

    const version: CollaborationVersion = {
      id: `version_${Date.now()}`,
      versionNumber: collab.versions.length + 1,
      name,
      audioUri,
      duration,
      createdBy,
      createdAt: Date.now(),
      notes,
      isActive: true,
    };

    collab.versions.push(version);
    collab.updatedAt = Date.now();
    collab.status = 'in_progress';

    return version;
  }

  // Revert to a previous version
  revertToVersion(collaborationId: string, versionId: string): boolean {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return false;

    const version = collab.versions.find(v => v.id === versionId);
    if (!version) return false;

    collab.versions.forEach(v => (v.isActive = false));
    version.isActive = true;
    collab.updatedAt = Date.now();

    return true;
  }

  // Send message in collaboration chat
  sendMessage(
    collaborationId: string,
    senderId: string,
    senderName: string,
    senderImage: string,
    text: string,
    attachmentUri?: string,
    attachmentType?: 'audio' | 'image' | 'file'
  ): CollaborationMessage | null {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return null;

    const message: CollaborationMessage = {
      id: `msg_${Date.now()}`,
      senderId,
      senderName,
      senderImage,
      text,
      timestamp: Date.now(),
      attachmentUri,
      attachmentType,
    };

    collab.messages.push(message);
    collab.updatedAt = Date.now();

    return message;
  }

  // Generate split sheet
  generateSplitSheet(collaborationId: string): SplitSheet | null {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return null;

    const acceptedCollaborators = collab.collaborators.filter(
      c => c.status === 'accepted'
    );

    const splits = acceptedCollaborators.map(c => ({
      artistId: c.artistId,
      artistName: c.artistName,
      percentage: c.splitPercentage,
      role: c.role,
    }));

    const totalPercentage = splits.reduce((sum, s) => sum + s.percentage, 0);

    const splitSheet: SplitSheet = {
      collaborationId,
      title: collab.title,
      splits,
      totalPercentage,
      isValid: totalPercentage === 100,
      createdAt: Date.now(),
      signedBy: [],
    };

    this.splitSheets.push(splitSheet);
    return splitSheet;
  }

  // Sign split sheet
  signSplitSheet(collaborationId: string, artistId: string): boolean {
    const splitSheet = this.splitSheets.find(
      s => s.collaborationId === collaborationId
    );
    if (!splitSheet || !splitSheet.isValid) return false;

    if (!splitSheet.signedBy.includes(artistId)) {
      splitSheet.signedBy.push(artistId);
    }

    return true;
  }

  // Check if split sheet is fully signed
  isSplitSheetComplete(collaborationId: string): boolean {
    const splitSheet = this.splitSheets.find(
      s => s.collaborationId === collaborationId
    );
    if (!splitSheet) return false;

    return splitSheet.signedBy.length === splitSheet.splits.length;
  }

  // Merge audio tracks (placeholder - actual merging would require audio processing)
  async mergeAudioTracks(
    collaborationId: string,
    trackUris: string[],
    outputName: string
  ): Promise<{ success: boolean; outputUri?: string; error?: string }> {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) {
      return { success: false, error: 'Collaboration not found' };
    }

    // In a real implementation, this would use audio processing libraries
    // For now, we'll simulate the merge
    await new Promise(resolve => setTimeout(resolve, 2000));

    const mergedUri = `merged_${Date.now()}.mp3`;
    
    // Add as new version
    this.addVersion(
      collaborationId,
      outputName,
      mergedUri,
      0, // Duration would be calculated
      collab.ownerId,
      `Merged from ${trackUris.length} tracks`
    );

    return { success: true, outputUri: mergedUri };
  }

  // Get collaboration by ID
  getCollaboration(id: string): Collaboration | undefined {
    return this.collaborations.find(c => c.id === id);
  }

  // Get collaborations for an artist
  getArtistCollaborations(artistId: string): Collaboration[] {
    return this.collaborations.filter(
      c => c.ownerId === artistId || c.collaborators.some(col => col.artistId === artistId)
    );
  }

  // Get pending invitations for an artist
  getPendingInvitations(artistId: string): Collaboration[] {
    return this.collaborations.filter(c =>
      c.collaborators.some(
        col => col.artistId === artistId && col.status === 'pending'
      )
    );
  }

  // Update collaboration status
  updateStatus(collaborationId: string, status: Collaboration['status']): boolean {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab) return false;

    collab.status = status;
    collab.updatedAt = Date.now();
    return true;
  }

  // Delete collaboration
  deleteCollaboration(collaborationId: string, requesterId: string): boolean {
    const collab = this.collaborations.find(c => c.id === collaborationId);
    if (!collab || collab.ownerId !== requesterId) return false;

    this.collaborations = this.collaborations.filter(c => c.id !== collaborationId);
    this.splitSheets = this.splitSheets.filter(s => s.collaborationId !== collaborationId);
    return true;
  }

  // Initialize with sample data
  initializeSampleData(currentUserId: string, currentUserName: string, currentUserImage: string): void {
    if (this.collaborations.length > 0) return;

    // Create sample collaborations
    const collab1 = this.createCollaboration(
      'Summer Vibes Remix',
      'Collaborative remix project for the summer',
      currentUserId,
      currentUserName,
      currentUserImage
    );

    // Add sample version
    this.addVersion(
      collab1.id,
      'Initial Beat',
      'sample_beat.mp3',
      180,
      currentUserId,
      'First draft of the beat'
    );

    // Add sample message
    this.sendMessage(
      collab1.id,
      currentUserId,
      currentUserName,
      currentUserImage,
      'Started working on the beat. Let me know what you think!'
    );
  }
}

export const collaborationService = new CollaborationService();
export default collaborationService;
